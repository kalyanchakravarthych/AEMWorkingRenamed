!function(){var e={834:function(e,t,r){"use strict";r(834),r(579),r(356),r(748)},579:function(){},356:function(){!function(){"use strict";var e='[data-cmp-is="helloworld"]',t='[data-cmp-hook-helloworld="property"]',r='[data-cmp-hook-helloworld="model"]';function a(e){e&&e.element&&function(e){e.element.removeAttribute("data-cmp-is");var a=e.element.querySelectorAll(t);a=1==a.length?a[0].textContent:null;var n=e.element.querySelectorAll(r);n=1==n.length?n[0].textContent:null,console&&console.log&&console.log("HelloWorld component JavaScript example","\nText property:\n",a,"\nModel message:\n",n)}(e)}function n(){for(var t=document.querySelectorAll(e),r=0;r<t.length;r++)new a({element:t[r]});var n=window.MutationObserver||window.WebKitMutationObserver||window.MozMutationObserver,i=document.querySelector("body");new n((function(t){t.forEach((function(t){var r=[].slice.call(t.addedNodes);r.length>0&&r.forEach((function(t){t.querySelectorAll&&[].slice.call(t.querySelectorAll(e)).forEach((function(e){new a({element:e})}))}))}))})).observe(i,{subtree:!0,childList:!0,characterData:!0})}"loading"!==document.readyState?n():document.addEventListener("DOMContentLoaded",n)}()},748:function(){}},t={};function r(a){var n=t[a];if(void 0!==n)return n.exports;var i=t[a]={exports:{}};return e[a](i,i.exports,r),i.exports}r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,{a:t}),t},r.d=function(e,t){for(var a in t)r.o(t,a)&&!r.o(e,a)&&Object.defineProperty(e,a,{enumerable:!0,get:t[a]})},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)};r(834)}();
/* VSC Header — disclosure navigation, mobile menu toggle, skip link.
   Pattern: WAI-ARIA APG "Disclosure Navigation Menu".
   - Click / Enter / Space toggles a dropdown; only one open at a time.
   - Esc closes the open dropdown (or the mobile panel) and returns focus.
   - ArrowDown on a trigger opens it and focuses the first link;
     ArrowUp/ArrowDown/Home/End move between links inside an open dropdown.
   - Focus leaving a dropdown, or a click outside the header, closes it. */
(function () {
    "use strict";

    var uid = 0;
    var MOBILE_QUERY = "(max-width: 899.98px)";

    function nextId(prefix) {
        uid += 1;
        return prefix + "-" + uid;
    }

    function ensureId(el, prefix) {
        if (!el.id) {
            el.id = nextId(prefix);
        }
        return el.id;
    }

    /* Point the skip link at the page's main content. Removes the link if
       nothing suitable exists so it never targets a missing anchor. */
    function wireSkipLink(root) {
        var skip = root.querySelector("[data-cmp-vscheader-skip]");
        if (!skip) {
            return;
        }
        var target = document.getElementById("main-content") ||
            document.querySelector("main, [role='main']") ||
            document.querySelector(".cmp-twocolgrid__col--right");
        if (!target) {
            skip.parentNode.removeChild(skip);
            return;
        }
        if (!target.id) {
            target.id = "main-content";
        }
        skip.setAttribute("href", "#" + target.id);
        if (!target.hasAttribute("tabindex")) {
            target.setAttribute("tabindex", "-1");
        }
        skip.addEventListener("click", function () {
            /* Some browsers scroll but do not move focus for in-page links. */
            window.setTimeout(function () { target.focus(); }, 0);
        });
    }

    function init(root) {
        if (!root || root.__vscHeaderInit) {
            return;
        }
        root.__vscHeaderInit = true;

        var triggers = Array.prototype.slice.call(root.querySelectorAll("[data-cmp-vscheader-trigger]"));
        var toggle = root.querySelector("[data-cmp-vscheader-toggle]");
        var panel = root.querySelector("[data-cmp-vscheader-panel]");
        var mq = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;

        function menuOf(trigger) { return trigger.nextElementSibling; }
        function linksOf(menu) { return Array.prototype.slice.call(menu.querySelectorAll("a[href]")); }

        function close(trigger, returnFocus) {
            if (trigger.getAttribute("aria-expanded") !== "true") {
                return;
            }
            trigger.setAttribute("aria-expanded", "false");
            menuOf(trigger).hidden = true;
            if (returnFocus) {
                trigger.focus();
            }
        }

        function closeAll(except) {
            triggers.forEach(function (t) {
                if (t !== except) {
                    close(t, false);
                }
            });
        }

        function open(trigger, focusFirst) {
            closeAll(trigger);
            trigger.setAttribute("aria-expanded", "true");
            var menu = menuOf(trigger);
            menu.hidden = false;
            if (focusFirst) {
                var links = linksOf(menu);
                if (links.length) {
                    links[0].focus();
                }
            }
        }

        function openTrigger() {
            for (var i = 0; i < triggers.length; i++) {
                if (triggers[i].getAttribute("aria-expanded") === "true") {
                    return triggers[i];
                }
            }
            return null;
        }

        /* ---------- Dropdown triggers ---------- */
        triggers.forEach(function (trigger) {
            var menu = menuOf(trigger);
            if (!menu) {
                return;
            }
            trigger.setAttribute("aria-controls", ensureId(menu, "vscheader-menu"));

            trigger.addEventListener("click", function () {
                if (trigger.getAttribute("aria-expanded") === "true") {
                    close(trigger, false);
                } else {
                    open(trigger, false);
                }
            });

            trigger.addEventListener("keydown", function (e) {
                if (e.key === "ArrowDown") {
                    e.preventDefault();
                    open(trigger, true);
                }
            });

            menu.addEventListener("keydown", function (e) {
                var links = linksOf(menu);
                var i = links.indexOf(document.activeElement);
                if (i < 0) {
                    return;
                }
                var next = null;
                if (e.key === "ArrowDown") {
                    next = links[(i + 1) % links.length];
                } else if (e.key === "ArrowUp") {
                    next = links[(i - 1 + links.length) % links.length];
                } else if (e.key === "Home") {
                    next = links[0];
                } else if (e.key === "End") {
                    next = links[links.length - 1];
                }
                if (next) {
                    e.preventDefault();
                    next.focus();
                }
            });

            /* Close when keyboard focus leaves this item entirely. */
            trigger.parentNode.addEventListener("focusout", function (e) {
                if (e.relatedTarget && !trigger.parentNode.contains(e.relatedTarget)) {
                    close(trigger, false);
                }
            });
        });

        /* ---------- Mobile menu toggle ---------- */
        function setPanel(isOpen, returnFocus) {
            if (!toggle || !panel) {
                return;
            }
            toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
            panel.classList.toggle("cmp-vscheader__nav-row--open", isOpen);
            if (!isOpen) {
                closeAll(null);
                if (returnFocus) {
                    toggle.focus();
                }
            }
        }

        function onBreakpointChange(ev) {
            if (!ev.matches) {
                setPanel(false, false);
            }
        }

        if (toggle && panel) {
            toggle.setAttribute("aria-controls", ensureId(panel, "vscheader-panel"));
            toggle.addEventListener("click", function () {
                setPanel(toggle.getAttribute("aria-expanded") !== "true", false);
            });
            /* Leaving the mobile breakpoint resets the panel state. */
            if (mq) {
                if (mq.addEventListener) {
                    mq.addEventListener("change", onBreakpointChange);
                } else if (mq.addListener) {
                    mq.addListener(onBreakpointChange);
                }
            }
        }

        /* ---------- Escape + outside click ---------- */
        root.addEventListener("keydown", function (e) {
            if (e.key !== "Escape" && e.key !== "Esc") {
                return;
            }
            var current = openTrigger();
            if (current) {
                e.preventDefault();
                close(current, true);
            } else if (toggle && toggle.getAttribute("aria-expanded") === "true") {
                e.preventDefault();
                setPanel(false, true);
            }
        });

        document.addEventListener("click", function (e) {
            if (!root.contains(e.target)) {
                closeAll(null);
            }
        });

        wireSkipLink(root);
    }

    function boot() {
        document.querySelectorAll("[data-cmp-vscheader]").forEach(init);
    }
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Header (cmp-header) — disclosure navigation, mobile menu toggle, skip link.
   Pattern: WAI-ARIA APG "Disclosure Navigation Menu".
   - Click / Enter / Space toggles a dropdown; only one open at a time.
   - Esc closes the open dropdown (or the mobile panel) and returns focus.
   - ArrowDown on a trigger opens it and focuses the first link;
     ArrowUp/ArrowDown/Home/End move between links inside an open dropdown.
   - Focus leaving a dropdown, or a click outside the header, closes it. */
(function () {
    "use strict";

    var uid = 0;
    var MOBILE_QUERY = "(max-width: 899.98px)";

    function nextId(prefix) {
        uid += 1;
        return prefix + "-" + uid;
    }

    function ensureId(el, prefix) {
        if (!el.id) {
            el.id = nextId(prefix);
        }
        return el.id;
    }

    /* Point the skip link at the page's main content. Removes the link if
       nothing suitable exists so it never targets a missing anchor. */
    function wireSkipLink(root) {
        var skip = root.querySelector("[data-cmp-header-skip]");
        if (!skip) {
            return;
        }
        var target = document.getElementById("main-content") ||
            document.querySelector("main, [role='main']") ||
            document.querySelector(".cmp-twocolgrid__col--right");
        if (!target) {
            skip.parentNode.removeChild(skip);
            return;
        }
        if (!target.id) {
            target.id = "main-content";
        }
        skip.setAttribute("href", "#" + target.id);
        if (!target.hasAttribute("tabindex")) {
            target.setAttribute("tabindex", "-1");
        }
        skip.addEventListener("click", function () {
            /* Some browsers scroll but do not move focus for in-page links. */
            window.setTimeout(function () { target.focus(); }, 0);
        });
    }

    function init(root) {
        if (!root || root.__cmpHeaderInit) {
            return;
        }
        root.__cmpHeaderInit = true;

        var triggers = Array.prototype.slice.call(root.querySelectorAll("[data-cmp-header-trigger]"));
        var toggle = root.querySelector("[data-cmp-header-toggle]");
        var panel = root.querySelector("[data-cmp-header-panel]");
        var mq = window.matchMedia ? window.matchMedia(MOBILE_QUERY) : null;

        function menuOf(trigger) { return trigger.nextElementSibling; }
        function linksOf(menu) { return Array.prototype.slice.call(menu.querySelectorAll("a[href]")); }

        function close(trigger, returnFocus) {
            if (trigger.getAttribute("aria-expanded") !== "true") {
                return;
            }
            trigger.setAttribute("aria-expanded", "false");
            menuOf(trigger).hidden = true;
            if (returnFocus) {
                trigger.focus();
            }
        }

        function closeAll(except) {
            triggers.forEach(function (t) {
                if (t !== except) {
                    close(t, false);
                }
            });
        }

        function open(trigger, focusFirst) {
            closeAll(trigger);
            trigger.setAttribute("aria-expanded", "true");
            var menu = menuOf(trigger);
            menu.hidden = false;
            if (focusFirst) {
                var links = linksOf(menu);
                if (links.length) {
                    links[0].focus();
                }
            }
        }

        function openTrigger() {
            for (var i = 0; i < triggers.length; i++) {
                if (triggers[i].getAttribute("aria-expanded") === "true") {
                    return triggers[i];
                }
            }
            return null;
        }

        /* ---------- Dropdown triggers ---------- */
        triggers.forEach(function (trigger) {
            var menu = menuOf(trigger);
            if (!menu) {
                return;
            }
            trigger.setAttribute("aria-controls", ensureId(menu, "cmp-header-menu"));

            trigger.addEventListener("click", function () {
                if (trigger.getAttribute("aria-expanded") === "true") {
                    close(trigger, false);
                } else {
                    open(trigger, false);
                }
            });

            trigger.addEventListener("keydown", function (e) {
                if (e.key === "ArrowDown") {
                    e.preventDefault();
                    open(trigger, true);
                }
            });

            menu.addEventListener("keydown", function (e) {
                var links = linksOf(menu);
                var i = links.indexOf(document.activeElement);
                if (i < 0) {
                    return;
                }
                var next = null;
                if (e.key === "ArrowDown") {
                    next = links[(i + 1) % links.length];
                } else if (e.key === "ArrowUp") {
                    next = links[(i - 1 + links.length) % links.length];
                } else if (e.key === "Home") {
                    next = links[0];
                } else if (e.key === "End") {
                    next = links[links.length - 1];
                }
                if (next) {
                    e.preventDefault();
                    next.focus();
                }
            });

            /* Close when keyboard focus leaves this item entirely. */
            trigger.parentNode.addEventListener("focusout", function (e) {
                if (e.relatedTarget && !trigger.parentNode.contains(e.relatedTarget)) {
                    close(trigger, false);
                }
            });
        });

        /* ---------- Mobile menu toggle ---------- */
        function setPanel(isOpen, returnFocus) {
            if (!toggle || !panel) {
                return;
            }
            toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
            panel.classList.toggle("cmp-header__nav--open", isOpen);
            if (!isOpen) {
                closeAll(null);
                if (returnFocus) {
                    toggle.focus();
                }
            }
        }

        function onBreakpointChange(ev) {
            if (!ev.matches) {
                setPanel(false, false);
            }
        }

        if (toggle && panel) {
            toggle.setAttribute("aria-controls", ensureId(panel, "cmp-header-panel"));
            toggle.addEventListener("click", function () {
                setPanel(toggle.getAttribute("aria-expanded") !== "true", false);
            });
            /* Leaving the mobile breakpoint resets the panel state. */
            if (mq) {
                if (mq.addEventListener) {
                    mq.addEventListener("change", onBreakpointChange);
                } else if (mq.addListener) {
                    mq.addListener(onBreakpointChange);
                }
            }
        }

        /* ---------- Escape + outside click ---------- */
        root.addEventListener("keydown", function (e) {
            if (e.key !== "Escape" && e.key !== "Esc") {
                return;
            }
            var current = openTrigger();
            if (current) {
                e.preventDefault();
                close(current, true);
            } else if (toggle && toggle.getAttribute("aria-expanded") === "true") {
                e.preventDefault();
                setPanel(false, true);
            }
        });

        document.addEventListener("click", function (e) {
            if (!root.contains(e.target)) {
                closeAll(null);
            }
        });

        wireSkipLink(root);
    }

    function boot() {
        document.querySelectorAll("[data-cmp-header]").forEach(init);
    }
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Two Column Grid — aligns the left column with the header tabs.
   Left column: from "Home" (1st primary nav item) to "My spend" (2nd item).
   Works with the cmp-header and cmp-vscheader components.
   Only sets two CSS custom properties; layout stays in _twocolgrid.scss. */
(function () {
    "use strict";

    var NAV_ITEMS = ".cmp-header__nav-list > .cmp-header__nav-item, " +
        ".cmp-vscheader__nav-list > .cmp-vscheader__item";
    var TAB = ".cmp-header__nav-link, .cmp-vscheader__nav-link";
    var grids = [];
    var frame = 0;

    /* Left/right edges of a tab: its box, or its visible label (box minus padding). */
    function edges(tab, align) {
        var rect = tab.getBoundingClientRect();
        if (align === "tab") {
            return { left: rect.left, right: rect.right };
        }
        var style = window.getComputedStyle(tab);
        return {
            left: rect.left + (parseFloat(style.paddingLeft) || 0),
            right: rect.right - (parseFloat(style.paddingRight) || 0)
        };
    }

    function headerTabs() {
        var items = document.querySelectorAll(NAV_ITEMS);
        if (items.length < 2) {
            return null;
        }
        var first = items[0].querySelector(TAB);
        var second = items[1].querySelector(TAB);
        if (!first || !second) {
            return null;
        }
        /* Collapsed (mobile) header: tabs are not laid out in a row. */
        if (!first.offsetWidth || !second.offsetWidth) {
            return null;
        }
        return { first: first, second: second };
    }

    function align(grid) {
        var tabs = headerTabs();
        if (!tabs) {
            grid.style.removeProperty("--cmp-twocolgrid-start");
            grid.style.removeProperty("--cmp-twocolgrid-end");
            return;
        }
        var mode = grid.getAttribute("data-cmp-twocolgrid-align") === "label" ? "label" : "tab";
        var origin = grid.getBoundingClientRect().left;
        var start = edges(tabs.first, mode).left - origin;
        var end = edges(tabs.second, mode).right - origin;
        if (end <= start || start < 0) {
            return;
        }
        grid.style.setProperty("--cmp-twocolgrid-start", start.toFixed(2) + "px");
        grid.style.setProperty("--cmp-twocolgrid-end", end.toFixed(2) + "px");
    }

    function alignAll() {
        frame = 0;
        grids = grids.filter(function (g) { return document.documentElement.contains(g); });
        grids.forEach(align);
    }

    function schedule() {
        if (!frame) {
            frame = window.requestAnimationFrame(alignAll);
        }
    }

    function register(root) {
        var found = root.querySelectorAll ? root.querySelectorAll("[data-cmp-twocolgrid]") : [];
        var added = false;
        Array.prototype.forEach.call(found, function (grid) {
            if (grids.indexOf(grid) < 0) {
                grids.push(grid);
                added = true;
            }
        });
        if (root.matches && root.matches("[data-cmp-twocolgrid]") && grids.indexOf(root) < 0) {
            grids.push(root);
            added = true;
        }
        if (added) {
            schedule();
        }
    }

    function boot() {
        register(document);

        window.addEventListener("resize", schedule);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(schedule);
        }
        /* Header labels or widths can change (authoring, fonts, zoom). */
        if (window.ResizeObserver) {
            var observer = new window.ResizeObserver(schedule);
            Array.prototype.forEach.call(document.querySelectorAll(NAV_ITEMS), function (item) {
                observer.observe(item);
            });
        }
        /* AEM editor re-renders components after edits (REFRESH_SELF/PAGE). */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                var changed = false;
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            register(node);
                            changed = true;
                        }
                    });
                });
                if (changed && grids.length) {
                    schedule();
                }
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Card Listing — Cards page behaviour (no backend, in-memory only).
   - Filter dropdown (status) and Create card split button
   - Employee search drawer + Create Card form drawer
   - Submit → new row inserted alphabetically + success toast
   - Row selection count + "Update cards" state
   - Pagination: drives a "VSC Pagination" component placed after the
     listing (or the one whose "Controls" field names this listing's ID).
     Rows per page comes from data-cmp-cardlist-page-size (dialog, default 2).
   The default rows are rendered by HTL; this script only enhances them.
   New rows are built with DOM APIs (textContent), never innerHTML, so
   form input can't inject markup. */
(function () {
    "use strict";

    var SVG_NS = "http://www.w3.org/2000/svg";

    /* ---------- Employee catalog for autosuggest ---------- */
    var EMPLOYEES = [
        { id: "deverett01", firstName: "Daniel", lastName: "Everett", initials: "DE",
            cardholderName: "Daniel Everett", companyName: "Acme Corp", workPhone: "daneverett01",
            addressLine1: "5032 Hawks Nest Lane", city: "St. Louis", state: "MO", zip: "12345" },
        { id: "jsmith02", firstName: "Jane", lastName: "Smith", initials: "JS",
            cardholderName: "Jane Smith", companyName: "Acme Corp", workPhone: "jsmith02",
            addressLine1: "123 Main St", city: "Boston", state: "MA", zip: "02108" },
        { id: "rtaylor03", firstName: "Rebecca", lastName: "Taylor", initials: "RT",
            cardholderName: "Rebecca Taylor", companyName: "Acme Corp", workPhone: "rtaylor03",
            addressLine1: "88 Oak Avenue", city: "Austin", state: "TX", zip: "73301" }
    ];

    var rowUid = 0;

    /* ---------- DOM helpers ---------- */
    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = text;
        }
        return node;
    }

    function chevronSvg() {
        var svg = document.createElementNS(SVG_NS, "svg");
        svg.setAttribute("viewBox", "0 0 12 12");
        svg.setAttribute("width", "12");
        svg.setAttribute("height", "12");
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("focusable", "false");
        var path = document.createElementNS(SVG_NS, "path");
        path.setAttribute("d", "M4 1l5 5-5 5");
        path.setAttribute("stroke", "currentColor");
        path.setAttribute("stroke-width", "1.75");
        path.setAttribute("fill", "none");
        path.setAttribute("stroke-linecap", "round");
        path.setAttribute("stroke-linejoin", "round");
        svg.appendChild(path);
        return svg;
    }

    /* Same markup as the HTL rows in cardlisting.html. */
    function buildRow(r) {
        rowUid += 1;
        var checkId = "cmp-row-new-" + rowUid;
        var tr = el("tr");
        tr.setAttribute("data-cmp-status", r.status);

        var tdCheck = el("td");
        var label = el("label", "cmp-visually-hidden", "Select " + r.name);
        label.setAttribute("for", checkId);
        var check = el("input");
        check.type = "checkbox";
        check.id = checkId;
        check.setAttribute("data-cmp-rowcheck", "");
        tdCheck.appendChild(label);
        tdCheck.appendChild(check);

        var tdHolder = el("td");
        var holder = el("div", "cmp-cardlist__holder");
        var avatar = el("span", "cmp-avatar", r.initials);
        avatar.setAttribute("aria-hidden", "true");
        var name = el("span", "cmp-cardlist__name");
        name.appendChild(el("span", "cmp-cardlist__fullname", r.name));
        name.appendChild(el("span", "cmp-cardlist__sub", r.sub));
        holder.appendChild(avatar);
        holder.appendChild(name);
        tdHolder.appendChild(holder);

        var tdStatus = el("td");
        var pill = el("span", "cmp-pill cmp-pill--" + r.status.toLowerCase());
        pill.appendChild(el("span", "cmp-pill__label", r.status));
        tdStatus.appendChild(pill);

        var tdDetail = el("td", "cmp-cardlist__details-col");
        var link = el("a", "cmp-cardlist__detail");
        link.href = "#";
        link.setAttribute("aria-label", "View " + r.name + " details");
        link.appendChild(chevronSvg());
        tdDetail.appendChild(link);

        tr.appendChild(tdCheck);
        tr.appendChild(tdHolder);
        tr.appendChild(el("td", null, r.account));
        tr.appendChild(el("td", "cmp-cardlist__num", r.limit));
        tr.appendChild(el("td", null, r.type));
        tr.appendChild(tdStatus);
        tr.appendChild(el("td", null, r.updated));
        tr.appendChild(tdDetail);
        return tr;
    }

    function rowName(tr) {
        var n = tr.querySelector(".cmp-cardlist__fullname");
        return n ? n.textContent.trim() : "";
    }

    function todayString() {
        var d = new Date();
        var mm = String(d.getMonth() + 1);
        var dd = String(d.getDate());
        return (mm.length < 2 ? "0" + mm : mm) + "/" + (dd.length < 2 ? "0" + dd : dd) + "/" + d.getFullYear();
    }

    /* ---------- Component ---------- */
    function init(root) {
        if (!root || root.__cardlistInit) {
            return;
        }
        root.__cardlistInit = true;

        function q(sel) {
            return root.querySelector(sel);
        }

        var createTrigger = q("[data-cmp-create-trigger]");
        var createMenu = q("#cmp-cardlist-create-menu");
        var createOptions = root.querySelectorAll("[data-cmp-create-option]");

        var filterTrigger = q("[data-cmp-filter-trigger]");
        var filterPanel = q("#cmp-cardlist-filter-panel");
        var filterLabel = q("[data-cmp-filter-label]");
        var filterOpts = root.querySelectorAll("[data-cmp-filter-opt]");
        var filterClear = q("[data-cmp-filter-clear]");
        var filterApply = q("[data-cmp-filter-apply]");

        var empDrawer = q("[data-cmp-empsearch-drawer]");
        var empClose = q("[data-cmp-empsearch-close]");
        var empInput = q("[data-cmp-empsearch-input]");
        var empResults = q("[data-cmp-empsearch-results]");

        var cardDrawer = q("[data-cmp-createcard-drawer]");
        var cardClose = q("[data-cmp-createcard-close]");
        var cardForm = q("[data-cmp-createcard-form]");
        var cardError = q("[data-cmp-form-error]");

        var tbody = q('[data-cmp-tbody="cardlist"]');
        var emptyMsg = q("[data-cmp-cardlist-empty]");
        var selectAll = q("[data-cmp-selectall]");
        var selectionCount = q("[data-cmp-selection-count]");
        var updateCards = q("[data-cmp-update-cards]");

        var toast = q("[data-cmp-toast]");
        var toastText = q("[data-cmp-toast-text]");
        var toastClose = q("[data-cmp-toast-close]");

        var charCount = q("[data-cmp-charcount]");
        var commentsField = q("#cf-comments");

        if (!tbody) {
            return;
        }

        /* =====================================================
           Filtering + pagination
           ===================================================== */
        var pageSize = parseInt(root.getAttribute("data-cmp-cardlist-page-size"), 10);
        if (!(pageSize > 0)) {
            pageSize = 2;
        }
        var page = 1;
        var activeStatuses = Array.prototype.slice.call(filterOpts)
            .filter(function (o) { return o.checked; })
            .map(function (o) { return o.value; });
        var pager = null;

        function allRows() {
            return Array.prototype.slice.call(tbody.querySelectorAll("tr"));
        }

        function matchingRows() {
            return allRows().filter(function (tr) {
                var st = tr.getAttribute("data-cmp-status") || "";
                return activeStatuses.length === 0 || activeStatuses.indexOf(st) !== -1;
            });
        }

        function pageCount(count) {
            return Math.max(1, Math.ceil(count / pageSize));
        }

        /* The pager linked to this listing: one naming our ID, otherwise the
           first unclaimed pager after the listing in document order. */
        function findPager() {
            var pagers = Array.prototype.slice.call(document.querySelectorAll("[data-cmp-pager]"));
            var id = root.id;
            var named = pagers.filter(function (p) {
                return id && p.getAttribute("data-cmp-pager-for") === id;
            });
            if (named.length) {
                return named[0];
            }
            var following = pagers.filter(function (p) {
                var free = !p.getAttribute("data-cmp-pager-for") && (!p.__vscPagerOwner || p.__vscPagerOwner === root);
                /* eslint-disable-next-line no-bitwise */
                return free && (root.compareDocumentPosition(p) & Node.DOCUMENT_POSITION_FOLLOWING);
            });
            return following.length ? following[0] : null;
        }

        function onPagerChange(e) {
            var requested = e.detail && e.detail.page;
            if (typeof requested === "number") {
                page = requested;
                render();
            }
        }

        function linkPager() {
            var found = findPager();
            if (found === pager) {
                return;
            }
            if (pager) {
                pager.removeEventListener("vsc:pager-change", onPagerChange);
                pager.__vscPagerOwner = null;
            }
            pager = found;
            if (pager) {
                pager.__vscPagerOwner = root;
                pager.addEventListener("vsc:pager-change", onPagerChange);
            }
        }

        function updateSelectAllState() {
            var onPage = allRows().filter(function (tr) { return !tr.hidden; })
                .map(function (tr) { return tr.querySelector("[data-cmp-rowcheck]"); })
                .filter(Boolean);
            var checked = onPage.filter(function (c) { return c.checked; }).length;
            selectAll.checked = onPage.length > 0 && checked === onPage.length;
            selectAll.indeterminate = checked > 0 && checked < onPage.length;
            selectAll.disabled = onPage.length === 0;
        }

        function render() {
            linkPager();
            var matches = matchingRows();
            var paged = !!pager;
            var pages = paged ? pageCount(matches.length) : 1;
            page = Math.min(Math.max(1, page), pages);
            var start = (page - 1) * pageSize;
            var end = start + pageSize;

            allRows().forEach(function (tr) {
                var idx = matches.indexOf(tr);
                tr.hidden = idx === -1 || (paged && (idx < start || idx >= end));
            });
            if (emptyMsg) {
                emptyMsg.hidden = matches.length > 0;
            }
            if (pager) {
                pager.setAttribute("data-cmp-pager-page", String(page));
                pager.setAttribute("data-cmp-pager-pages", String(pages));
                pager.dispatchEvent(new CustomEvent("vsc:pager-render", { detail: { page: page, pages: pages } }));
            }
            updateSelectAllState();
        }

        /* A pager added later (e.g. dropped in the AEM editor) links itself. */
        document.addEventListener("vsc:pager-ready", function () {
            if (document.documentElement.contains(root)) {
                render();
            }
        });

        /* =====================================================
           Create card split button (ARIA menu)
           ===================================================== */
        function menuItems() {
            return Array.prototype.slice.call(createMenu.querySelectorAll('[role="menuitem"]'));
        }

        function toggleCreateMenu(show) {
            var open = show !== undefined ? show : createMenu.hasAttribute("hidden");
            if (open) {
                createMenu.removeAttribute("hidden");
                createTrigger.setAttribute("aria-expanded", "true");
                var items = menuItems();
                if (items.length) {
                    items[0].focus();
                }
            } else {
                createMenu.setAttribute("hidden", "");
                createTrigger.setAttribute("aria-expanded", "false");
            }
        }

        createTrigger.addEventListener("click", function (e) {
            e.stopPropagation();
            toggleCreateMenu();
        });
        createTrigger.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") {
                e.preventDefault();
                toggleCreateMenu(true);
            }
        });
        createMenu.addEventListener("keydown", function (e) {
            var items = menuItems();
            var idx = items.indexOf(document.activeElement);
            if (e.key === "ArrowDown") {
                e.preventDefault();
                items[(idx + 1) % items.length].focus();
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                items[(idx - 1 + items.length) % items.length].focus();
            } else if (e.key === "Home") {
                e.preventDefault();
                items[0].focus();
            } else if (e.key === "End") {
                e.preventDefault();
                items[items.length - 1].focus();
            } else if (e.key === "Escape") {
                toggleCreateMenu(false);
                createTrigger.focus();
            } else if (e.key === "Tab") {
                toggleCreateMenu(false);
            }
        });

        createOptions.forEach(function (opt) {
            opt.addEventListener("click", function () {
                var choice = opt.getAttribute("data-cmp-create-option");
                toggleCreateMenu(false);
                if (choice === "existing") {
                    openEmployeeDrawer();
                } else {
                    clearForm();
                    openCardDrawer();
                }
            });
        });

        /* =====================================================
           Filter dropdown
           ===================================================== */
        function setFilterOpen(open) {
            filterPanel.hidden = !open;
            filterTrigger.setAttribute("aria-expanded", open ? "true" : "false");
        }

        filterTrigger.addEventListener("click", function (e) {
            e.stopPropagation();
            setFilterOpen(filterPanel.hidden);
        });
        filterPanel.addEventListener("keydown", function (e) {
            if (e.key === "Escape") {
                setFilterOpen(false);
                filterTrigger.focus();
            }
        });
        if (filterClear) {
            filterClear.addEventListener("click", function () {
                filterOpts.forEach(function (o) { o.checked = false; });
            });
        }
        if (filterApply) {
            filterApply.addEventListener("click", function () {
                activeStatuses = Array.prototype.slice.call(filterOpts)
                    .filter(function (o) { return o.checked; })
                    .map(function (o) { return o.value; });
                var n = activeStatuses.length;
                filterLabel.textContent = n === 0 ? "No filters applied" :
                    n + " filter" + (n === 1 ? "" : "s") + " applied";
                setFilterOpen(false);
                filterTrigger.focus();
                page = 1;
                render();
            });
        }

        document.addEventListener("click", function (e) {
            if (!createMenu.hidden && !createMenu.contains(e.target) && !createTrigger.contains(e.target)) {
                toggleCreateMenu(false);
            }
            if (!filterPanel.hidden && !filterPanel.contains(e.target) && !filterTrigger.contains(e.target)) {
                setFilterOpen(false);
            }
        });

        /* =====================================================
           Drawers
           ===================================================== */
        var lastFocused = null;

        function openDrawer(drawer) {
            lastFocused = document.activeElement;
            drawer.removeAttribute("hidden");
            document.body.style.overflow = "hidden";
            drawer.querySelector(".cmp-drawer__panel").focus();
        }

        function closeDrawer(drawer) {
            drawer.setAttribute("hidden", "");
            document.body.style.overflow = "";
            if (lastFocused && lastFocused.focus) {
                lastFocused.focus();
            }
        }

        function openEmployeeDrawer() {
            openDrawer(empDrawer);
            empInput.value = "";
            empResults.textContent = "";
            empInput.setAttribute("aria-expanded", "false");
        }

        function closeEmployeeDrawer() {
            closeDrawer(empDrawer);
        }

        function openCardDrawer() {
            openDrawer(cardDrawer);
        }

        function closeCardDrawer() {
            closeDrawer(cardDrawer);
        }

        empClose.addEventListener("click", closeEmployeeDrawer);
        empDrawer.querySelector(".cmp-drawer__backdrop").addEventListener("click", closeEmployeeDrawer);
        cardClose.addEventListener("click", closeCardDrawer);
        cardDrawer.querySelector(".cmp-drawer__backdrop").addEventListener("click", closeCardDrawer);

        empInput.addEventListener("input", function () {
            var term = empInput.value.trim().toLowerCase();
            empResults.textContent = "";
            if (!term) {
                empInput.setAttribute("aria-expanded", "false");
                return;
            }
            var matches = EMPLOYEES.filter(function (emp) {
                return emp.firstName.toLowerCase().indexOf(term) !== -1 ||
                    emp.lastName.toLowerCase().indexOf(term) !== -1 ||
                    emp.id.toLowerCase().indexOf(term) !== -1;
            });
            matches.forEach(function (emp) {
                var full = emp.firstName + " " + emp.lastName;
                var li = el("li", "cmp-empsel__item");
                li.setAttribute("role", "option");
                li.setAttribute("aria-selected", "false");
                var avatar = el("span", "cmp-avatar", emp.initials);
                avatar.setAttribute("aria-hidden", "true");
                var meta = el("div", "cmp-empsel__meta");
                meta.appendChild(el("span", "cmp-empsel__name", full));
                meta.appendChild(el("span", "cmp-empsel__sub", emp.id));
                var btn = el("button", "cmp-btn cmp-btn--text", "Select");
                btn.type = "button";
                btn.setAttribute("aria-label", "Select " + full);
                btn.addEventListener("click", function () {
                    closeEmployeeDrawer();
                    prefillForm(emp);
                    openCardDrawer();
                });
                li.appendChild(avatar);
                li.appendChild(meta);
                li.appendChild(btn);
                empResults.appendChild(li);
            });
            empInput.setAttribute("aria-expanded", matches.length > 0 ? "true" : "false");
        });

        /* =====================================================
           Create Card form
           ===================================================== */
        function field(name) {
            return cardForm.querySelector('[name="' + name + '"]');
        }

        function clearForm() {
            cardForm.reset();
            cardError.setAttribute("hidden", "");
            cardForm.querySelectorAll(".cmp-field__err").forEach(function (p) { p.setAttribute("hidden", ""); });
            cardForm.querySelectorAll('[aria-invalid="true"]').forEach(function (f) {
                f.removeAttribute("aria-invalid");
            });
            if (charCount) {
                charCount.textContent = "500";
            }
        }

        function prefillForm(emp) {
            clearForm();
            ["firstName", "lastName", "cardholderName", "workPhone", "addressLine1", "city", "state", "zip"]
                .forEach(function (name) {
                    field(name).value = emp[name];
                });
        }

        if (commentsField && charCount) {
            commentsField.addEventListener("input", function () {
                charCount.textContent = String(500 - commentsField.value.length);
            });
        }

        function setFieldError(f, invalid) {
            var errId = f.getAttribute("aria-errormessage");
            var errP = errId ? document.getElementById(errId) : null;
            if (invalid) {
                f.setAttribute("aria-invalid", "true");
                if (errP) {
                    errP.removeAttribute("hidden");
                }
            } else {
                f.removeAttribute("aria-invalid");
                if (errP) {
                    errP.setAttribute("hidden", "");
                }
            }
        }

        cardForm.addEventListener("submit", function (e) {
            e.preventDefault();
            cardError.setAttribute("hidden", "");
            var firstInvalid = null;
            cardForm.querySelectorAll("[required]").forEach(function (f) {
                var invalid = !f.value || f.value.trim() === "";
                setFieldError(f, invalid);
                if (invalid && !firstInvalid) {
                    firstInvalid = f;
                }
            });
            if (firstInvalid) {
                cardError.textContent = "Please fix the highlighted fields.";
                cardError.removeAttribute("hidden");
                firstInvalid.focus();
                return;
            }

            var first = field("firstName").value.trim();
            var last = field("lastName").value.trim();
            var holderName = field("cardholderName").value.trim();
            var amount = parseFloat(field("creditLimit").value || "0");
            var digits = field("workPhone").value.replace(/[^0-9]/g, "").slice(-4);

            var tr = buildRow({
                initials: (first.charAt(0) + last.charAt(0)).toUpperCase(),
                name: holderName,
                sub: digits || "0001",
                account: "Corporate account",
                limit: (isNaN(amount) ? 0 : amount).toLocaleString("en-US",
                    { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " USD",
                type: "Corporate card",
                status: "Active",
                updated: todayString()
            });

            /* Insert alphabetically by cardholder name. */
            var before = null;
            allRows().some(function (row) {
                if (rowName(row).localeCompare(holderName, undefined, { numeric: true, sensitivity: "base" }) > 0) {
                    before = row;
                    return true;
                }
                return false;
            });
            tbody.insertBefore(tr, before);

            /* Show the page that contains the new card. */
            var idx = matchingRows().indexOf(tr);
            if (idx !== -1) {
                page = Math.floor(idx / pageSize) + 1;
            }
            render();
            updateSelectionCount();

            closeCardDrawer();
            showToast("Card created for " + holderName + ".");
        });

        /* =====================================================
           Selection
           ===================================================== */
        function updateSelectionCount() {
            var count = tbody.querySelectorAll("[data-cmp-rowcheck]:checked").length;
            selectionCount.textContent = count + " card" + (count === 1 ? "" : "s") + " selected";
            updateCards.disabled = count === 0;
            updateSelectAllState();
        }

        tbody.addEventListener("change", function (e) {
            if (e.target && e.target.hasAttribute("data-cmp-rowcheck")) {
                updateSelectionCount();
            }
        });

        selectAll.addEventListener("change", function () {
            allRows().forEach(function (tr) {
                var c = tr.querySelector("[data-cmp-rowcheck]");
                if (c && !tr.hidden) {
                    c.checked = selectAll.checked;
                }
            });
            updateSelectionCount();
        });

        /* =====================================================
           Toast
           ===================================================== */
        var toastTimer = 0;

        function showToast(msg) {
            if (toastText) {
                toastText.textContent = msg;
            }
            toast.removeAttribute("hidden");
            window.clearTimeout(toastTimer);
            toastTimer = window.setTimeout(function () { toast.setAttribute("hidden", ""); }, 5000);
        }

        if (toastClose) {
            toastClose.addEventListener("click", function () {
                window.clearTimeout(toastTimer);
                toast.setAttribute("hidden", "");
            });
        }

        document.addEventListener("keydown", function (e) {
            if (e.key !== "Escape") {
                return;
            }
            if (!empDrawer.hasAttribute("hidden")) {
                closeEmployeeDrawer();
            } else if (!cardDrawer.hasAttribute("hidden")) {
                closeCardDrawer();
            }
        });

        render();
        updateSelectionCount();
    }

    function safeInit(root) {
        try {
            init(root);
        } catch (err) {
            /* Keep other components on the page working. */
            window.console.warn("VSC Card Listing could not start", err);
        }
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-cardlist]")) {
            safeInit(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-cardlist]"), safeInit);
        }
    }

    function boot() {
        scan(document);
        /* AEM editor re-renders components after edits; enhance the new markup. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Pagination — UI for any paged list (e.g. VSC Card Listing).
   The list owns the data; the pager only shows state and asks for pages.
     list  -> pager : CustomEvent "vsc:pager-render" { page, pages }
                      (also mirrored in data-cmp-pager-page / -pages)
     pager -> list  : CustomEvent "vsc:pager-change" { page }
   A pager that appears later (AEM editor drop/refresh) announces itself
   with "vsc:pager-ready" on document so lists can link to it. */
(function () {
    "use strict";

    function readInt(pager, name, fallback) {
        var n = parseInt(pager.getAttribute(name), 10);
        return n > 0 ? n : fallback;
    }

    function init(pager) {
        if (!pager || pager.__vscPagerInit) {
            return;
        }
        pager.__vscPagerInit = true;

        var prev = pager.querySelector("[data-cmp-pager-prev]");
        var next = pager.querySelector("[data-cmp-pager-next]");
        var status = pager.querySelector("[data-cmp-pager-status]");
        var state = { page: 1, pages: 1 };

        function update(page, pages) {
            var hadFocus = document.activeElement;
            state.pages = Math.max(1, pages);
            state.page = Math.min(Math.max(1, page), state.pages);
            var text = "Page " + state.page + " of " + state.pages;
            if (status.textContent !== text) {
                status.textContent = text;
            }
            prev.disabled = state.page <= 1;
            next.disabled = state.page >= state.pages;
            /* Keep keyboard focus inside the pager when a button disables itself. */
            if (hadFocus === prev && prev.disabled && !next.disabled) {
                next.focus();
            } else if (hadFocus === next && next.disabled && !prev.disabled) {
                prev.focus();
            }
        }

        function request(page) {
            pager.dispatchEvent(new CustomEvent("vsc:pager-change", {
                bubbles: true,
                detail: { page: page }
            }));
        }

        prev.addEventListener("click", function () {
            if (state.page > 1) {
                request(state.page - 1);
            }
        });
        next.addEventListener("click", function () {
            if (state.page < state.pages) {
                request(state.page + 1);
            }
        });

        pager.addEventListener("vsc:pager-render", function (e) {
            var d = e.detail || {};
            update(d.page || 1, d.pages || 1);
        });

        /* Pick up state a list may have written before this script ran. */
        update(readInt(pager, "data-cmp-pager-page", 1), readInt(pager, "data-cmp-pager-pages", 1));

        document.dispatchEvent(new CustomEvent("vsc:pager-ready", { detail: { pager: pager } }));
    }

    function scan(root) {
        if (root.matches && root.matches("[data-cmp-pager]")) {
            init(root);
        }
        if (root.querySelectorAll) {
            Array.prototype.forEach.call(root.querySelectorAll("[data-cmp-pager]"), init);
        }
    }

    function boot() {
        scan(document);
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Virtual Cards — list + "Add virtual cards" 3-step drawer (in-memory, no backend).
   Step 1 Details → Step 2 Employees → Step 3 Review + blocked merchant groups → Create.
   - The default row is server-rendered; new rows are built with DOM APIs
     (textContent only), so typed input can never inject markup.
   - Drawer and "Select employees" are modal dialogs: focus moves in, Tab is
     trapped, Esc closes, focus returns to the opener.
   - Errors: inline per field (aria-invalid + aria-describedby) plus an alert. */
(function () {
    "use strict";

    var SVG_NS = "http://www.w3.org/2000/svg";
    var FOCUSABLE = "a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), " +
        "textarea:not([disabled]), [tabindex]:not([tabindex='-1'])";
    var CURRENCY_CODES = { "US Dollar": "USD", "Euro": "EUR", "British Pound": "GBP" };
    var PAYMENT_TYPES = {
        "Single use virtual card": "Single-use",
        "Multi-use virtual card": "Multi-use",
        "Recurring virtual card": "Recurring"
    };

    /* ---------- helpers ---------- */
    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = text;
        }
        return node;
    }

    function svgPath(d, size) {
        var svg = document.createElementNS(SVG_NS, "svg");
        svg.setAttribute("viewBox", "0 0 12 12");
        svg.setAttribute("width", String(size));
        svg.setAttribute("height", String(size));
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("focusable", "false");
        var path = document.createElementNS(SVG_NS, "path");
        path.setAttribute("d", d);
        path.setAttribute("stroke", "currentColor");
        path.setAttribute("stroke-width", "2.25");
        path.setAttribute("fill", "none");
        path.setAttribute("stroke-linecap", "round");
        path.setAttribute("stroke-linejoin", "round");
        svg.appendChild(path);
        return svg;
    }

    function pad(n) {
        return n < 10 ? "0" + n : String(n);
    }

    function toIso(d) {
        return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
    }

    function parseIso(value) {
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value || "");
        return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
    }

    function toDisplay(value) {
        var d = parseIso(value);
        return d ? pad(d.getMonth() + 1) + "/" + pad(d.getDate()) + "/" + d.getFullYear() : "";
    }

    function addMonths(d, months) {
        return new Date(d.getFullYear(), d.getMonth() + months, d.getDate());
    }

    function initialsOf(name) {
        return name.split(/\s+/).filter(Boolean).map(function (p) { return p.charAt(0); })
            .join("").slice(0, 2).toUpperCase();
    }

    function money(value) {
        return Number(value).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    function focusables(container) {
        return Array.prototype.slice.call(container.querySelectorAll(FOCUSABLE)).filter(function (n) {
            return n.offsetWidth > 0 || n.offsetHeight > 0 || n === document.activeElement;
        });
    }

    function trapTab(container, e) {
        if (e.key !== "Tab") {
            return;
        }
        var items = focusables(container);
        if (!items.length) {
            e.preventDefault();
            return;
        }
        var first = items[0];
        var last = items[items.length - 1];
        if (e.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))) {
            e.preventDefault();
            last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
        }
    }

    /* ---------- component ---------- */
    function init(root) {
        if (!root || root.__vclistInit) {
            return;
        }
        root.__vclistInit = true;

        function q(sel) {
            return root.querySelector(sel);
        }

        var tbody = q('[data-cmp-tbody="vclist"]');
        var emptyMsg = q("[data-cmp-vclist-empty]");
        var status = q("[data-cmp-vclist-status]");
        var searchInput = q("#cmp-vclist-search");
        var findInput = q("#cmp-vclist-find");
        var findBtn = q("[data-cmp-vclist-find-btn]");
        var addTrigger = q("[data-cmp-vclist-add-trigger]");

        var drawer = q("[data-cmp-vclist-drawer]");
        var panel = drawer.querySelector(".cmp-drawer__panel");
        var form = q("[data-cmp-vcwiz-form]");
        var steps = Array.prototype.slice.call(root.querySelectorAll("[data-cmp-wizard-step]"));
        var backBtn = q("[data-cmp-vcwiz-back]");
        var nextBtn = q("[data-cmp-vcwiz-next]");
        var createBtn = q("[data-cmp-vcwiz-create]");
        var cancelBtn = q("[data-cmp-vcwiz-cancel]");
        var backLink = q("[data-cmp-vcwiz-back-link]");

        var empAdd = q("[data-cmp-vcemp-add]");
        var empModal = q("[data-cmp-vcemp-modal]");
        var empDialog = empModal.querySelector(".cmp-vcemp-modal__dialog");
        var empTbody = q('[data-cmp-tbody="vcemp"]');
        var empTableWrap = q(".cmp-vcwiz__emp-table");
        var empEmpty = q("[data-cmp-vcemp-empty]");
        var empSummary = q("[data-cmp-vcemp-summary]");

        var toast = q('[data-cmp-toast="vclist"]');
        var toastText = toast ? toast.querySelector("[data-cmp-toast-text]") : null;
        var toastClose = toast ? toast.querySelector("[data-cmp-toast-close]") : null;

        var f = {
            description: form.elements.description,
            spendLimit: form.elements.spendLimit,
            startDate: form.elements.startDate,
            endDate: form.elements.endDate,
            currency: form.elements.currency,
            spendType: form.elements.spendType
        };

        var currentStep = 1;
        var opener = null;
        var empOpener = null;
        var selected = [];
        var data = {};

        /* =====================================================
           List: search / find
           ===================================================== */
        function rows() {
            return Array.prototype.slice.call(tbody.querySelectorAll("tr"));
        }

        function applySearch(term, announce) {
            var needle = (term || "").trim().toLowerCase();
            var shown = 0;
            rows().forEach(function (tr) {
                var match = !needle || tr.textContent.toLowerCase().indexOf(needle) !== -1;
                tr.hidden = !match;
                if (match) {
                    shown += 1;
                }
            });
            emptyMsg.hidden = shown > 0;
            if (announce) {
                status.textContent = shown + " virtual card" + (shown === 1 ? "" : "s") + " found";
            }
        }

        searchInput.addEventListener("input", function () {
            applySearch(searchInput.value, false);
        });
        findBtn.addEventListener("click", function () {
            applySearch(findInput.value, true);
        });
        findInput.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                applySearch(findInput.value, true);
            }
        });

        tbody.addEventListener("click", function (e) {
            var link = e.target.closest ? e.target.closest(".cmp-vclist__detail") : null;
            if (link && link.getAttribute("href") === "#") {
                e.preventDefault();
            }
        });

        function buildRow(r) {
            var tr = el("tr");
            var tdAvatar = el("td");
            var avatar = el("span", "cmp-avatar", r.initials);
            avatar.setAttribute("aria-hidden", "true");
            tdAvatar.appendChild(avatar);

            var tdStatus = el("td");
            var pill = el("span", "cmp-pill cmp-pill--active");
            pill.appendChild(el("span", "cmp-pill__label", "Active"));
            tdStatus.appendChild(pill);

            var tdDetail = el("td", "cmp-vclist__details");
            var link = el("a", "cmp-vclist__detail");
            link.href = "#";
            link.setAttribute("aria-label", "View " + r.name + " virtual card details");
            link.appendChild(svgPath("M4 1.5L8.5 6 4 10.5", 11));
            tdDetail.appendChild(link);

            tr.appendChild(tdAvatar);
            tr.appendChild(el("td", "cmp-vclist__name", r.name));
            tr.appendChild(el("td", null, r.description));
            tr.appendChild(tdStatus);
            tr.appendChild(el("td", null, r.type));
            tr.appendChild(el("td", null, r.dateRange));
            tr.appendChild(el("td", "cmp-vclist__limit", r.limit));
            tr.appendChild(tdDetail);
            return tr;
        }

        function insertRow(tr, name) {
            var before = null;
            rows().some(function (row) {
                var cell = row.querySelector(".cmp-vclist__name");
                if (cell && cell.textContent.localeCompare(name, undefined, { sensitivity: "base" }) > 0) {
                    before = row;
                    return true;
                }
                return false;
            });
            tbody.insertBefore(tr, before);
        }

        /* =====================================================
           Drawer (modal dialog)
           ===================================================== */
        function placeDrawer() {
            /* Start below the site header, as in the Figma. */
            var header = document.querySelector(".cmp-header, .cmp-vscheader");
            var top = 0;
            if (header) {
                top = Math.max(0, Math.round(header.getBoundingClientRect().bottom));
            }
            drawer.style.setProperty("--cmp-vclist-drawer-top", top + "px");
        }

        function resetWizard() {
            form.reset();
            var today = new Date();
            var max = toIso(addMonths(today, 36));
            f.startDate.value = toIso(today);
            f.endDate.value = toIso(addMonths(today, 1));
            f.startDate.min = toIso(today);
            f.startDate.max = max;
            f.endDate.min = toIso(today);
            f.endDate.max = max;
            form.querySelectorAll("[aria-invalid]").forEach(function (n) { n.removeAttribute("aria-invalid"); });
            form.querySelectorAll(".cmp-field__err, [data-cmp-vcwiz-error]").forEach(function (n) { n.hidden = true; });
            root.querySelectorAll("[data-cmp-mccsel] input").forEach(function (c) { c.checked = false; });
            selected = [];
            data = {};
            renderEmployees();
        }

        function openDrawer() {
            opener = document.activeElement;
            resetWizard();
            placeDrawer();
            drawer.hidden = false;
            setStep(1, false);
            f.description.focus();
        }

        function closeDrawer() {
            closeEmpModal(false);
            drawer.hidden = true;
            if (opener && opener.focus) {
                opener.focus();
            }
        }

        function setStep(n, moveFocus) {
            currentStep = n;
            drawer.setAttribute("data-step", String(n));
            steps.forEach(function (s) {
                s.hidden = Number(s.getAttribute("data-cmp-wizard-step")) !== n;
            });
            backBtn.hidden = n !== 2;
            nextBtn.hidden = n === 3;
            createBtn.hidden = n !== 3;
            cancelBtn.hidden = n !== 3;
            panel.scrollTop = 0;
            if (moveFocus) {
                var title = root.querySelector("#cmp-vcwiz-step" + n + "-title");
                if (title) {
                    title.setAttribute("tabindex", "-1");
                    title.focus();
                }
            }
        }

        addTrigger.addEventListener("click", openDrawer);
        q("[data-cmp-vclist-close]").addEventListener("click", closeDrawer);
        q("[data-cmp-vclist-backdrop]").addEventListener("click", closeDrawer);
        cancelBtn.addEventListener("click", closeDrawer);
        window.addEventListener("resize", function () {
            if (!drawer.hidden) {
                placeDrawer();
            }
        });

        /* Date picker buttons (dateinput component) */
        root.querySelectorAll("[data-cmp-date-picker]").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var input = document.getElementById(btn.getAttribute("data-cmp-date-picker"));
                if (!input) {
                    return;
                }
                input.focus();
                if (typeof input.showPicker === "function") {
                    try {
                        input.showPicker();
                    } catch (err) {
                        /* Picker not allowed here; the focused input still accepts typing. */
                    }
                }
            });
        });

        /* =====================================================
           Validation
           ===================================================== */
        function setError(input, message) {
            var err = document.getElementById(input.id + "-err");
            if (message) {
                input.setAttribute("aria-invalid", "true");
                if (err) {
                    err.textContent = message;
                    err.hidden = false;
                }
            } else {
                input.removeAttribute("aria-invalid");
                if (err) {
                    err.hidden = true;
                }
            }
            return !message;
        }

        /* Clear a field's error as soon as the user corrects it. */
        form.addEventListener("input", function (e) {
            if (e.target && e.target.getAttribute && e.target.getAttribute("aria-invalid") === "true") {
                setError(e.target, "");
            }
        });
        form.addEventListener("change", function (e) {
            if (e.target && e.target.getAttribute && e.target.getAttribute("aria-invalid") === "true") {
                setError(e.target, "");
            }
        });

        function stepAlert(n, message) {
            var box = root.querySelector('[data-cmp-vcwiz-error="' + n + '"]');
            if (!box) {
                return;
            }
            box.textContent = message || "";
            box.hidden = !message;
        }

        function validateDetails() {
            var invalid = [];
            var today = parseIso(toIso(new Date()));
            var maxEnd = addMonths(today, 36);
            var desc = f.description.value.trim();
            var amount = f.spendLimit.value.replace(/,/g, "").trim();
            var start = parseIso(f.startDate.value);
            var end = parseIso(f.endDate.value);

            if (!setError(f.description, desc ? "" : "Enter a description.")) {
                invalid.push(f.description);
            }
            var amountOk = /^\d+(\.\d{1,2})?$/.test(amount) && Number(amount) > 0;
            if (!setError(f.spendLimit, amountOk ? "" : "Enter a spend limit greater than 0, for example 250.00.")) {
                invalid.push(f.spendLimit);
            }
            if (!setError(f.startDate, start ? "" : "Enter a start date.")) {
                invalid.push(f.startDate);
            }
            var endMsg = "";
            if (!end) {
                endMsg = "Enter an end date.";
            } else if (start && end < start) {
                endMsg = "The end date must be on or after the start date.";
            } else if (end > maxEnd) {
                endMsg = "The end date must be within 3 years from today.";
            }
            if (!setError(f.endDate, endMsg)) {
                invalid.push(f.endDate);
            }
            [f.currency, f.spendType].forEach(function (sel) {
                if (!setError(sel, sel.value ? "" : "Please choose an option.")) {
                    invalid.push(sel);
                }
            });

            if (invalid.length) {
                stepAlert(1, "Please fix " + invalid.length + " highlighted field" +
                    (invalid.length === 1 ? "" : "s") + ".");
                invalid[0].focus();
                return false;
            }
            stepAlert(1, "");
            data = {
                description: desc,
                amount: Number(amount),
                currency: f.currency.value,
                currencyCode: CURRENCY_CODES[f.currency.value] || "USD",
                startDate: f.startDate.value,
                endDate: f.endDate.value,
                spendType: f.spendType.value,
                paymentType: PAYMENT_TYPES[f.spendType.value] || "Single-use"
            };
            return true;
        }

        function fillSummary() {
            var values = {
                description: data.description,
                spendLimit: money(data.amount) + " " + data.currencyCode,
                dateRange: toDisplay(data.startDate) + " - " + toDisplay(data.endDate),
                paymentType: data.paymentType,
                spendType: data.spendType
            };
            root.querySelectorAll("[data-cmp-vcsum]").forEach(function (node) {
                node.textContent = values[node.getAttribute("data-cmp-vcsum")] || "";
            });
        }

        /* =====================================================
           Employees
           ===================================================== */
        function renderEmployees() {
            empTbody.textContent = "";
            empSummary.textContent = "";
            selected.forEach(function (emp) {
                var tr = el("tr");
                var tdName = el("td");
                var holder = el("span", "cmp-vcwiz__emp");
                var avatar = el("span", "cmp-avatar", initialsOf(emp.name));
                avatar.setAttribute("aria-hidden", "true");
                holder.appendChild(avatar);
                holder.appendChild(el("span", null, emp.name));
                tdName.appendChild(holder);

                var tdAction = el("td", "cmp-vcwiz__emp-action");
                var remove = el("button", "cmp-btn cmp-vcwiz__outline cmp-vcwiz__remove");
                remove.type = "button";
                remove.setAttribute("aria-label", "Remove " + emp.name);
                remove.appendChild(svgPath("M2.5 2.5l7 7M9.5 2.5l-7 7", 9));
                remove.appendChild(el("span", null, "Remove"));
                remove.addEventListener("click", function () {
                    selected = selected.filter(function (s) { return s.id !== emp.id; });
                    renderEmployees();
                    status.textContent = emp.name + " removed";
                    empAdd.focus();
                });
                tdAction.appendChild(remove);

                tr.appendChild(tdName);
                tr.appendChild(el("td", null, emp.id));
                tr.appendChild(tdAction);
                empTbody.appendChild(tr);

                var li = el("li", "cmp-vcwiz__emp");
                var av2 = el("span", "cmp-avatar", initialsOf(emp.name));
                av2.setAttribute("aria-hidden", "true");
                li.appendChild(av2);
                li.appendChild(el("span", null, emp.name));
                empSummary.appendChild(li);
            });
            var none = selected.length === 0;
            empTableWrap.hidden = none;
            empEmpty.hidden = !none;
            if (!none) {
                stepAlert(2, "");
            }
        }

        function openEmpModal() {
            empOpener = document.activeElement;
            empModal.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
                cb.checked = selected.some(function (s) { return s.id === cb.value; });
            });
            empModal.hidden = false;
            var first = empModal.querySelector('input[type="checkbox"]');
            if (first) {
                first.focus();
            }
        }

        function closeEmpModal(restore) {
            if (empModal.hidden) {
                return;
            }
            empModal.hidden = true;
            if (restore !== false && empOpener && empOpener.focus) {
                empOpener.focus();
            }
        }

        empAdd.addEventListener("click", openEmpModal);
        q("[data-cmp-vcemp-close]").addEventListener("click", function () { closeEmpModal(true); });
        q("[data-cmp-vcemp-cancel]").addEventListener("click", function () { closeEmpModal(true); });
        q("[data-cmp-vcemp-backdrop]").addEventListener("click", function () { closeEmpModal(true); });
        q("[data-cmp-vcemp-confirm]").addEventListener("click", function () {
            selected = [];
            empModal.querySelectorAll('input[type="checkbox"]:checked').forEach(function (cb) {
                selected.push({ id: cb.value, name: cb.getAttribute("data-name") || cb.value });
            });
            renderEmployees();
            status.textContent = selected.length + " employee" + (selected.length === 1 ? "" : "s") + " selected";
            closeEmpModal(true);
        });

        /* =====================================================
           Navigation + create
           ===================================================== */
        nextBtn.addEventListener("click", function () {
            if (currentStep === 1) {
                if (validateDetails()) {
                    fillSummary();
                    setStep(2, true);
                }
            } else if (currentStep === 2) {
                if (!selected.length) {
                    stepAlert(2, "Select at least one employee to receive the virtual card.");
                    empAdd.focus();
                    return;
                }
                setStep(3, true);
            }
        });
        backBtn.addEventListener("click", function () {
            setStep(1, true);
        });
        backLink.addEventListener("click", function () {
            setStep(2, true);
        });

        var toastTimer = 0;

        function showToast(message) {
            if (!toast) {
                return;
            }
            if (toastText && message) {
                toastText.textContent = message;
            }
            toast.hidden = false;
            window.clearTimeout(toastTimer);
            toastTimer = window.setTimeout(function () { toast.hidden = true; }, 8000);
        }

        if (toastClose) {
            toastClose.addEventListener("click", function () {
                window.clearTimeout(toastTimer);
                toast.hidden = true;
            });
        }

        createBtn.addEventListener("click", function () {
            var snapshot = data;
            var people = selected.slice();
            closeDrawer();
            showToast("Virtual card is being created. This may take some time.");
            /* Creation is not instant; the card appears in the list shortly after. */
            window.setTimeout(function () {
                people.forEach(function (emp) {
                    insertRow(buildRow({
                        initials: initialsOf(emp.name),
                        name: emp.name,
                        description: snapshot.description,
                        type: snapshot.paymentType,
                        dateRange: toDisplay(snapshot.startDate) + " - " + toDisplay(snapshot.endDate),
                        limit: money(snapshot.amount) + " Spend limit (" + snapshot.currencyCode + ")"
                    }), emp.name);
                });
                applySearch(searchInput.value, false);
                status.textContent = people.length + " virtual card" + (people.length === 1 ? "" : "s") +
                    " added to the list";
            }, 1500);
        });

        /* =====================================================
           Keyboard: Esc + focus trap
           ===================================================== */
        document.addEventListener("keydown", function (e) {
            if (drawer.hidden) {
                return;
            }
            if (e.key === "Escape" || e.key === "Esc") {
                e.preventDefault();
                if (!empModal.hidden) {
                    closeEmpModal(true);
                } else {
                    closeDrawer();
                }
                return;
            }
            trapTab(empModal.hidden ? panel : empDialog, e);
        });

        renderEmployees();
    }

    function safeInit(root) {
        try {
            init(root);
        } catch (err) {
            window.console.warn("VSC Virtual Cards could not start", err);
        }
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-vclist]")) {
            safeInit(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-vclist]"), safeInit);
        }
    }

    function boot() {
        scan(document);
        /* AEM editor re-renders components after edits; enhance the new markup. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Expense Categories (Charge Codes) — in-memory, no backend.
   Toolbar: Search (filter bar) · Create (dialog) · Group Action (selected rows) ·
   Export (xlsx / csv / pdf / png via window.VSC.exporter) · columns · pager.
   Rows: Edit (prefilled dialog) · View details (read-only dialog).
   Default rows are server-rendered; new rows are built with DOM APIs only
   (textContent), so typed text can never inject markup. */
(function () {
    "use strict";

    var SVG_NS = "http://www.w3.org/2000/svg";
    var FOCUSABLE = "a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), " +
        "textarea:not([disabled]), [tabindex]:not([tabindex='-1'])";
    var DEFAULT_GROUP = "All Codes";

    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = text;
        }
        return node;
    }

    function icon(paths) {
        var svg = document.createElementNS(SVG_NS, "svg");
        svg.setAttribute("viewBox", "0 0 16 16");
        svg.setAttribute("width", "13");
        svg.setAttribute("height", "13");
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("focusable", "false");
        paths.forEach(function (p) {
            var node = document.createElementNS(SVG_NS, p.tag);
            Object.keys(p.attrs).forEach(function (k) { node.setAttribute(k, p.attrs[k]); });
            svg.appendChild(node);
        });
        return svg;
    }

    function plural(n, word) {
        return n + " " + word + (n === 1 ? "" : "s");
    }

    function compareValues(a, b) {
        return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" });
    }

    function init(root) {
        if (!root || root.__expcatInit) {
            return;
        }
        root.__expcatInit = true;

        function q(sel) {
            return root.querySelector(sel);
        }

        var tbody = q("[data-cmp-expcat-tbody]");
        var table = q(".cmp-expcat__table");
        var emptyMsg = q("[data-cmp-expcat-empty]");
        var status = q("[data-cmp-expcat-status]");
        var selectionText = q("[data-cmp-expcat-selection]");
        var selectAll = q("[data-cmp-expcat-selectall]");

        var searchToggle = q("[data-cmp-expcat-search-toggle]");
        var searchBar = q("#cmp-expcat-search");
        var qInput = q("#cmp-expcat-q");
        var fType = q("#cmp-expcat-ftype");
        var fStatus = q("#cmp-expcat-fstatus");

        var groupBtn = q('[data-cmp-expcat-menu="group"]');
        var pageSelect = q("[data-cmp-expcat-page]");
        var pageCount = q("[data-cmp-expcat-pagecount]");
        var prevBtn = q("[data-cmp-expcat-prev]");
        var nextBtn = q("[data-cmp-expcat-next]");
        var colBtn = q("[data-cmp-expcat-columns-btn]");
        var colPanel = q("#cmp-expcat-columns");

        var modal = q("[data-cmp-expcat-modal]");
        var dialog = modal.querySelector(".cmp-expcat__dialog");
        var dialogTitle = q("[data-cmp-expcat-dialog-title]");
        var form = q("[data-cmp-expcat-form]");
        var formError = q("[data-cmp-expcat-error]");
        var saveBtn = q("[data-cmp-expcat-save]");
        var cancelBtn = q("[data-cmp-expcat-cancel]");
        var multi = form.querySelector("[data-cmp-multiselect]");

        var toast = q('[data-cmp-toast="expcat"]');
        var toastText = toast ? toast.querySelector("[data-cmp-toast-text]") : null;

        var f = {
            type: form.elements.type,
            value: form.elements.value,
            description: form.elements.description,
            advanced: form.elements.advancedDescription,
            parentType: form.elements.parentType,
            parentValue: form.elements.parentValue
        };

        var pageSize = parseInt(root.getAttribute("data-cmp-expcat-page-size"), 10);
        if (!(pageSize > 0)) {
            pageSize = 25;
        }
        var page = 1;
        var mode = "create";
        var editing = null;
        var opener = null;

        /* =====================================================
           Row data
           ===================================================== */
        function rows() {
            return Array.prototype.slice.call(tbody.querySelectorAll("[data-cmp-expcat-row]"));
        }

        function groupsOf(tr) {
            return (tr.getAttribute("data-groups") || "").split("|").filter(Boolean);
        }

        function dataOf(tr) {
            return {
                value: tr.getAttribute("data-value") || "",
                type: tr.getAttribute("data-type") || "",
                description: tr.querySelector('[data-col="description"]').textContent,
                status: tr.getAttribute("data-status") || "Active",
                groups: groupsOf(tr),
                advanced: tr.getAttribute("data-adv") || "",
                parentType: tr.getAttribute("data-ptype") || "",
                parentValue: tr.getAttribute("data-pvalue") || ""
            };
        }

        function writeRow(tr, d) {
            tr.setAttribute("data-value", d.value);
            tr.setAttribute("data-type", d.type);
            tr.setAttribute("data-status", d.status);
            tr.setAttribute("data-groups", d.groups.join("|"));
            tr.setAttribute("data-adv", d.advanced);
            tr.setAttribute("data-ptype", d.parentType);
            tr.setAttribute("data-pvalue", d.parentValue);
            tr.querySelector('[data-col="value"]').textContent = d.value;
            tr.querySelector('[data-col="type"]').textContent = d.type;
            tr.querySelector('[data-col="description"]').textContent = d.description;
            tr.querySelector('[data-col="groups"]').textContent = String(d.groups.length);
            tr.classList.toggle("is-inactive", d.status === "Inactive");
            tr.querySelector("[data-cmp-expcat-rowcheck]").setAttribute("aria-label", "Select " + d.value);
            tr.querySelector("[data-cmp-expcat-edit]").setAttribute("aria-label", "Edit " + d.value);
            tr.querySelector("[data-cmp-expcat-view]").setAttribute("aria-label", "View " + d.value + " details");
        }

        /* Same markup as the HTL row template. */
        function buildRow(d) {
            var tr = el("tr");
            tr.setAttribute("data-cmp-expcat-row", "");
            var tdCheck = el("td", "cmp-expcat__check");
            var check = el("input");
            check.type = "checkbox";
            check.setAttribute("data-cmp-expcat-rowcheck", "");
            tdCheck.appendChild(check);
            tr.appendChild(tdCheck);
            ["value", "type", "description", "groups"].forEach(function (col) {
                var td = el("td", col === "value" ? "cmp-expcat__value" : null);
                td.setAttribute("data-col", col);
                tr.appendChild(td);
            });
            var tdActions = el("td", "cmp-expcat__actions");
            var edit = el("button", "cmp-expcat__icon");
            edit.type = "button";
            edit.setAttribute("data-cmp-expcat-edit", "");
            edit.appendChild(icon([
                { tag: "path", attrs: { d: "M11.3 1.7l3 3-8.6 8.6-3.9.9.9-3.9z", fill: "currentColor" } }
            ]));
            var view = el("button", "cmp-expcat__icon");
            view.type = "button";
            view.setAttribute("data-cmp-expcat-view", "");
            view.appendChild(icon([
                { tag: "rect", attrs: { x: "2.5", y: "1.5", width: "11", height: "13", rx: "1", fill: "none",
                    stroke: "currentColor", "stroke-width": "1.5" } },
                { tag: "path", attrs: { d: "M5 5h6M5 8h6M5 11h4", stroke: "currentColor", "stroke-width": "1.5" } }
            ]));
            tdActions.appendChild(edit);
            tdActions.appendChild(view);
            tr.appendChild(tdActions);
            writeRow(tr, d);
            return tr;
        }

        function insertSorted(tr) {
            var value = tr.getAttribute("data-value");
            var before = null;
            rows().some(function (row) {
                if (row !== tr && compareValues(row.getAttribute("data-value"), value) > 0) {
                    before = row;
                    return true;
                }
                return false;
            });
            tbody.insertBefore(tr, before);
        }

        /* =====================================================
           Filter + pagination + selection
           ===================================================== */
        function matches(tr) {
            var term = qInput.value.trim().toLowerCase();
            var d = dataOf(tr);
            if (term && (d.value + " " + d.description + " " + d.type).toLowerCase().indexOf(term) === -1) {
                return false;
            }
            if (fType.value && d.type !== fType.value) {
                return false;
            }
            if (fStatus.value && d.status !== fStatus.value) {
                return false;
            }
            return true;
        }

        function filtered() {
            return rows().filter(matches);
        }

        function checkedRows() {
            return rows().filter(function (tr) { return tr.querySelector("[data-cmp-expcat-rowcheck]").checked; });
        }

        function updateSelection() {
            var n = checkedRows().length;
            selectionText.textContent = n ? plural(n, "charge code") + " selected" : "No charge codes selected";
            groupBtn.disabled = n === 0;
            var onPage = rows().filter(function (tr) { return !tr.hidden; });
            var checkedOnPage = onPage.filter(function (tr) {
                return tr.querySelector("[data-cmp-expcat-rowcheck]").checked;
            }).length;
            selectAll.checked = onPage.length > 0 && checkedOnPage === onPage.length;
            selectAll.indeterminate = checkedOnPage > 0 && checkedOnPage < onPage.length;
            selectAll.disabled = onPage.length === 0;
        }

        function render() {
            var list = filtered();
            var pages = Math.max(1, Math.ceil(list.length / pageSize));
            page = Math.min(Math.max(1, page), pages);
            var start = (page - 1) * pageSize;
            rows().forEach(function (tr) {
                var idx = list.indexOf(tr);
                tr.hidden = idx === -1 || idx < start || idx >= start + pageSize;
            });
            emptyMsg.hidden = list.length > 0;

            if (pageSelect.options.length !== pages) {
                pageSelect.textContent = "";
                for (var i = 1; i <= pages; i++) {
                    var opt = el("option", null, "Page " + i);
                    opt.value = String(i);
                    pageSelect.appendChild(opt);
                }
            }
            pageSelect.value = String(page);
            pageCount.textContent = "of " + pages;
            prevBtn.disabled = page <= 1;
            nextBtn.disabled = page >= pages;
            updateSelection();
            return list;
        }

        function announce(text) {
            status.textContent = "";
            window.setTimeout(function () { status.textContent = text; }, 30);
        }

        function goToRow(tr) {
            var idx = filtered().indexOf(tr);
            if (idx !== -1) {
                page = Math.floor(idx / pageSize) + 1;
            }
            render();
        }

        tbody.addEventListener("change", function (e) {
            if (e.target && e.target.hasAttribute("data-cmp-expcat-rowcheck")) {
                updateSelection();
            }
        });
        selectAll.addEventListener("change", function () {
            rows().forEach(function (tr) {
                if (!tr.hidden) {
                    tr.querySelector("[data-cmp-expcat-rowcheck]").checked = selectAll.checked;
                }
            });
            updateSelection();
        });

        pageSelect.addEventListener("change", function () {
            page = parseInt(pageSelect.value, 10) || 1;
            render();
        });
        prevBtn.addEventListener("click", function () {
            page -= 1;
            render();
            if (prevBtn.disabled) {
                nextBtn.focus();
            }
        });
        nextBtn.addEventListener("click", function () {
            page += 1;
            render();
            if (nextBtn.disabled) {
                prevBtn.focus();
            }
        });

        /* Search bar */
        searchToggle.addEventListener("click", function () {
            var open = searchBar.hidden;
            searchBar.hidden = !open;
            searchToggle.setAttribute("aria-expanded", open ? "true" : "false");
            if (open) {
                qInput.focus();
            }
        });
        function onFilter() {
            page = 1;
            var n = render().length;
            announce(plural(n, "charge code") + " found");
        }
        qInput.addEventListener("input", onFilter);
        fType.addEventListener("change", onFilter);
        fStatus.addEventListener("change", onFilter);
        q("[data-cmp-expcat-clear]").addEventListener("click", function () {
            qInput.value = "";
            fType.value = "";
            fStatus.value = "";
            onFilter();
            qInput.focus();
        });

        /* =====================================================
           Menus (Group Action, Export) — ARIA menu pattern
           ===================================================== */
        var openMenu = null;

        function menuItems(menu) {
            return Array.prototype.slice.call(menu.querySelectorAll('[role="menuitem"]'));
        }

        function closeMenu(focusButton) {
            if (!openMenu) {
                return;
            }
            openMenu.menu.hidden = true;
            openMenu.button.setAttribute("aria-expanded", "false");
            if (focusButton) {
                openMenu.button.focus();
            }
            openMenu = null;
        }

        function openMenuFor(button, focusLast) {
            closeMenu(false);
            closePopover();
            var menu = document.getElementById(button.getAttribute("aria-controls"));
            menu.hidden = false;
            button.setAttribute("aria-expanded", "true");
            openMenu = { button: button, menu: menu };
            var items = menuItems(menu);
            if (items.length) {
                items[focusLast ? items.length - 1 : 0].focus();
            }
        }

        root.querySelectorAll("[data-cmp-expcat-menu]").forEach(function (button) {
            button.addEventListener("click", function (e) {
                e.stopPropagation();
                if (openMenu && openMenu.button === button) {
                    closeMenu(true);
                } else {
                    openMenuFor(button, false);
                }
            });
            button.addEventListener("keydown", function (e) {
                if (e.key === "ArrowDown" || e.key === "ArrowUp") {
                    e.preventDefault();
                    openMenuFor(button, e.key === "ArrowUp");
                }
            });
            var menu = document.getElementById(button.getAttribute("aria-controls"));
            menu.addEventListener("keydown", function (e) {
                var items = menuItems(menu);
                var idx = items.indexOf(document.activeElement);
                var target = null;
                if (e.key === "ArrowDown") {
                    target = items[(idx + 1) % items.length];
                } else if (e.key === "ArrowUp") {
                    target = items[(idx - 1 + items.length) % items.length];
                } else if (e.key === "Home") {
                    target = items[0];
                } else if (e.key === "End") {
                    target = items[items.length - 1];
                } else if (e.key === "Escape" || e.key === "Esc") {
                    e.preventDefault();
                    closeMenu(true);
                    return;
                } else if (e.key === "Tab") {
                    closeMenu(false);
                    return;
                }
                if (target) {
                    e.preventDefault();
                    target.focus();
                }
            });
        });

        /* Columns popover */
        function closePopover() {
            if (!colPanel.hidden) {
                colPanel.hidden = true;
                colBtn.setAttribute("aria-expanded", "false");
            }
        }
        colBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            closeMenu(false);
            var open = colPanel.hidden;
            colPanel.hidden = !open;
            colBtn.setAttribute("aria-expanded", open ? "true" : "false");
            if (open) {
                colPanel.querySelector("input").focus();
            }
        });
        colPanel.addEventListener("keydown", function (e) {
            if (e.key === "Escape" || e.key === "Esc") {
                e.preventDefault();
                closePopover();
                colBtn.focus();
            }
        });
        colPanel.addEventListener("change", function (e) {
            var col = e.target.value;
            table.classList.toggle("cmp-expcat__table--hide-" + col, !e.target.checked);
        });

        document.addEventListener("click", function (e) {
            if (openMenu && !openMenu.menu.contains(e.target)) {
                closeMenu(false);
            }
            if (!colPanel.hidden && !colPanel.contains(e.target) && e.target !== colBtn) {
                closePopover();
            }
        });

        /* Group actions */
        root.querySelectorAll("[data-cmp-expcat-group]").forEach(function (item) {
            item.addEventListener("click", function () {
                var action = item.getAttribute("data-cmp-expcat-group");
                var targets = checkedRows();
                closeMenu(true);
                if (!targets.length) {
                    return;
                }
                if (action === "delete") {
                    /* eslint-disable-next-line no-alert */
                    if (!window.confirm("Delete " + plural(targets.length, "charge code") + "?")) {
                        return;
                    }
                    targets.forEach(function (tr) { tr.parentNode.removeChild(tr); });
                    render();
                    announce(plural(targets.length, "charge code") + " deleted");
                    showToast("Success", plural(targets.length, "charge code") + " deleted.");
                    return;
                }
                targets.forEach(function (tr) {
                    var d = dataOf(tr);
                    if (action.indexOf("add:") === 0) {
                        var g = action.slice(4);
                        if (d.groups.indexOf(g) === -1) {
                            d.groups.push(g);
                        }
                    } else if (action === "reset") {
                        d.groups = [DEFAULT_GROUP];
                    } else if (action.indexOf("status:") === 0) {
                        d.status = action.slice(7);
                    }
                    writeRow(tr, d);
                });
                render();
                var msg = plural(targets.length, "charge code") + " updated";
                announce(msg);
                showToast("Success", msg + ".");
            });
        });

        /* Export (visible filter, all pages) */
        root.querySelectorAll("[data-cmp-expcat-export]").forEach(function (item) {
            item.addEventListener("click", function () {
                var format = item.getAttribute("data-cmp-expcat-export");
                closeMenu(true);
                var data = filtered().map(dataOf).map(function (d) {
                    return [d.value, d.type, d.description, String(d.groups.length), d.groups.join(", "), d.status];
                });
                var exporter = window.VSC && window.VSC.exporter;
                var ok = exporter && exporter.download(format, {
                    filename: "charge-codes",
                    title: "Charge Codes",
                    columns: ["Value", "Type", "Description", "Group(s)", "Charge groups", "Status"],
                    rows: data
                });
                announce(ok ? plural(data.length, "charge code") + " exported as " + item.textContent.trim() :
                    "Export is not available");
            });
        });

        /* =====================================================
           Dialog: create / edit / view
           ===================================================== */
        function groupBoxes() {
            return Array.prototype.slice.call(multi.querySelectorAll('input[type="checkbox"]'));
        }

        function fillParentValues(selected) {
            var type = f.parentType.value;
            f.parentValue.textContent = "";
            var first = el("option", null, type ? "Select a parent value" : "Select a parent type first");
            first.value = "";
            f.parentValue.appendChild(first);
            if (type) {
                rows().map(dataOf).filter(function (d) {
                    return d.type === type && (!editing || d.value !== editing.getAttribute("data-value"));
                }).forEach(function (d) {
                    var opt = el("option", null, d.value + " - " + d.description);
                    opt.value = d.value;
                    f.parentValue.appendChild(opt);
                });
            }
            f.parentValue.value = selected || "";
            f.parentValue.disabled = !type || mode === "view";
        }
        f.parentType.addEventListener("change", function () { fillParentValues(""); });

        function clearErrors() {
            formError.hidden = true;
            form.querySelectorAll("[aria-invalid]").forEach(function (n) { n.removeAttribute("aria-invalid"); });
            form.querySelectorAll(".cmp-field__err").forEach(function (n) { n.hidden = true; });
        }

        function setError(input, message) {
            var err = document.getElementById(input.id + "-err");
            if (message) {
                input.setAttribute("aria-invalid", "true");
                if (err) {
                    err.textContent = message;
                    err.hidden = false;
                }
            } else {
                input.removeAttribute("aria-invalid");
                if (err) {
                    err.hidden = true;
                }
            }
            return !message;
        }

        function clearFixed(e) {
            if (e.target.getAttribute && e.target.getAttribute("aria-invalid") === "true") {
                setError(e.target, "");
                if (!form.querySelector('[aria-invalid="true"]')) {
                    formError.hidden = true;
                }
            }
        }
        form.addEventListener("input", clearFixed);
        form.addEventListener("change", clearFixed);

        function openDialog(newMode, tr) {
            mode = newMode;
            editing = tr || null;
            opener = document.activeElement;
            closeMenu(false);
            closePopover();
            form.reset();
            clearErrors();
            var d = tr ? dataOf(tr) : { value: "", type: "", description: "", status: "Active",
                groups: [DEFAULT_GROUP], advanced: "", parentType: "", parentValue: "" };
            f.type.value = d.type;
            f.value.value = d.value;
            f.description.value = d.description;
            f.advanced.value = d.advanced;
            form.querySelectorAll('input[name="status"]').forEach(function (r) { r.checked = r.value === d.status; });
            groupBoxes().forEach(function (b) { b.checked = d.groups.indexOf(b.value) !== -1; });
            f.parentType.value = d.parentType;

            var readOnly = mode === "view";
            Array.prototype.forEach.call(form.elements, function (n) {
                if (n.tagName !== "BUTTON") {
                    n.disabled = readOnly;
                }
            });
            fillParentValues(d.parentValue);
            multi.dispatchEvent(new CustomEvent("vsc:multiselect-sync"));

            dialogTitle.textContent = mode === "edit" ? "Edit Charge Code" :
                mode === "view" ? "Charge Code Details" : "Create New Charge Code";
            saveBtn.hidden = readOnly;
            cancelBtn.textContent = readOnly ? "Close" : "Cancel";
            modal.hidden = false;
            /* In the AEM editor the page frame is as tall as the page: bring the dialog into view. */
            if (dialog.scrollIntoView) {
                dialog.scrollIntoView({ block: "nearest" });
            }
            (readOnly ? cancelBtn : f.type).focus({ preventScroll: true });
        }

        function closeDialog() {
            modal.hidden = true;
            if (opener && opener.focus && document.documentElement.contains(opener)) {
                opener.focus();
            }
        }

        q("[data-cmp-expcat-create]").addEventListener("click", function () { openDialog("create", null); });
        q("[data-cmp-expcat-close]").addEventListener("click", closeDialog);
        q("[data-cmp-expcat-backdrop]").addEventListener("click", closeDialog);
        cancelBtn.addEventListener("click", closeDialog);

        tbody.addEventListener("click", function (e) {
            var btn = e.target.closest ? e.target.closest("[data-cmp-expcat-edit], [data-cmp-expcat-view]") : null;
            if (!btn) {
                return;
            }
            var tr = btn.closest("[data-cmp-expcat-row]");
            openDialog(btn.hasAttribute("data-cmp-expcat-edit") ? "edit" : "view", tr);
        });

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            if (mode === "view") {
                closeDialog();
                return;
            }
            clearErrors();
            var invalid = [];
            var value = f.value.value.trim().toUpperCase();
            var desc = f.description.value.trim();
            var current = editing ? editing.getAttribute("data-value") : null;
            if (!setError(f.type, f.type.value ? "" : "Choose a type.")) {
                invalid.push(f.type);
            }
            var valueMsg = "";
            if (!value) {
                valueMsg = "Enter a value.";
            } else if (!/^[A-Z0-9][A-Z0-9_-]{0,19}$/.test(value)) {
                valueMsg = "Use up to 20 letters, numbers, hyphens or underscores.";
            } else if (rows().some(function (tr) {
                return tr.getAttribute("data-value").toUpperCase() === value && tr !== editing;
            })) {
                valueMsg = "The value " + value + " already exists.";
            }
            if (!setError(f.value, valueMsg)) {
                invalid.push(f.value);
            }
            if (!setError(f.description, desc ? "" : "Enter a description.")) {
                invalid.push(f.description);
            }
            if (invalid.length) {
                formError.textContent = "Please fix " + plural(invalid.length, "highlighted field") + ".";
                formError.hidden = false;
                invalid[0].focus();
                return;
            }
            var checkedStatus = form.querySelector('input[name="status"]:checked');
            var groups = groupBoxes().filter(function (b) { return b.checked; }).map(function (b) { return b.value; });
            var d = {
                value: value,
                type: f.type.value,
                description: desc,
                status: checkedStatus ? checkedStatus.value : "Active",
                groups: groups.length ? groups : [DEFAULT_GROUP],
                advanced: f.advanced.value.trim(),
                parentType: f.parentType.value,
                parentValue: f.parentValue.value
            };
            var tr;
            if (editing) {
                tr = editing;
                writeRow(tr, d);
                if (current !== value) {
                    insertSorted(tr);
                }
            } else {
                tr = buildRow(d);
                insertSorted(tr);
            }
            closeDialog();
            goToRow(tr);
            tr.classList.remove("is-new");
            /* Force a reflow so the highlight restarts for repeated saves. */
            tr.getBoundingClientRect();
            tr.classList.add("is-new");
            window.setTimeout(function () { tr.classList.remove("is-new"); }, 4000);
            var msg = editing ? "Charge code successfully updated." : "Charge code successfully added.";
            showToast("Success", msg);
            announce(msg);
        });

        /* =====================================================
           Toast
           ===================================================== */
        var toastTimer = 0;

        function showToast(title, message) {
            if (!toast) {
                return;
            }
            var titleEl = toast.querySelector(".cmp-toast__title");
            if (titleEl && title) {
                titleEl.textContent = title;
            }
            if (toastText) {
                toastText.textContent = message;
            }
            toast.hidden = false;
            window.clearTimeout(toastTimer);
            toastTimer = window.setTimeout(function () { toast.hidden = true; }, 8000);
        }

        if (toast) {
            toast.querySelector("[data-cmp-toast-close]").addEventListener("click", function () {
                window.clearTimeout(toastTimer);
                toast.hidden = true;
            });
        }

        /* =====================================================
           Keyboard: Esc + focus trap in the dialog
           ===================================================== */
        document.addEventListener("keydown", function (e) {
            if (modal.hidden) {
                return;
            }
            if (e.key === "Escape" || e.key === "Esc") {
                if (e.defaultPrevented) {
                    return;
                }
                e.preventDefault();
                closeDialog();
                return;
            }
            if (e.key !== "Tab") {
                return;
            }
            var items = Array.prototype.slice.call(dialog.querySelectorAll(FOCUSABLE)).filter(function (n) {
                return n.offsetWidth > 0 || n.offsetHeight > 0;
            });
            if (!items.length) {
                return;
            }
            var first = items[0];
            var last = items[items.length - 1];
            if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) {
                e.preventDefault();
                last.focus();
            } else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        });

        /* =====================================================
           Align the panel: from the end of the header's "My spend" tab
           to the right edge of the header's notification bell
           ===================================================== */
        var NAV_ITEMS = ".cmp-header__nav-list > .cmp-header__nav-item, " +
            ".cmp-vscheader__nav-list > .cmp-vscheader__item";
        var alignFrame = 0;

        function align() {
            alignFrame = 0;
            var items = document.querySelectorAll(NAV_ITEMS);
            var tab = items.length > 1 ?
                items[1].querySelector(".cmp-header__nav-link, .cmp-vscheader__nav-link") : null;
            if (!tab || !tab.offsetWidth) {
                root.style.removeProperty("--cmp-expcat-start");
                root.style.removeProperty("--cmp-expcat-end-gap");
                return;
            }
            var box = root.getBoundingClientRect();
            var start = tab.getBoundingClientRect().right -
                (parseFloat(window.getComputedStyle(tab).paddingRight) || 0) - box.left;
            if (start > 0) {
                root.style.setProperty("--cmp-expcat-start", start.toFixed(2) + "px");
            }
            /* End: right edge of the visible bell icon (falls back to the CSS value). */
            var bell = document.querySelector(".cmp-header__notifications-icon");
            if (bell && bell.getBoundingClientRect().width) {
                var contentRight = box.right - (parseFloat(window.getComputedStyle(root).paddingRight) || 0);
                var gap = contentRight - bell.getBoundingClientRect().right;
                if (gap >= 0) {
                    root.style.setProperty("--cmp-expcat-end-gap", gap.toFixed(2) + "px");
                }
            } else {
                root.style.removeProperty("--cmp-expcat-end-gap");
            }
        }

        function scheduleAlign() {
            if (!alignFrame) {
                alignFrame = window.requestAnimationFrame(align);
            }
        }

        window.addEventListener("resize", scheduleAlign);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(scheduleAlign);
        }
        if (window.ResizeObserver) {
            var alignObserver = new window.ResizeObserver(scheduleAlign);
            Array.prototype.forEach.call(document.querySelectorAll(NAV_ITEMS), function (item) {
                alignObserver.observe(item);
            });
        }
        align();

        render();
    }

    function safeInit(root) {
        try {
            init(root);
        } catch (err) {
            window.console.warn("VSC Expense Categories could not start", err);
        }
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-expcat]")) {
            safeInit(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-expcat]"), safeInit);
        }
    }

    function boot() {
        scan(document);
        /* AEM editor re-renders components after edits; enhance the new markup. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());

/* VSC Multi-select (dropdown component, "multi" template).
   - The ▾ button opens/closes the option list (aria-expanded).
   - Checking an option adds a chip; a chip button removes it.
   - Esc or a click outside closes the list.
   - Callers that change the checkboxes in code dispatch "vsc:multiselect-sync"
     on the [data-cmp-multiselect] element to redraw the chips. */
(function () {
    "use strict";

    function init(root) {
        if (!root || root.__vscMultiInit) {
            return;
        }
        root.__vscMultiInit = true;

        var toggle = root.querySelector("[data-cmp-multi-toggle]");
        var list = root.querySelector("[data-cmp-multi-list]");
        var chips = root.querySelector("[data-cmp-multi-chips]");
        if (!toggle || !list || !chips) {
            return;
        }

        function boxes() {
            return Array.prototype.slice.call(list.querySelectorAll('input[type="checkbox"]'));
        }

        function setOpen(open) {
            list.hidden = !open;
            toggle.setAttribute("aria-expanded", open ? "true" : "false");
        }

        function render() {
            chips.textContent = "";
            boxes().forEach(function (box) {
                if (!box.checked) {
                    return;
                }
                var li = document.createElement("li");
                var chip = document.createElement("button");
                chip.type = "button";
                chip.className = "cmp-multi__chip";
                chip.setAttribute("data-value", box.value);
                chip.setAttribute("aria-label", "Remove " + box.value);
                chip.disabled = box.disabled;
                var x = document.createElement("span");
                x.setAttribute("aria-hidden", "true");
                x.textContent = "×";
                chip.appendChild(x);
                chip.appendChild(document.createTextNode(box.value));
                li.appendChild(chip);
                chips.appendChild(li);
            });
            toggle.disabled = boxes().every(function (b) { return b.disabled; });
        }

        toggle.addEventListener("click", function (e) {
            e.stopPropagation();
            setOpen(list.hidden);
            if (!list.hidden) {
                var first = boxes()[0];
                if (first) {
                    first.focus();
                }
            }
        });

        list.addEventListener("change", render);

        chips.addEventListener("click", function (e) {
            var chip = e.target.closest ? e.target.closest(".cmp-multi__chip") : null;
            if (!chip) {
                return;
            }
            var value = chip.getAttribute("data-value");
            boxes().forEach(function (box) {
                if (box.value === value) {
                    box.checked = false;
                    box.dispatchEvent(new Event("change", { bubbles: true }));
                }
            });
            render();
            toggle.focus();
        });

        root.addEventListener("keydown", function (e) {
            if ((e.key === "Escape" || e.key === "Esc") && !list.hidden) {
                e.stopPropagation();
                setOpen(false);
                toggle.focus();
            }
        });

        document.addEventListener("click", function (e) {
            if (!list.hidden && !root.contains(e.target)) {
                setOpen(false);
            }
        });

        root.addEventListener("vsc:multiselect-sync", function () {
            setOpen(false);
            render();
        });

        render();
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-multiselect]")) {
            init(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-multiselect]"), init);
        }
    }

    function boot() {
        scan(document);
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());

/* VSC table export — dependency-free CSV, Excel (.xlsx), PDF and PNG.
   Usage (any component):
     window.VSC.exporter.download("xlsx", {
         filename: "charge-codes",          // no extension
         title: "Charge Codes",             // PDF / image heading, sheet name
         columns: ["Value", "Type"],
         rows: [["500030", "GL Account"]]
     });
   Formats: "csv" | "xlsx" | "pdf" | "png". Returns true when a file was produced.
   Everything is generated in the browser: no network requests, no libraries. */
(function () {
    "use strict";

    var VSC = window.VSC = window.VSC || {};

    /* ---------- download ---------- */
    function save(blob, name) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = name;
        a.rel = "noopener";
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    }

    function utf8(str) {
        return new TextEncoder().encode(str);
    }

    function cell(v) {
        return v === null || v === undefined ? "" : String(v);
    }

    /* ---------- CSV ---------- */
    function toCsv(columns, rows) {
        function q(v) {
            var s = cell(v);
            /* Neutralise spreadsheet formulas (CSV injection). */
            if (/^[=+\-@\t\r]/.test(s)) {
                s = "'" + s;
            }
            return '"' + s.replace(/"/g, '""') + '"';
        }
        var lines = [columns.map(q).join(",")];
        rows.forEach(function (r) { lines.push(r.map(q).join(",")); });
        return new Blob(["\ufeff" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
    }

    /* ---------- ZIP (stored) for XLSX ---------- */
    var CRC_TABLE = (function () {
        var t = [];
        for (var n = 0; n < 256; n++) {
            var c = n;
            for (var k = 0; k < 8; k++) {
                /* eslint-disable-next-line no-bitwise */
                c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
            }
            t[n] = c >>> 0;
        }
        return t;
    }());

    function crc32(bytes) {
        var c = 0xFFFFFFFF;
        for (var i = 0; i < bytes.length; i++) {
            /* eslint-disable-next-line no-bitwise */
            c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
        }
        /* eslint-disable-next-line no-bitwise */
        return (c ^ 0xFFFFFFFF) >>> 0;
    }

    function zip(files) {
        var parts = [];
        var central = [];
        var offset = 0;
        function u16(v) {
            /* eslint-disable-next-line no-bitwise */
            return [v & 0xFF, (v >>> 8) & 0xFF];
        }
        function u32(v) {
            /* eslint-disable-next-line no-bitwise */
            return [v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF];
        }
        files.forEach(function (f) {
            var name = utf8(f.name);
            var data = utf8(f.data);
            var crc = crc32(data);
            var common = [].concat(u16(20), u16(0x0800), u16(0), u16(0), u16(0x21),
                u32(crc), u32(data.length), u32(data.length), u16(name.length), u16(0));
            var local = new Uint8Array([].concat(u32(0x04034b50), common));
            parts.push(local, name, data);
            central.push(new Uint8Array([].concat(u32(0x02014b50), u16(20), common,
                u16(0), u16(0), u16(0), u32(0), u32(offset))), name);
            offset += local.length + name.length + data.length;
        });
        var size = central.reduce(function (s, p) { return s + p.length; }, 0);
        var end = new Uint8Array([].concat(u32(0x06054b50), u16(0), u16(0), u16(files.length),
            u16(files.length), u32(size), u32(offset), u16(0)));
        return new Blob(parts.concat(central, [end]),
            { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    }

    function xml(s) {
        return cell(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
    }

    function colName(i) {
        var s = "";
        var n = i + 1;
        while (n > 0) {
            var m = (n - 1) % 26;
            s = String.fromCharCode(65 + m) + s;
            n = Math.floor((n - 1) / 26);
        }
        return s;
    }

    function toXlsx(title, columns, rows) {
        var sheetName = xml((title || "Sheet1").replace(/[\\/?*[\]:]/g, " ").slice(0, 31));
        var all = [columns].concat(rows);
        var sheetRows = all.map(function (r, ri) {
            var cells = r.map(function (v, ci) {
                var ref = colName(ci) + (ri + 1);
                return '<c r="' + ref + '" t="inlineStr"' + (ri === 0 ? ' s="1"' : "") +
                    "><is><t xml:space=\"preserve\">" + xml(v) + "</t></is></c>";
            }).join("");
            return '<row r="' + (ri + 1) + '">' + cells + "</row>";
        }).join("");
        var widths = columns.map(function (c, ci) {
            var w = all.reduce(function (m, r) { return Math.max(m, cell(r[ci]).length); }, 8);
            return '<col min="' + (ci + 1) + '" max="' + (ci + 1) + '" width="' + Math.min(60, w + 2) +
                '" customWidth="1"/>';
        }).join("");
        var ns = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"';
        var rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        return zip([
            { name: "[Content_Types].xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
                '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
                '<Default Extension="xml" ContentType="application/xml"/>' +
                '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-' +
                'officedocument.spreadsheetml.sheet.main+xml"/>' +
                '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-' +
                'officedocument.spreadsheetml.worksheet+xml"/>' +
                '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-' +
                'officedocument.spreadsheetml.styles+xml"/></Types>' },
            { name: "_rels/.rels", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                '<Relationship Id="rId1" Type="' + rel + '/officeDocument" Target="xl/workbook.xml"/>' +
                "</Relationships>" },
            { name: "xl/workbook.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                "<workbook " + ns + ' xmlns:r="' + rel + '"><sheets><sheet name="' + sheetName +
                '" sheetId="1" r:id="rId1"/></sheets></workbook>' },
            { name: "xl/_rels/workbook.xml.rels", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                '<Relationship Id="rId1" Type="' + rel + '/worksheet" Target="worksheets/sheet1.xml"/>' +
                '<Relationship Id="rId2" Type="' + rel + '/styles" Target="styles.xml"/></Relationships>' },
            { name: "xl/styles.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                "<styleSheet " + ns + '><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>' +
                '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>' +
                '<fills count="2"><fill><patternFill patternType="none"/></fill>' +
                '<fill><patternFill patternType="gray125"/></fill></fills>' +
                '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
                '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
                '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
                '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>' +
                '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
                "</styleSheet>" },
            { name: "xl/worksheets/sheet1.xml", data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
                "<worksheet " + ns + "><cols>" + widths + "</cols><sheetData>" + sheetRows +
                "</sheetData></worksheet>" }
        ]);
    }

    /* ---------- PDF (Helvetica, A4 landscape, paginated) ---------- */
    function pdfText(s) {
        var out = "";
        var str = cell(s);
        for (var i = 0; i < str.length; i++) {
            var code = str.charCodeAt(i);
            var ch = str.charAt(i);
            if (ch === "\\" || ch === "(" || ch === ")") {
                out += "\\" + ch;
            } else if (code < 32) {
                out += " ";
            } else if (code < 128) {
                out += ch;
            } else if (code < 256) {
                out += "\\" + ("00" + code.toString(8)).slice(-3);
            } else {
                out += "?";
            }
        }
        return out;
    }

    function fit(text, maxChars) {
        var s = cell(text);
        return s.length > maxChars ? s.slice(0, Math.max(1, maxChars - 3)) + "..." : s;
    }

    function toPdf(title, columns, rows) {
        var W = 842;
        var H = 595;
        var M = 40;
        var ROW = 20;
        var usable = W - 2 * M;
        var weights = columns.map(function (c, ci) {
            return [c].concat(rows.map(function (r) { return r[ci]; }))
                .reduce(function (m, v) { return Math.max(m, cell(v).length); }, 4);
        });
        var total = weights.reduce(function (a, b) { return a + b; }, 0);
        var widths = weights.map(function (w) { return usable * w / total; });
        var perPage = Math.floor((H - 2 * M - 60) / ROW);
        var pages = [];
        for (var p = 0; p === 0 || p * perPage < rows.length; p++) {
            pages.push(rows.slice(p * perPage, (p + 1) * perPage));
        }

        function rowOps(values, y, bold) {
            var x = M;
            var ops = "";
            values.forEach(function (v, ci) {
                var maxChars = Math.floor(widths[ci] / 5.2);
                ops += "BT /" + (bold ? "F2" : "F1") + " 10 Tf " + (x + 4).toFixed(1) + " " + (y + 6).toFixed(1) +
                    " Td (" + pdfText(fit(v, maxChars)) + ") Tj ET\n";
                x += widths[ci];
            });
            ops += "0.85 G 0.5 w " + M + " " + y.toFixed(1) + " m " + (W - M) + " " + y.toFixed(1) + " l S\n";
            return ops;
        }

        var objects = [];
        function add(body) {
            objects.push(body);
            return objects.length;
        }
        var fontReg = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        var fontBold = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        var pagesId = objects.length + 1;
        objects.push(null);
        var kids = [];
        pages.forEach(function (chunk, pi) {
            var y = H - M - 20;
            var ops = "BT /F2 16 Tf " + M + " " + y + " Td (" + pdfText(title) + ") Tj ET\n";
            ops += "BT /F1 9 Tf " + (W - M - 90) + " " + y + " Td (" + pdfText("Page " + (pi + 1) + " of " +
                pages.length) + ") Tj ET\n";
            y -= 34;
            ops += "0.95 g " + M + " " + y.toFixed(1) + " " + usable + " " + ROW + " re f 0 g\n";
            ops += rowOps(columns, y, true);
            chunk.forEach(function (r) {
                y -= ROW;
                ops += rowOps(r, y, false);
            });
            var stream = add("<< /Length " + ops.length + " >>\nstream\n" + ops + "endstream");
            kids.push(add("<< /Type /Page /Parent " + pagesId + " 0 R /MediaBox [0 0 " + W + " " + H + "] " +
                "/Resources << /Font << /F1 " + fontReg + " 0 R /F2 " + fontBold + " 0 R >> >> " +
                "/Contents " + stream + " 0 R >>"));
        });
        objects[pagesId - 1] = "<< /Type /Pages /Kids [" + kids.map(function (k) { return k + " 0 R"; }).join(" ") +
            "] /Count " + kids.length + " >>";
        var catalog = add("<< /Type /Catalog /Pages " + pagesId + " 0 R >>");
        var info = add("<< /Title (" + pdfText(title) + ") /Producer (Spend Clarity) >>");

        var out = "%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n";
        var offsets = [];
        objects.forEach(function (body, i) {
            offsets.push(out.length);
            out += (i + 1) + " 0 obj\n" + body + "\nendobj\n";
        });
        var xref = out.length;
        out += "xref\n0 " + (objects.length + 1) + "\n0000000000 65535 f \n";
        offsets.forEach(function (o) { out += ("0000000000" + o).slice(-10) + " 00000 n \n"; });
        out += "trailer\n<< /Size " + (objects.length + 1) + " /Root " + catalog + " 0 R /Info " + info +
            " 0 R >>\nstartxref\n" + xref + "\n%%EOF";
        var bytes = new Uint8Array(out.length);
        for (var i = 0; i < out.length; i++) {
            /* eslint-disable-next-line no-bitwise */
            bytes[i] = out.charCodeAt(i) & 0xFF;
        }
        return new Blob([bytes], { type: "application/pdf" });
    }

    /* ---------- PNG (canvas) ---------- */
    function toPng(title, columns, rows, done) {
        var scale = 2;
        var font = "13px Arial, Helvetica, sans-serif";
        var bold = "bold 13px Arial, Helvetica, sans-serif";
        var pad = 12;
        var rowH = 32;
        var canvas = document.createElement("canvas");
        var ctx = canvas.getContext("2d");
        if (!ctx || !canvas.toBlob) {
            done(null);
            return;
        }
        ctx.font = bold;
        var widths = columns.map(function (c, ci) {
            var w = ctx.measureText(cell(c)).width;
            ctx.font = font;
            rows.forEach(function (r) { w = Math.max(w, ctx.measureText(cell(r[ci])).width); });
            ctx.font = bold;
            return Math.ceil(w) + pad * 2;
        });
        var width = widths.reduce(function (a, b) { return a + b; }, 0) + 32;
        var height = 64 + rowH * (rows.length + 1) + 16;
        canvas.width = width * scale;
        canvas.height = height * scale;
        ctx.scale(scale, scale);
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = "#202124";
        ctx.font = "bold 18px Arial, Helvetica, sans-serif";
        ctx.textBaseline = "middle";
        ctx.fillText(cell(title), 16, 30);
        var y = 56;
        [columns].concat(rows).forEach(function (r, ri) {
            if (ri === 0) {
                ctx.fillStyle = "#f1f3f5";
                ctx.fillRect(16, y, width - 32, rowH);
            }
            ctx.fillStyle = "#202124";
            ctx.font = ri === 0 ? bold : font;
            var x = 16;
            r.forEach(function (v, ci) {
                ctx.fillText(cell(v), x + pad, y + rowH / 2);
                x += widths[ci];
            });
            ctx.fillStyle = "#dfe2e6";
            ctx.fillRect(16, y + rowH - 1, width - 32, 1);
            y += rowH;
        });
        canvas.toBlob(done, "image/png");
    }

    /* ---------- public API ---------- */
    function download(format, spec) {
        var columns = spec.columns || [];
        var rows = spec.rows || [];
        var title = spec.title || "Export";
        var base = (spec.filename || title).replace(/[^\w.-]+/g, "-").replace(/^-+|-+$/g, "") || "export";
        if (format === "csv") {
            save(toCsv(columns, rows), base + ".csv");
        } else if (format === "xlsx") {
            save(toXlsx(title, columns, rows), base + ".xlsx");
        } else if (format === "pdf") {
            save(toPdf(title, columns, rows), base + ".pdf");
        } else if (format === "png") {
            toPng(title, columns, rows, function (blob) {
                if (blob) {
                    save(blob, base + ".png");
                }
            });
        } else {
            return false;
        }
        return true;
    }

    VSC.exporter = {
        download: download,
        /* Exposed for unit tests. */
        build: { csv: toCsv, xlsx: toXlsx, pdf: toPdf, png: toPng }
    };
}());
/* VSC Expenses Two Column Grid — aligns the columns with the header tabs.
   Left column ends at the right edge of the 2nd primary tab ("My spend");
   right column content starts at the label of the 3rd tab ("Approvals" in the
   Figma). Works with cmp-header and cmp-vscheader. Sets two CSS variables only. */
(function () {
    "use strict";

    var NAV_ITEMS = ".cmp-header__nav-list > .cmp-header__nav-item, " +
        ".cmp-vscheader__nav-list > .cmp-vscheader__item";
    var TAB = ".cmp-header__nav-link, .cmp-vscheader__nav-link";
    var grids = [];
    var frame = 0;

    function tabs() {
        var items = document.querySelectorAll(NAV_ITEMS);
        if (items.length < 3) {
            return null;
        }
        var second = items[1].querySelector(TAB);
        var third = items[2].querySelector(TAB);
        if (!second || !third || !second.offsetWidth || !third.offsetWidth) {
            return null;
        }
        return { second: second, third: third };
    }

    function align(grid) {
        var t = tabs();
        if (!t) {
            grid.style.removeProperty("--cmp-expgrid-left-end");
            grid.style.removeProperty("--cmp-expgrid-right-start");
            return;
        }
        var origin = grid.getBoundingClientRect().left;
        var leftEnd = t.second.getBoundingClientRect().right - origin;
        var rightStart = t.third.getBoundingClientRect().left +
            (parseFloat(window.getComputedStyle(t.third).paddingLeft) || 0) - origin;
        if (leftEnd <= 0 || rightStart <= leftEnd) {
            return;
        }
        grid.style.setProperty("--cmp-expgrid-left-end", leftEnd.toFixed(2) + "px");
        grid.style.setProperty("--cmp-expgrid-right-start", rightStart.toFixed(2) + "px");
    }

    function alignAll() {
        frame = 0;
        grids = grids.filter(function (g) { return document.documentElement.contains(g); });
        grids.forEach(align);
    }

    function schedule() {
        if (!frame) {
            frame = window.requestAnimationFrame(alignAll);
        }
    }

    function register(node) {
        var added = false;
        function add(g) {
            if (grids.indexOf(g) < 0) {
                grids.push(g);
                added = true;
            }
        }
        if (node.matches && node.matches("[data-cmp-expgrid]")) {
            add(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-expgrid]"), add);
        }
        if (added) {
            schedule();
        }
    }

    function boot() {
        register(document);
        window.addEventListener("resize", schedule);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(schedule);
        }
        if (window.ResizeObserver) {
            var observer = new window.ResizeObserver(schedule);
            Array.prototype.forEach.call(document.querySelectorAll(NAV_ITEMS), function (item) {
                observer.observe(item);
            });
        }
        /* AEM editor re-renders components after edits (REFRESH_SELF/PAGE). */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                var changed = false;
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            register(node);
                            changed = true;
                        }
                    });
                });
                if (changed && grids.length) {
                    schedule();
                }
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Code Expenses — list + coding panel + image linking (in-memory, no backend).
   List: Show / Filters / Find, Select all, Code selected expenses.
   Panel: summary + receipt (Manage), Coding / Details tabs, Spend Wizard,
   Expense template, split allocation, Cost Center / GL Account / Project pickers,
   description, Complete / Update / Reset.
   Image Linking: Linked Images / Image Library, Upload, Upload via Email,
   zoom, rotate, link / unlink, delete.
   All text is written with textContent; uploaded files are read locally only. */
(function () {
    "use strict";

    var SVG_NS = "http://www.w3.org/2000/svg";
    var FOCUSABLE = "a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), " +
        "textarea:not([disabled]), [tabindex]:not([tabindex='-1'])";
    var MAX_UPLOAD = 10 * 1024 * 1024;

    var CATS = {
        supplies: "Other Supplies", airline: "Airlines", professional: "Professional Services",
        transport: "Ground Transportation", restaurant: "Restaurants", office: "Office",
        other: "Other", car: "Auto Rentals"
    };
    var SUGGEST = {
        supplies: ["FIN", "500050"], airline: ["OPN", "500090"], professional: ["FIN", "500090"],
        transport: ["OPN", "500090"], restaurant: ["OPN", "500030"], office: ["FIN", "500050"],
        other: ["FIN", "500070"], car: ["OPN", "500090"]
    };
    var DIMS = {
        cc: { label: "Cost Center", options: [["FIN", "Finance"], ["HUR", "Human Resources"],
            ["ITI", "IT Integration"], ["LDV", "Learning & Development"], ["OPN", "Operations"],
            ["PROD", "Product"]] },
        gl: { label: "GL Account", options: [["500030", "Meals - Individual"], ["500040", "Memberships/Associations"],
            ["500050", "Office Supplies"], ["500060", "Printing & Copying"], ["500070", "Retail/Other Supplies"],
            ["500080", "Salaries Expense"], ["500090", "Services"], ["500110", "Technology <$5000"],
            ["500120", "Technology >$5000"]] },
        pr: { label: "Project", options: [["P100", "Website Refresh"], ["P200", "ERP Upgrade"],
            ["P300", "Office Move"]] }
    };

    /* ---------- helpers ---------- */
    function el(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }
        if (text !== undefined && text !== null) {
            node.textContent = text;
        }
        return node;
    }

    function useIcon(name, w, h) {
        var svg = document.createElementNS(SVG_NS, "svg");
        svg.setAttribute("viewBox", "0 0 16 16");
        svg.setAttribute("width", String(w));
        svg.setAttribute("height", String(h || w));
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("focusable", "false");
        var use = document.createElementNS(SVG_NS, "use");
        use.setAttribute("href", "#cx-ico-" + name);
        svg.appendChild(use);
        return svg;
    }

    function nameOf(dim, code) {
        var found = DIMS[dim].options.filter(function (o) { return o[0] === code; })[0];
        return found ? found[1] : "";
    }

    function money(n) {
        return (Math.round(Number(n) * 100) / 100).toFixed(2);
    }

    function parseMoney(v) {
        var s = String(v || "").replace(/,/g, "").trim();
        return /^\d+(\.\d{1,2})?$/.test(s) ? Number(s) : NaN;
    }

    function parseUsDate(v) {
        var m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(v || "");
        return m ? new Date(Number(m[3]), Number(m[1]) - 1, Number(m[2])) : null;
    }

    function parseIso(v) {
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v || "");
        return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
    }

    function xml(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    /* Illustrative receipt image (SVG data URI) for the demo data. */
    function receiptImage(merchant, amount, date) {
        var lines = ["Receipt #: 7749204", "Date: " + date, "Merchandise Purchase   $" + amount,
            "Subtotal", "Sales Tax", "Total   $" + amount, "Visa ************0006"];
        var body = lines.map(function (t, i) {
            return '<text x="18" y="' + (78 + i * 18) + '" font-size="11">' + xml(t) + "</text>";
        }).join("");
        var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="300" viewBox="0 0 240 300">' +
            '<rect width="240" height="300" fill="#b9956b"/>' +
            '<rect x="10" y="8" width="220" height="284" fill="#fbfaf6"/>' +
            '<g font-family="Courier New, monospace" fill="#333"><text x="120" y="40" font-size="15" ' +
            'text-anchor="middle" font-weight="bold">' + xml(merchant.toUpperCase().slice(0, 22)) + "</text>" +
            body + '<text x="120" y="270" font-size="10" text-anchor="middle">Thank you!</text></g></svg>';
        return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
    }

    function trap(container, e) {
        var items = Array.prototype.slice.call(container.querySelectorAll(FOCUSABLE)).filter(function (n) {
            return (n.offsetWidth > 0 || n.offsetHeight > 0) && !n.closest("[hidden]");
        });
        if (!items.length) {
            return;
        }
        var first = items[0];
        var last = items[items.length - 1];
        if (e.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))) {
            e.preventDefault();
            last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
        }
    }

    /* ---------- component ---------- */
    function init(root) {
        if (!root || root.__codeexpInit) {
            return;
        }
        root.__codeexpInit = true;

        function q(sel) {
            return root.querySelector(sel);
        }
        function qa(sel) {
            return Array.prototype.slice.call(root.querySelectorAll(sel));
        }

        var list = q("[data-cmp-codeexp-list]");
        var emptyMsg = q("[data-cmp-codeexp-empty]");
        var status = q("[data-cmp-codeexp-status]");
        var showSel = q("#cx-show");
        var findInput = q("#cx-find");
        var filtersBtn = q("[data-cmp-codeexp-filters-btn]");
        var filtersPop = q("#cx-filters");
        var filtersLabel = q("[data-cmp-codeexp-filters-label]");
        var fCat = q("#cx-f-cat");
        var fRcpt = q("#cx-f-rcpt");
        var fFrom = q("#cx-f-from");
        var fTo = q("#cx-f-to");
        var selectAllBtn = q("[data-cmp-codeexp-selectall]");
        var codeSelBtn = q("[data-cmp-codeexp-codesel]");

        var panel = q("[data-cmp-codeexp-panel]");
        var ptitle = q("[data-cmp-codeexp-ptitle]");
        var form = q("[data-cmp-codeexp-form]");
        var formError = q("[data-cmp-codeexp-error]");
        var doneMsg = q("[data-cmp-codeexp-done]");
        var completeBtn = q("[data-cmp-codeexp-complete]");
        var updateBtn = q("[data-cmp-codeexp-update]");
        var desc = q("#cx-desc");
        var count = q("[data-cmp-codeexp-count]");
        var manageBtn = q("[data-cmp-codeexp-manage]");
        var managePop = q("#cx-manage");
        var rcptSel = q("#cx-rcpt");
        var tplBtn = q("[data-cmp-codeexp-tplbtn]");
        var tplMenu = q("#cx-tplmenu");
        var picker = q("[data-cmp-codeexp-picker]");
        var pickerTitle = q("[data-cmp-codeexp-picker-title]");
        var pickerQ = q("#cx-picker-q");
        var pickerList = q("[data-cmp-codeexp-options]");
        var pickerEmpty = q("[data-cmp-codeexp-options-empty]");

        var modal = q("[data-cmp-codeexp-modal]");
        var dialog = modal.querySelector(".cmp-codeexp__dialog");
        var fileInput = q("[data-cmp-codeexp-file]");
        var imgPop = q("[data-cmp-codeexp-imgpop]");
        var dstatus = q("[data-cmp-codeexp-dstatus]");

        var toast = q('[data-cmp-toast="codeexp"]');
        var toastText = toast ? toast.querySelector("[data-cmp-toast-text]") : null;

        var state = {};
        var images = [];
        var imgSeq = 2;
        var current = null;
        var opener = null;
        var dialogOpener = null;
        var pickerCtx = null;
        var imgCtx = null;
        var queue = [];

        /* ---------- data ---------- */
        function items() {
            return Array.prototype.slice.call(list.querySelectorAll("[data-cmp-codeexp-item]"));
        }

        function itemById(id) {
            return list.querySelector('[data-cmp-codeexp-item][data-id="' + id + '"]');
        }

        function info(li) {
            return {
                id: li.getAttribute("data-id"),
                merchant: li.getAttribute("data-merchant"),
                amount: li.getAttribute("data-amount"),
                date: li.getAttribute("data-date"),
                cat: li.getAttribute("data-cat")
            };
        }

        function blank(d) {
            return {
                splits: [{ amount: money(d.amount), taxCode: "N/A", tax: "0.00", cc: "FIN", gl: "", pr: "" }],
                description: "Purchase " + d.merchant,
                receiptAttached: "N/A",
                done: false
            };
        }

        function clone(o) {
            return JSON.parse(JSON.stringify(o));
        }

        function linkedTo(id) {
            return images.filter(function (img) { return img.linkedTo === id; });
        }

        items().forEach(function (li, i) {
            var d = info(li);
            var s = blank(d);
            state[d.id] = { saved: s, draft: clone(s) };
            if (li.getAttribute("data-receipt") === "yes") {
                images.push({ id: "img-" + d.id, name: i === 0 ? "IMG001.jpg" : "RCPT-" + d.id.toUpperCase() + ".jpg",
                    src: receiptImage(d.merchant, d.amount, d.date), rotate: 0, linkedTo: d.id });
            }
        });
        var first = items()[0];
        if (first) {
            var f0 = info(first);
            images.push({ id: "img-lib-1", name: "IMG002.jpg", src: receiptImage(f0.merchant, f0.amount, f0.date),
                rotate: 0, linkedTo: null });
        }

        /* Every page load starts from the original list (nothing is stored).
           Remove data saved by an earlier version of this component. */
        try {
            window.localStorage.removeItem("vsc-codeexp:" + window.location.pathname + ":" +
                (root.id || "default"));
        } catch (err) {
            /* Storage unavailable: nothing to clean up. */
        }

        function announce(el2, text) {
            el2.textContent = "";
            window.setTimeout(function () { el2.textContent = text; }, 30);
        }

        var toastTimer = 0;
        function showToast(message) {
            if (!toast) {
                return;
            }
            toastText.textContent = message;
            toast.hidden = false;
            window.clearTimeout(toastTimer);
            toastTimer = window.setTimeout(function () { toast.hidden = true; }, 8000);
        }
        if (toast) {
            toast.querySelector("[data-cmp-toast-close]").addEventListener("click", function () {
                window.clearTimeout(toastTimer);
                toast.hidden = true;
            });
        }

        /* =====================================================
           List: Show / Filters / Find
           ===================================================== */
        function activeFilters() {
            return [fCat.value, fRcpt.value, fFrom.value, fTo.value].filter(Boolean).length;
        }

        function matches(li) {
            var d = info(li);
            var done = state[d.id].saved.done;
            var hasRcpt = linkedTo(d.id).length > 0;
            var show = showSel.value;
            if (show === "My expenses" && done) {
                return false;
            }
            if (show === "Completed expenses" && !done) {
                return false;
            }
            if (show === "Missing receipts" && hasRcpt) {
                return false;
            }
            if (fCat.value && CATS[d.cat] !== fCat.value) {
                return false;
            }
            if (fRcpt.value === "Attached" && !hasRcpt) {
                return false;
            }
            if (fRcpt.value === "Missing" && hasRcpt) {
                return false;
            }
            var when = parseUsDate(d.date);
            var from = parseIso(fFrom.value);
            var to = parseIso(fTo.value);
            if (when && from && when < from) {
                return false;
            }
            if (when && to && when > to) {
                return false;
            }
            var term = findInput.value.trim().toLowerCase();
            if (term && (d.merchant + " " + d.amount + " " + d.date + " " + CATS[d.cat]).toLowerCase()
                .indexOf(term) === -1) {
                return false;
            }
            return true;
        }

        function renderList(announceIt) {
            var shown = 0;
            items().forEach(function (li) {
                var ok = matches(li);
                li.hidden = !ok;
                if (ok) {
                    shown += 1;
                }
                var id = li.getAttribute("data-id");
                li.querySelector("[data-cmp-codeexp-rcpt]").hidden = linkedTo(id).length > 0;
                li.setAttribute("data-done", state[id].saved.done ? "true" : "false");
            });
            emptyMsg.hidden = shown > 0;
            var n = activeFilters();
            filtersLabel.textContent = n ? n + " applied" : "Default";
            updateSelection();
            if (announceIt) {
                announce(status, shown + " expense" + (shown === 1 ? "" : "s") + " shown");
            }
        }

        function checked() {
            return items().filter(function (li) {
                return !li.hidden && li.querySelector("[data-cmp-codeexp-check]").checked;
            });
        }

        function updateSelection() {
            var visible = items().filter(function (li) { return !li.hidden; });
            var n = checked().length;
            codeSelBtn.disabled = n === 0;
            var all = visible.length > 0 && n === visible.length;
            selectAllBtn.setAttribute("aria-pressed", all ? "true" : "false");
            selectAllBtn.textContent = all ? "Clear selection" : "Select all";
        }

        showSel.addEventListener("change", function () { renderList(true); });
        findInput.addEventListener("input", function () { renderList(false); });
        findInput.addEventListener("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                renderList(true);
            }
        });
        q("[data-cmp-codeexp-find-btn]").addEventListener("click", function () { renderList(true); });

        function setPop(btn, pop, open) {
            pop.hidden = !open;
            btn.setAttribute("aria-expanded", open ? "true" : "false");
        }

        filtersBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            var open = filtersPop.hidden;
            setPop(filtersBtn, filtersPop, open);
            if (open) {
                fCat.focus();
            }
        });
        q("[data-cmp-codeexp-filters-apply]").addEventListener("click", function () {
            setPop(filtersBtn, filtersPop, false);
            filtersBtn.focus();
            renderList(true);
        });
        q("[data-cmp-codeexp-filters-clear]").addEventListener("click", function () {
            fCat.value = "";
            fRcpt.value = "";
            fFrom.value = "";
            fTo.value = "";
            renderList(true);
        });

        list.addEventListener("change", function (e) {
            if (e.target.hasAttribute("data-cmp-codeexp-check")) {
                updateSelection();
            }
        });
        selectAllBtn.addEventListener("click", function () {
            var visible = items().filter(function (li) { return !li.hidden; });
            var all = checked().length === visible.length && visible.length > 0;
            visible.forEach(function (li) { li.querySelector("[data-cmp-codeexp-check]").checked = !all; });
            updateSelection();
            announce(status, all ? "Selection cleared" : visible.length + " expenses selected");
        });
        codeSelBtn.addEventListener("click", function () {
            queue = checked().map(function (li) { return li.getAttribute("data-id"); });
            if (queue.length) {
                openPanel(queue.shift(), codeSelBtn);
            }
        });

        list.addEventListener("click", function (e) {
            var btn = e.target.closest ? e.target.closest("[data-cmp-codeexp-open]") : null;
            if (btn) {
                queue = [];
                openPanel(btn.closest("[data-cmp-codeexp-item]").getAttribute("data-id"), btn);
            }
        });

        /* =====================================================
           Panel
           ===================================================== */
        function fieldsFor(n) {
            return { amount: q("#cx-amt-" + n), code: q("#cx-code-" + n), tax: q("#cx-tax-" + n),
                block: q('[data-cmp-codeexp-split="' + n + '"]') };
        }

        function setText(key, value) {
            qa('[data-cx="' + key + '"]').forEach(function (n) { n.textContent = value; });
        }

        function renderSummary() {
            var d = info(itemById(current));
            var s = state[current];
            var linked = linkedTo(current);
            ptitle.textContent = d.merchant;
            setText("merchant", d.merchant);
            setText("amount", money(d.amount) + " USD");
            setText("date", d.date);
            setText("catname", CATS[d.cat]);
            setText("receipt", linked.length ? linked.length + " linked (" + linked.map(function (i) {
                return i.name;
            }).join(", ") + ")" : "Missing");
            setText("state", s.saved.done ? "Submitted for approval" : "Awaiting coding");
            var use = q('[data-cx="catico"] use');
            if (use) {
                use.setAttribute("href", "#cx-ico-" + d.cat);
            }
            var img = q("[data-cmp-codeexp-thumbimg]");
            img.hidden = !linked.length;
            q("[data-cmp-codeexp-nothumb]").hidden = linked.length > 0;
            if (linked.length) {
                img.src = linked[0].src;
            }
            q("[data-cmp-codeexp-thumblabel]").textContent = linked.length ?
                "Receipt image " + linked[0].name + ", open image linking" : "No receipt linked, open image linking";
        }

        function renderCells(n) {
            var split = state[current].draft.splits[n - 1];
            var block = fieldsFor(n).block;
            var readOnly = state[current].saved.done;
            ["cc", "gl", "pr"].forEach(function (dim) {
                var cell = block.querySelector('[data-dim="' + dim + '"] [data-cmp-codeexp-cell]');
                cell.textContent = "";
                var label = DIMS[dim].label;
                if (split[dim]) {
                    var name = nameOf(dim, split[dim]);
                    var change = el("button", "cmp-codeexp__chip");
                    change.type = "button";
                    change.disabled = readOnly;
                    change.setAttribute("aria-label", label + ": " + split[dim] + " " + name + ". Change");
                    change.setAttribute("data-pick", dim);
                    change.appendChild(el("span", "cmp-codeexp__code", split[dim]));
                    change.appendChild(el("span", "cmp-codeexp__codename", name));
                    var clear = el("button", "cmp-codeexp__clear");
                    clear.type = "button";
                    clear.disabled = readOnly;
                    clear.setAttribute("aria-label", "Remove " + label + " " + split[dim]);
                    clear.setAttribute("data-clear", dim);
                    clear.appendChild(el("span", null, "×"));
                    clear.firstChild.setAttribute("aria-hidden", "true");
                    cell.appendChild(change);
                    cell.appendChild(clear);
                } else {
                    var add = el("button", "cmp-codeexp__add" + (dim === "gl" ? " cmp-codeexp__add--required" : ""));
                    add.type = "button";
                    add.disabled = readOnly;
                    add.setAttribute("data-pick", dim);
                    add.setAttribute("aria-label", "Choose " + label + (dim === "gl" ? " (required)" : ""));
                    add.appendChild(el("span", null, "+"));
                    add.firstChild.setAttribute("aria-hidden", "true");
                    cell.appendChild(add);
                }
            });
        }

        function fillForm() {
            var s = state[current];
            var d = s.draft;
            [1, 2].forEach(function (n) {
                var fl = fieldsFor(n);
                var sp = d.splits[n - 1];
                fl.block.hidden = !sp;
                if (sp) {
                    fl.amount.value = sp.amount;
                    fl.code.value = sp.taxCode;
                    fl.tax.value = sp.tax;
                    renderCells(n);
                }
            });
            desc.value = d.description;
            rcptSel.value = d.receiptAttached;
            updateCount();
            clearErrors();
            var readOnly = s.saved.done;
            Array.prototype.forEach.call(form.elements, function (n) {
                if (n !== completeBtn && n.tagName !== "BUTTON") {
                    n.disabled = readOnly;
                }
            });
            qa("[data-cmp-codeexp-split-btn], [data-cmp-codeexp-unsplit], [data-cmp-codeexp-wizard], " +
                "[data-cmp-codeexp-tplbtn], [data-cmp-codeexp-reset]").forEach(function (b) { b.disabled = readOnly; });
            completeBtn.disabled = readOnly;
            doneMsg.hidden = !readOnly;
            setDirty(false);
        }

        function readForm() {
            var d = state[current].draft;
            [1, 2].forEach(function (n) {
                var sp = d.splits[n - 1];
                if (sp) {
                    var fl = fieldsFor(n);
                    sp.amount = fl.amount.value.trim();
                    sp.taxCode = fl.code.value;
                    sp.tax = fl.tax.value.trim();
                }
            });
            d.description = desc.value;
            d.receiptAttached = rcptSel.value;
        }

        function setDirty(dirty) {
            updateBtn.disabled = !dirty || state[current].saved.done;
        }

        function openPanel(id, from) {
            if (current && current !== id) {
                markRow(current, false);
            }
            current = id;
            opener = from || null;
            state[id].draft = clone(state[id].saved);
            closePops();
            selectTab(q("#cx-tab-coding"), false);
            renderSummary();
            fillForm();
            panel.hidden = false;
            root.classList.add("cmp-codeexp--open");
            markRow(id, true);
            ptitle.focus();
        }

        function markRow(id, on) {
            var li = itemById(id);
            if (!li) {
                return;
            }
            li.classList.toggle("is-current", on);
            li.querySelector("[data-cmp-codeexp-open]").setAttribute("aria-expanded", on ? "true" : "false");
        }

        function closePanel() {
            closePops();
            panel.hidden = true;
            root.classList.remove("cmp-codeexp--open");
            if (current) {
                markRow(current, false);
            }
            var back = opener && document.documentElement.contains(opener) && !opener.closest("[hidden]") ?
                opener : null;
            current = null;
            if (back) {
                back.focus();
            } else {
                var heading = q("#cmp-codeexp-title");
                heading.setAttribute("tabindex", "-1");
                heading.focus();
            }
        }

        q("[data-cmp-codeexp-close]").addEventListener("click", closePanel);

        /* Tabs (ARIA tabs pattern) */
        function selectTab(tab, focus) {
            tab.parentNode.querySelectorAll('[role="tab"]').forEach(function (t) {
                var on = t === tab;
                t.setAttribute("aria-selected", on ? "true" : "false");
                t.tabIndex = on ? 0 : -1;
                var tp = document.getElementById(t.getAttribute("aria-controls"));
                if (tp) {
                    tp.hidden = !on;
                }
            });
            if (focus) {
                tab.focus();
            }
        }

        function tabKeys(e) {
            var tabs = Array.prototype.slice.call(e.currentTarget.querySelectorAll('[role="tab"]'));
            var i = tabs.indexOf(document.activeElement);
            var next = null;
            if (e.key === "ArrowRight") {
                next = tabs[(i + 1) % tabs.length];
            } else if (e.key === "ArrowLeft") {
                next = tabs[(i - 1 + tabs.length) % tabs.length];
            } else if (e.key === "Home") {
                next = tabs[0];
            } else if (e.key === "End") {
                next = tabs[tabs.length - 1];
            }
            if (next) {
                e.preventDefault();
                selectTab(next, true);
            }
        }

        qa('[role="tablist"]').forEach(function (tl) {
            tl.addEventListener("keydown", tabKeys);
            tl.addEventListener("click", function (e) {
                var tab = e.target.closest ? e.target.closest('[role="tab"]') : null;
                if (tab) {
                    selectTab(tab, false);
                }
            });
        });

        /* Form changes */
        form.addEventListener("input", function (e) {
            if (!current) {
                return;
            }
            if (e.target === desc) {
                updateCount();
            }
            if (e.target.getAttribute("aria-invalid") === "true") {
                setError(e.target, "");
            }
            readForm();
            setDirty(true);
        });
        form.addEventListener("change", function () {
            if (current) {
                readForm();
                setDirty(true);
            }
        });

        function updateCount() {
            var left = 500 - desc.value.length;
            count.textContent = left + " character" + (left === 1 ? "" : "s") + " left";
        }
        desc.setAttribute("aria-describedby", (desc.getAttribute("aria-describedby") || "") + " cx-desc-count");

        /* Split */
        q("[data-cmp-codeexp-split-btn]").addEventListener("click", function () {
            readForm();
            var d = state[current].draft;
            if (d.splits.length > 1) {
                fieldsFor(2).amount.focus();
                return;
            }
            var total = parseMoney(itemById(current).getAttribute("data-amount"));
            var half = Math.floor(total * 50) / 100;
            d.splits[0].amount = money(total - half);
            d.splits.push({ amount: money(half), taxCode: "N/A", tax: "0.00", cc: d.splits[0].cc, gl: "", pr: "" });
            var saved = state[current].saved.done;
            fillForm();
            setDirty(!saved);
            fieldsFor(2).amount.focus();
            announce(status, "Allocation 2 added. Amounts split 50/50.");
        });
        q("[data-cmp-codeexp-unsplit]").addEventListener("click", function () {
            readForm();
            var d = state[current].draft;
            d.splits = [d.splits[0]];
            d.splits[0].amount = money(itemById(current).getAttribute("data-amount"));
            fillForm();
            setDirty(true);
            fieldsFor(1).amount.focus();
            announce(status, "Allocation 2 removed.");
        });

        /* Spend Wizard + Expense template */
        function applyCoding(cc, gl, pr, source) {
            readForm();
            state[current].draft.splits.forEach(function (sp) {
                sp.cc = cc;
                sp.gl = gl;
                if (pr !== undefined) {
                    sp.pr = pr;
                }
            });
            [1, 2].forEach(function (n) {
                if (state[current].draft.splits[n - 1]) {
                    renderCells(n);
                }
            });
            setDirty(true);
            announce(status, source + " applied: Cost Center " + cc + " " + nameOf("cc", cc) +
                ", GL Account " + gl + " " + nameOf("gl", gl) + ".");
        }

        q("[data-cmp-codeexp-wizard]").addEventListener("click", function () {
            var s = SUGGEST[itemById(current).getAttribute("data-cat")] || ["FIN", "500070"];
            applyCoding(s[0], s[1], undefined, "Suggested coding");
        });

        function menuItems() {
            return Array.prototype.slice.call(tplMenu.querySelectorAll('[role="menuitem"]'));
        }
        function setMenu(open, focusFirst) {
            setPop(tplBtn, tplMenu, open);
            if (open && focusFirst) {
                menuItems()[0].focus();
            }
        }
        tplBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            setMenu(tplMenu.hidden, true);
        });
        tplBtn.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") {
                e.preventDefault();
                setMenu(true, true);
            }
        });
        tplMenu.addEventListener("keydown", function (e) {
            var its = menuItems();
            var i = its.indexOf(document.activeElement);
            if (e.key === "ArrowDown" || e.key === "ArrowUp") {
                e.preventDefault();
                its[(i + (e.key === "ArrowDown" ? 1 : -1) + its.length) % its.length].focus();
            } else if (e.key === "Escape" || e.key === "Esc") {
                e.preventDefault();
                e.stopPropagation();
                setMenu(false);
                tplBtn.focus();
            } else if (e.key === "Tab") {
                setMenu(false);
            }
        });
        tplMenu.querySelectorAll("[data-cmp-codeexp-tpl]").forEach(function (it) {
            it.addEventListener("click", function () {
                var p = it.getAttribute("data-cmp-codeexp-tpl").split("|");
                setMenu(false);
                tplBtn.focus();
                applyCoding(p[0], p[1], p[2], "Template " + it.textContent.trim());
            });
        });

        /* Code pickers */
        function renderOptions() {
            var term = pickerQ.value.trim().toLowerCase();
            var dim = pickerCtx.dim;
            var suggested = dim === "gl" ? (SUGGEST[itemById(current).getAttribute("data-cat")] || [])[1] : null;
            pickerList.textContent = "";
            var shown = 0;
            DIMS[dim].options.forEach(function (o) {
                if (term && (o[0] + " " + o[1]).toLowerCase().indexOf(term) === -1) {
                    return;
                }
                shown += 1;
                var li = el("li");
                var b = el("button", "cmp-codeexp__option");
                b.type = "button";
                b.setAttribute("data-code", o[0]);
                b.appendChild(el("span", "cmp-codeexp__code", o[0]));
                b.appendChild(el("span", "cmp-codeexp__codename", o[1]));
                if (o[0] === suggested) {
                    var star = el("span", "cmp-codeexp__star", "★");
                    star.setAttribute("aria-hidden", "true");
                    b.appendChild(star);
                    b.appendChild(el("span", "cmp-visually-hidden", ", suggested"));
                }
                li.appendChild(b);
                pickerList.appendChild(li);
            });
            pickerEmpty.hidden = shown > 0;
        }

        function openPicker(anchor, n, dim) {
            closePops();
            pickerCtx = { anchor: anchor, n: n, dim: dim };
            pickerTitle.textContent = "Choose " + DIMS[dim].label;
            pickerQ.value = "";
            renderOptions();
            picker.hidden = false;
            var pr = panel.getBoundingClientRect();
            var ar = anchor.getBoundingClientRect();
            picker.style.top = (ar.bottom - pr.top + panel.scrollTop + 4) + "px";
            picker.style.left = Math.max(8, Math.min(ar.left - pr.left, pr.width - picker.offsetWidth - 8)) + "px";
            pickerQ.focus();
        }

        function closePicker(restore) {
            if (picker.hidden) {
                return;
            }
            picker.hidden = true;
            if (restore && pickerCtx && document.documentElement.contains(pickerCtx.anchor)) {
                pickerCtx.anchor.focus();
            }
            pickerCtx = null;
        }

        pickerQ.addEventListener("input", renderOptions);
        picker.addEventListener("keydown", function (e) {
            var opts = Array.prototype.slice.call(pickerList.querySelectorAll("button"));
            var i = opts.indexOf(document.activeElement);
            if (e.key === "ArrowDown") {
                e.preventDefault();
                if (opts.length) {
                    opts[Math.min(i + 1, opts.length - 1)].focus();
                }
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                if (i <= 0) {
                    pickerQ.focus();
                } else {
                    opts[i - 1].focus();
                }
            } else if (e.key === "Escape" || e.key === "Esc") {
                e.preventDefault();
                e.stopPropagation();
                closePicker(true);
            } else if (e.key === "Enter" && document.activeElement === pickerQ && opts.length) {
                e.preventDefault();
                opts[0].click();
            }
        });
        pickerList.addEventListener("click", function (e) {
            var b = e.target.closest ? e.target.closest("[data-code]") : null;
            if (!b || !pickerCtx) {
                return;
            }
            var ctx = pickerCtx;
            readForm();
            state[current].draft.splits[ctx.n - 1][ctx.dim] = b.getAttribute("data-code");
            closePicker(false);
            renderCells(ctx.n);
            setDirty(true);
            setError(null, "", ctx.n);
            var again = fieldsFor(ctx.n).block.querySelector('[data-dim="' + ctx.dim + '"] [data-pick]');
            if (again) {
                again.focus();
            }
        });

        q(".cmp-codeexp__splits").addEventListener("click", function (e) {
            var pick = e.target.closest ? e.target.closest("[data-pick]") : null;
            var clear = e.target.closest ? e.target.closest("[data-clear]") : null;
            var block = e.target.closest ? e.target.closest("[data-cmp-codeexp-split]") : null;
            if (!block) {
                return;
            }
            var n = Number(block.getAttribute("data-cmp-codeexp-split"));
            if (pick) {
                e.stopPropagation();
                openPicker(pick, n, pick.getAttribute("data-pick"));
            } else if (clear) {
                var dim = clear.getAttribute("data-clear");
                readForm();
                state[current].draft.splits[n - 1][dim] = "";
                renderCells(n);
                setDirty(true);
                block.querySelector('[data-dim="' + dim + '"] [data-pick]').focus();
                announce(status, DIMS[dim].label + " removed");
            }
        });

        /* Validation + Complete / Update / Reset */
        function clearErrors() {
            formError.hidden = true;
            form.querySelectorAll("[aria-invalid]").forEach(function (n) { n.removeAttribute("aria-invalid"); });
            form.querySelectorAll(".cmp-field__err, [data-cmp-codeexp-split-err]").forEach(function (n) {
                n.hidden = true;
            });
        }

        function setError(input, message, n) {
            if (!input) {
                var box = fieldsFor(n).block.querySelector("[data-cmp-codeexp-split-err]");
                box.textContent = message;
                box.hidden = !message;
                return !message;
            }
            var err = document.getElementById(input.id + "-err");
            if (message) {
                input.setAttribute("aria-invalid", "true");
            } else {
                input.removeAttribute("aria-invalid");
            }
            if (err) {
                err.textContent = message;
                err.hidden = !message;
            }
            return !message;
        }

        function validate(full) {
            clearErrors();
            readForm();
            var d = state[current].draft;
            var total = parseMoney(itemById(current).getAttribute("data-amount"));
            var invalid = [];
            var sum = 0;
            d.splits.forEach(function (sp, i) {
                var fl = fieldsFor(i + 1);
                var amt = parseMoney(sp.amount);
                if (!setError(fl.amount, isNaN(amt) || amt <= 0 ? "Enter an amount greater than 0, e.g. 45.99." : "")) {
                    invalid.push(fl.amount);
                } else {
                    sum += amt;
                }
                var tax = parseMoney(sp.tax || "0");
                if (!setError(fl.tax, isNaN(tax) || (!isNaN(amt) && tax > amt) ?
                    "Enter a tax amount up to the allocation amount." : "")) {
                    invalid.push(fl.tax);
                }
                if (full) {
                    var missing = [];
                    if (!sp.cc) {
                        missing.push("Cost Center");
                    }
                    if (!sp.gl) {
                        missing.push("GL Account");
                    }
                    if (!setError(null, missing.length ? "Choose " + missing.join(" and ") + "." : "", i + 1)) {
                        invalid.push(fl.block.querySelector("[data-pick]"));
                    }
                }
            });
            if (!invalid.length && Math.round(sum * 100) !== Math.round(total * 100)) {
                setError(fieldsFor(1).amount, "Allocations must add up to " + money(total) + " USD (now " +
                    money(sum) + ").");
                invalid.push(fieldsFor(1).amount);
            }
            if (invalid.length) {
                formError.textContent = "Please fix the highlighted coding before continuing.";
                formError.hidden = false;
                invalid[0].focus();
                return false;
            }
            return true;
        }

        form.addEventListener("submit", function (e) {
            e.preventDefault();
            if (!current || state[current].saved.done || !validate(true)) {
                return;
            }
            var s = state[current];
            s.draft.done = true;
            s.saved = clone(s.draft);
            var name = itemById(current).getAttribute("data-merchant");
            var nextId = null;
            while (queue.length && !nextId) {
                var cand = queue.shift();
                if (!state[cand].saved.done) {
                    nextId = cand;
                }
            }
            var nextRow = null;
            var all = items();
            var idx = all.indexOf(itemById(current));
            for (var k = idx + 1; k < all.length && !nextRow; k++) {
                if (!all[k].hidden && !state[all[k].getAttribute("data-id")].saved.done) {
                    nextRow = all[k];
                }
            }
            showToast("Expense coded and submitted for approval.");
            announce(status, name + " submitted for approval and removed from the list.");
            if (nextId) {
                renderList(false);
                openPanel(nextId, opener);
                return;
            }
            /* Close the side panel, then drop the completed row from the list. */
            opener = nextRow ? nextRow.querySelector("[data-cmp-codeexp-open]") : null;
            closePanel();
            renderList(false);
        });

        updateBtn.addEventListener("click", function () {
            if (!validate(false)) {
                return;
            }
            var s = state[current];
            s.saved = clone(s.draft);
            setDirty(false);
            renderSummary();
            showToast("Expense coding saved.");
        });

        q("[data-cmp-codeexp-reset]").addEventListener("click", function () {
            state[current].draft = clone(state[current].saved);
            fillForm();
            announce(status, "Changes reset.");
        });

        /* Manage menu */
        manageBtn.addEventListener("click", function (e) {
            e.stopPropagation();
            var open = managePop.hidden;
            closePops();
            setPop(manageBtn, managePop, open);
            if (open) {
                managePop.querySelector("button").focus();
            }
        });
        q("[data-cmp-codeexp-library]").addEventListener("click", function () {
            setPop(manageBtn, managePop, false);
            openDialog("library", manageBtn);
        });
        q("[data-cmp-codeexp-thumb]").addEventListener("click", function (e) {
            openDialog("linked", e.currentTarget);
        });

        function closePops() {
            if (!filtersPop.hidden) {
                setPop(filtersBtn, filtersPop, false);
            }
            if (!managePop.hidden) {
                setPop(manageBtn, managePop, false);
            }
            if (!tplMenu.hidden) {
                setMenu(false);
            }
            closePicker(false);
        }

        document.addEventListener("click", function (e) {
            [[filtersBtn, filtersPop], [manageBtn, managePop], [tplBtn, tplMenu]].forEach(function (pair) {
                if (!pair[1].hidden && !pair[1].contains(e.target) && !pair[0].contains(e.target)) {
                    setPop(pair[0], pair[1], false);
                }
            });
            if (!picker.hidden && !picker.contains(e.target)) {
                closePicker(false);
            }
        });

        /* =====================================================
           Image Linking dialog
           ===================================================== */
        function renderImages() {
            var lists = { linked: q("[data-cmp-codeexp-linked]"), library: q("[data-cmp-codeexp-library-list]") };
            lists.linked.textContent = "";
            lists.library.textContent = "";
            var counts = { linked: 0, library: 0 };
            images.forEach(function (img) {
                var where = img.linkedTo === current ? "linked" : (img.linkedTo ? null : "library");
                if (!where) {
                    return;
                }
                counts[where] += 1;
                var li = el("li", "cmp-codeexp__imgitem");
                var b = el("button", "cmp-codeexp__imgbtn");
                b.type = "button";
                b.setAttribute("data-img", img.id);
                b.setAttribute("aria-label", img.name + (where === "linked" ? ", linked" : ", not linked") +
                    ". Image actions");
                var im = el("img");
                im.src = img.src;
                im.alt = "";
                im.width = 240;
                im.height = 300;
                im.style.transform = "rotate(" + img.rotate + "deg)";
                b.appendChild(im);
                var cap = el("span", "cmp-codeexp__imgname", img.name);
                cap.setAttribute("aria-hidden", "true");
                b.appendChild(cap);
                if (where === "linked") {
                    var ok = el("span", "cmp-codeexp__imgok", "✓");
                    ok.setAttribute("aria-hidden", "true");
                    b.appendChild(ok);
                }
                li.appendChild(b);
                lists[where].appendChild(li);
            });
            q("[data-cmp-codeexp-linked-empty]").hidden = counts.linked > 0;
            q("[data-cmp-codeexp-library-empty]").hidden = counts.library > 0;
        }

        function openDialog(tab, from) {
            if (!current) {
                return;
            }
            closePops();
            dialogOpener = from || document.activeElement;
            var d = info(itemById(current));
            q("[data-cmp-codeexp-dmeta]").textContent = "Big Bank 1: " + d.date.replace(/^0/, "") +
                "  Amount: $" + money(d.amount) + " USD";
            renderImages();
            selectTab(q(tab === "library" ? "#cx-itab-library" : "#cx-itab-linked"), false);
            modal.hidden = false;
            if (dialog.scrollIntoView) {
                dialog.scrollIntoView({ block: "nearest" });
            }
            q(tab === "library" ? "#cx-itab-library" : "#cx-itab-linked").focus({ preventScroll: true });
        }

        function closeImgPop(restore) {
            if (imgPop.hidden) {
                return;
            }
            imgPop.hidden = true;
            var back = imgCtx && dialog.querySelector('[data-img="' + imgCtx.id + '"]');
            imgCtx = null;
            if (restore && back) {
                back.focus();
            }
        }

        function closeDialog() {
            closeImgPop(false);
            modal.hidden = true;
            renderSummary();
            renderList(false);
            if (dialogOpener && document.documentElement.contains(dialogOpener)) {
                dialogOpener.focus();
            }
        }

        q("[data-cmp-codeexp-dclose]").addEventListener("click", closeDialog);
        q("[data-cmp-codeexp-backdrop]").addEventListener("click", closeDialog);

        q("[data-cmp-codeexp-upload]").addEventListener("click", function () { fileInput.click(); });
        fileInput.addEventListener("change", function () {
            var files = Array.prototype.slice.call(fileInput.files || []);
            var added = 0;
            var rejected = 0;
            var pending = files.length;
            function doneOne() {
                pending -= 1;
                if (pending === 0) {
                    renderImages();
                    selectTab(q("#cx-itab-library"), false);
                    announce(dstatus, added + " receipt" + (added === 1 ? "" : "s") + " added to the Image Library" +
                        (rejected ? ", " + rejected + " skipped (images up to 10 MB only)" : "") + ".");
                }
            }
            files.forEach(function (file) {
                if (!/^image\//.test(file.type) || file.size > MAX_UPLOAD) {
                    rejected += 1;
                    doneOne();
                    return;
                }
                var reader = new FileReader();
                reader.addEventListener("load", function () {
                    imgSeq += 1;
                    images.push({ id: "img-up-" + imgSeq, name: file.name, src: String(reader.result),
                        rotate: 0, linkedTo: null });
                    added += 1;
                    doneOne();
                });
                reader.addEventListener("error", function () {
                    rejected += 1;
                    doneOne();
                });
                reader.readAsDataURL(file);
            });
            fileInput.value = "";
        });

        var emailBtn = q("[data-cmp-codeexp-email]");
        emailBtn.addEventListener("click", function () {
            var infoBox = q("[data-cmp-codeexp-emailinfo]");
            infoBox.hidden = !infoBox.hidden;
            emailBtn.setAttribute("aria-expanded", infoBox.hidden ? "false" : "true");
        });

        dialog.addEventListener("click", function (e) {
            var b = e.target.closest ? e.target.closest("[data-img]") : null;
            if (!b) {
                return;
            }
            var img = images.filter(function (i) { return i.id === b.getAttribute("data-img"); })[0];
            if (!img) {
                return;
            }
            imgCtx = img;
            q("[data-cmp-codeexp-imgname]").textContent = img.name;
            imgPop.querySelector('[data-cmp-codeexp-img="link"]').textContent = img.linkedTo ? "Unlink" : "Link";
            var zoom = imgPop.querySelector('[data-cmp-codeexp-img="zoom"]');
            zoom.setAttribute("aria-pressed", b.parentNode.classList.contains("is-zoomed") ? "true" : "false");
            imgPop.hidden = false;
            var dr = dialog.getBoundingClientRect();
            var br = b.getBoundingClientRect();
            imgPop.style.top = Math.max(8, br.top - dr.top + dialog.scrollTop + br.height * 0.55) + "px";
            imgPop.style.left = Math.min(br.right - dr.left - 24, dr.width - imgPop.offsetWidth - 8) + "px";
            zoom.focus();
        });

        q("[data-cmp-codeexp-imgclose]").addEventListener("click", function () { closeImgPop(true); });

        imgPop.addEventListener("click", function (e) {
            var act = e.target.closest ? e.target.closest("[data-cmp-codeexp-img]") : null;
            if (!act || !imgCtx) {
                return;
            }
            var a = act.getAttribute("data-cmp-codeexp-img");
            var img = imgCtx;
            var btn = dialog.querySelector('[data-img="' + img.id + '"]');
            if (a === "zoom") {
                var z = btn.parentNode.classList.toggle("is-zoomed");
                act.setAttribute("aria-pressed", z ? "true" : "false");
                announce(dstatus, img.name + (z ? " enlarged" : " reduced"));
            } else if (a === "left" || a === "right") {
                img.rotate = (img.rotate + (a === "left" ? -90 : 90) + 360) % 360;
                btn.querySelector("img").style.transform = "rotate(" + img.rotate + "deg)";
                announce(dstatus, img.name + " rotated " + (a === "left" ? "left" : "right"));
                } else if (a === "link") {
                var linking = !img.linkedTo;
                img.linkedTo = linking ? current : null;
                if (linking && state[current]) {
                    state[current].draft.receiptAttached = "Yes";
                    state[current].saved.receiptAttached = "Yes";
                    rcptSel.value = "Yes";
                }
                closeImgPop(false);
                if (linking) {
                    /* Linked: close Image Linking and go back to the coding form. */
                    closeDialog();
                    selectTab(q("#cx-tab-coding"), false);
                    announce(status, img.name + " linked to this expense. Receipt attached.");
                } else {
                    renderImages();
                    selectTab(q("#cx-itab-library"), true);
                    announce(dstatus, img.name + " moved to the Image Library");
                }
                } else if (a === "delete") {
                images = images.filter(function (i) { return i !== img; });
                closeImgPop(false);
                renderImages();
                dialog.querySelector('.cmp-codeexp__dtabs [aria-selected="true"]').focus();
                announce(dstatus, img.name + " deleted");
                }
        });

        /* =====================================================
           Keyboard: Esc + focus trap
           ===================================================== */
        document.addEventListener("keydown", function (e) {
            var esc = e.key === "Escape" || e.key === "Esc";
            if (!modal.hidden) {
                if (esc) {
                    e.preventDefault();
                    if (!imgPop.hidden) {
                        closeImgPop(true);
                    } else {
                        closeDialog();
                    }
                } else if (e.key === "Tab") {
                    trap(dialog, e);
                }
                return;
            }
            if (!esc || e.defaultPrevented) {
                return;
            }
            if (!filtersPop.hidden) {
                setPop(filtersBtn, filtersPop, false);
                filtersBtn.focus();
            } else if (!managePop.hidden) {
                setPop(manageBtn, managePop, false);
                manageBtn.focus();
            } else if (!picker.hidden) {
                closePicker(true);
            } else if (!panel.hidden && panel.contains(document.activeElement)) {
                closePanel();
            }
        });

        renderList(false);
    }

    function safeInit(root) {
        try {
            init(root);
        } catch (err) {
            window.console.warn("VSC Code Expenses could not start", err);
        }
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-codeexp]")) {
            safeInit(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-codeexp]"), safeInit);
        }
    }

    function boot() {
        scan(document);
        /* AEM editor re-renders components after edits; enhance the new markup. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Transactions — updates the dashboard numbers for the chosen Show / Recent Periods.
   Demo data below mirrors the Figma (May 2026 = 1 transaction, 1.00 USD debit).
   Replace DATA with a service call when a backend is available. */
(function () {
    "use strict";

    var DATA = {
        "All requests": {
            "05/01/2026 to 05/31/2026": { total: 1, coding: 0, pending: 0, txns: 1, debit: "1.00", credit: "0.00" },
            "04/01/2026 to 04/30/2026": { total: 6, coding: 2, pending: 1, txns: 6, debit: "842.17", credit: "25.00" },
            "03/01/2026 to 03/31/2026": { total: 4, coding: 0, pending: 3, txns: 4, debit: "1,120.40", credit: "0.00" }
        },
        "My requests": {
            "05/01/2026 to 05/31/2026": { total: 1, coding: 0, pending: 0, txns: 1, debit: "1.00", credit: "0.00" },
            "04/01/2026 to 04/30/2026": { total: 3, coding: 1, pending: 1, txns: 3, debit: "412.35", credit: "0.00" },
            "03/01/2026 to 03/31/2026": { total: 2, coding: 0, pending: 2, txns: 2, debit: "615.20", credit: "0.00" }
        }
    };

    function init(root) {
        if (!root || root.__vtxnInit) {
            return;
        }
        root.__vtxnInit = true;

        var scope = root.querySelector("#cmp-vtxn-scope");
        var period = root.querySelector("#cmp-vtxn-period");
        var range = root.querySelector("[data-cmp-vtxn-range]");
        var status = root.querySelector("[data-cmp-vtxn-status]");
        if (!scope || !period) {
            return;
        }

        function set(key, value) {
            var node = root.querySelector('[data-cmp-vtxn="' + key + '"]');
            if (node) {
                node.textContent = String(value);
            }
        }

        function arc(key, value, total) {
            var path = root.querySelector('[data-cmp-vtxn-arc="' + key + '"]');
            if (path) {
                var pct = total > 0 ? Math.max(0, Math.min(100, (value / total) * 100)) : 0;
                path.setAttribute("stroke-dasharray", (pct > 0 ? pct.toFixed(1) : "0") + " 100");
            }
        }

        function render(announce) {
            var group = DATA[scope.value] || DATA["All requests"];
            var d = group[period.value];
            if (!d) {
                return;
            }
            range.textContent = period.value;
            ["total", "coding", "pending", "txns", "debit", "credit"].forEach(function (k) { set(k, d[k]); });
            arc("coding", d.coding, d.total);
            arc("pending", d.pending, d.total);
            if (announce) {
                status.textContent = scope.value + ", " + period.value + ": " + d.txns + " transaction" +
                    (d.txns === 1 ? "" : "s") + ", " + d.coding + " coding required, " + d.pending +
                    " pending approval.";
            }
        }

        scope.addEventListener("change", function () { render(true); });
        period.addEventListener("change", function () { render(true); });
        render(false);
    }

    function scan(node) {
        if (node.matches && node.matches("[data-cmp-vtxn]")) {
            init(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-vtxn]"), init);
        }
    }

    function boot() {
        scan(document);
        /* AEM editor re-renders components after edits; enhance the new markup. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            scan(node);
                        }
                    });
                });
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* Three Column Grid — aligns the columns with letters in the header navigation.
   start: end of the 2nd tab's label ("My Spend").
   left column end / middle start: the last "r" in the "Virtual Cards" label
   (left edge of the "r" / the letter after it). Right column = left column width.
   Works with cmp-header and cmp-vscheader. Sets CSS custom properties only. */
(function () {
    "use strict";

    var NAV_ITEMS = ".cmp-header__nav-list > .cmp-header__nav-item, " +
        ".cmp-vscheader__nav-list > .cmp-vscheader__item";
    var TAB = ".cmp-header__nav-link, .cmp-vscheader__nav-link";
    var grids = [];
    var frame = 0;

    function textNode(el, pattern) {
        var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
        var node = walker.nextNode();
        while (node) {
            if (pattern.test(node.nodeValue)) {
                return node;
            }
            node = walker.nextNode();
        }
        return null;
    }

    function measure() {
        var items = Array.prototype.slice.call(document.querySelectorAll(NAV_ITEMS));
        if (items.length < 2) {
            return null;
        }
        var second = items[1].querySelector(TAB);
        if (!second || !second.offsetWidth) {
            return null;
        }
        var start = second.getBoundingClientRect().right -
            (parseFloat(window.getComputedStyle(second).paddingRight) || 0);
        var vc = null;
        items.some(function (item) {
            var tab = item.querySelector(TAB);
            var node = tab ? textNode(tab, /virtual\s+cards/i) : null;
            if (node) {
                vc = node;
                return true;
            }
            return false;
        });
        if (!vc) {
            return null;
        }
        var i = vc.nodeValue.toLowerCase().lastIndexOf("r");
        if (i < 0) {
            return null;
        }
        var range = document.createRange();
        range.setStart(vc, i);
        range.setEnd(vc, i + 1);
        var r = range.getBoundingClientRect();
        if (!r.width) {
            return null;
        }
        return { start: start, rLeft: r.left, rRight: r.right };
    }

    function align(grid, m) {
        if (!m) {
            ["--cmp-grid-start", "--cmp-grid-col", "--cmp-grid-gap"].forEach(function (v) {
                grid.style.removeProperty(v);
            });
            return;
        }
        var origin = grid.getBoundingClientRect().left;
        var start = m.start - origin;
        var col = m.rLeft - m.start;
        var gap = m.rRight - m.rLeft;
        if (start < 0 || col <= 0) {
            return;
        }
        grid.style.setProperty("--cmp-grid-start", start.toFixed(2) + "px");
        grid.style.setProperty("--cmp-grid-col", col.toFixed(2) + "px");
        grid.style.setProperty("--cmp-grid-gap", gap.toFixed(2) + "px");
    }

    function alignAll() {
        frame = 0;
        grids = grids.filter(function (g) { return document.documentElement.contains(g); });
        if (!grids.length) {
            return;
        }
        var m = measure();
        grids.forEach(function (g) { align(g, m); });
    }

    function schedule() {
        if (!frame) {
            frame = window.requestAnimationFrame(alignAll);
        }
    }

    function register(node) {
        var added = false;
        function add(g) {
            if (grids.indexOf(g) < 0) {
                grids.push(g);
                added = true;
            }
        }
        if (node.matches && node.matches("[data-cmp-threecol]")) {
            add(node);
        }
        if (node.querySelectorAll) {
            Array.prototype.forEach.call(node.querySelectorAll("[data-cmp-threecol]"), add);
        }
        if (added) {
            schedule();
        }
    }

    function boot() {
        register(document);
        window.addEventListener("resize", schedule);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(schedule);
        }
        if (window.ResizeObserver) {
            var observer = new window.ResizeObserver(schedule);
            Array.prototype.forEach.call(document.querySelectorAll(NAV_ITEMS), function (item) {
                observer.observe(item);
            });
        }
        /* AEM editor re-renders components after edits. */
        if (window.MutationObserver) {
            new window.MutationObserver(function (records) {
                var changed = false;
                records.forEach(function (record) {
                    Array.prototype.forEach.call(record.addedNodes, function (node) {
                        if (node.nodeType === 1) {
                            register(node);
                            changed = true;
                        }
                    });
                });
                if (changed && grids.length) {
                    schedule();
                }
            }).observe(document.body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
/* VSC Guided Journey — demo tour across the Spend Clarity pages.
   - Chapters menu (bottom left): jump to any chapter (navigates when needed).
   - Each step shows a popover (Back / Next), an optional yellow hotspot ring on the
     target, and runs idempotent "prepare" actions on the existing components so the
     screen matches the Figma (open menus and drawers, fill the demo employee, submit).
   - Progress lives in sessionStorage for the browser tab, so the journey continues
     on the next page. Esc or the close button ends the journey.
   - Popovers are non-modal dialogs: focus moves to them, they are announced, and the
     page underneath stays usable (hotspots can be clicked). */
(function () {
    "use strict";

    var KEY = "vsc-tour";
    var DEMO = {
        search: "Everett",
        addressLine2: "(09) 4994991",
        creditLimit: "2000",
        authStrategy: "Cash Blocked",
        name: "Daniel Everett"
    };

    function q(sel, root) {
        return (root || document).querySelector(sel);
    }

    function visible(el) {
        return !!el && !el.closest("[hidden]") && el.getClientRects().length > 0;
    }

    function setValue(input, value) {
        if (input && input.value !== value) {
            input.value = value;
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.dispatchEvent(new Event("change", { bubbles: true }));
        }
    }

    /* ---------- actions on the existing Card Listing component ---------- */
    function cardlist() {
        return q("[data-cmp-cardlist]");
    }

    function closeCardUi() {
        var root = cardlist();
        if (!root) {
            return;
        }
        ["[data-cmp-empsearch-drawer]", "[data-cmp-createcard-drawer]"].forEach(function (sel) {
            var d = q(sel, root);
            if (d && !d.hidden) {
                var close = d.querySelector("[data-cmp-empsearch-close], [data-cmp-createcard-close]");
                if (close) {
                    close.click();
                }
            }
        });
    }

    function setCreateMenu(open) {
        var root = cardlist();
        var menu = root && q("#cmp-cardlist-create-menu", root);
        var trigger = root && q("[data-cmp-create-trigger]", root);
        if (menu && trigger && menu.hidden === open) {
            trigger.click();
        }
    }

    function ensureEmployeeSearch() {
        var root = cardlist();
        if (!root) {
            return;
        }
        var drawer = q("[data-cmp-empsearch-drawer]", root);
        var card = q("[data-cmp-createcard-drawer]", root);
        if (card && !card.hidden) {
            q("[data-cmp-createcard-close]", card).click();
        }
        if (drawer && drawer.hidden) {
            setCreateMenu(true);
            var opt = q('[data-cmp-create-option="existing"]', root);
            if (opt) {
                opt.click();
            }
        }
        setValue(q("[data-cmp-empsearch-input]", root), DEMO.search);
    }

    function ensureCardForm(full) {
        var root = cardlist();
        if (!root) {
            return;
        }
        var card = q("[data-cmp-createcard-drawer]", root);
        if (card && card.hidden) {
            ensureEmployeeSearch();
            var select = q('[data-cmp-empsearch-results] button[aria-label="Select ' + DEMO.name + '"]', root);
            if (!select) {
                select = q("[data-cmp-empsearch-results] button", root);
            }
            if (select) {
                select.click();
            }
        }
        var form = q("[data-cmp-createcard-form]", root);
        if (!form) {
            return;
        }
        setValue(form.elements.addressLine2, DEMO.addressLine2);
        if (full) {
            setValue(form.elements.creditLimit, DEMO.creditLimit);
            setValue(form.elements.authStrategy, DEMO.authStrategy);
        }
    }

    function hasDemoRow() {
        var root = cardlist();
        var names = root ? root.querySelectorAll(".cmp-cardlist__fullname") : [];
        return Array.prototype.some.call(names, function (n) {
            return n.textContent.trim() === DEMO.name;
        });
    }

    function submitCard() {
        var root = cardlist();
        if (!root) {
            return;
        }
        if (hasDemoRow()) {
            closeCardUi();
            return;
        }
        ensureCardForm(true);
        var form = q("[data-cmp-createcard-form]", root);
        if (form && typeof form.requestSubmit === "function") {
            form.requestSubmit();
        } else if (form) {
            form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
        }
    }

    function demoRow() {
        var root = cardlist();
        var hit = null;
        if (root) {
            Array.prototype.some.call(root.querySelectorAll(".cmp-cardlist__fullname"), function (n) {
                if (n.textContent.trim() === DEMO.name) {
                    hit = n.closest("tr");
                    return true;
                }
                return false;
            });
        }
        return hit;
    }


    /* ---------- actions on the existing Virtual Cards component ---------- */
    var VC = {
        desc: "Ad hoc office supplies purchase", spend: "250.00", start: "2026-06-25", end: "2026-07-25",
        currency: "US Dollar", spendType: "Single use virtual card", employee: "AMILLER01", name: "Alex Miller"
    };

    function vcRoot() {
        return q("[data-cmp-vclist]");
    }

    function vcDrawer() {
        var root = vcRoot();
        return root ? q("[data-cmp-vclist-drawer]", root) : null;
    }

    function vcStep() {
        var d = vcDrawer();
        return d && !d.hidden ? Number(d.getAttribute("data-step")) || 1 : 0;
    }

    function vcCloseDrawer() {
        var d = vcDrawer();
        if (d && !d.hidden) {
            var close = q("[data-cmp-vclist-close]", d);
            if (close) {
                close.click();
            }
        }
    }

    function vcNext() {
        var d = vcDrawer();
        var btn = d ? q("[data-cmp-vcwiz-next]", d) : null;
        if (btn && visible(btn)) {
            btn.click();
        }
    }

    function selectByText(select, text) {
        if (!select) {
            return;
        }
        var opt = Array.prototype.filter.call(select.options, function (o) {
            return o.text.trim() === text || o.value === text;
        })[0];
        if (opt) {
            setValue(select, opt.value);
        }
    }

    function vcEnsureDetails() {
        var root = vcRoot();
        if (!root) {
            return;
        }
        if (!vcStep()) {
            var add = q("[data-cmp-vclist-add-trigger]", root);
            if (add) {
                add.click();
            }
        }
        if (vcStep() === 1) {
            setValue(q("#vcf-desc", root), VC.desc);
            setValue(q("#vcf-spend", root), VC.spend);
            setValue(q("#vcf-start", root), VC.start);
            setValue(q("#vcf-end", root), VC.end);
            selectByText(q("#vcf-currency", root), VC.currency);
            selectByText(q("#vcf-spendtype", root), VC.spendType);
        }
    }

    function vcEnsureEmployees() {
        vcEnsureDetails();
        if (vcStep() === 1) {
            vcNext();
        }
        var root = vcRoot();
        if (vcStep() !== 2 || !root) {
            return;
        }
        var empty = q("[data-cmp-vcemp-empty]", root);
        if (empty && !empty.hidden) {
            var add = q("[data-cmp-vcemp-add]", root);
            if (add) {
                add.click();
            }
            var box = q('[data-cmp-vcemp-modal] input[value="' + VC.employee + '"]', root);
            if (box && !box.checked) {
                box.click();
            }
            var ok = q("[data-cmp-vcemp-confirm]", root);
            if (ok) {
                ok.click();
            }
        }
    }

    function vcEnsureReview() {
        vcEnsureEmployees();
        if (vcStep() === 2) {
            vcNext();
        }
    }

    function vcRow() {
        var root = vcRoot();
        var hit = null;
        if (root) {
            Array.prototype.some.call(root.querySelectorAll(".cmp-vclist__name"), function (n) {
                if (n.textContent.trim() === VC.name) {
                    hit = n.closest("tr");
                    return true;
                }
                return false;
            });
        }
        return hit;
    }

    var vcCreated = false;

    function vcCreate() {
        var root = vcRoot();
        if (!root || vcRow() || vcCreated) {
            vcCloseDrawer();
            return;
        }
        if (vcStep() !== 3) {
            vcEnsureReview();
        }
        var create = q("[data-cmp-vcwiz-create]", root);
        if (create && visible(create)) {
            vcCreated = true;
            create.click();
        }
    }

    /* ---------- actions on the existing Expense Categories component ---------- */
    var EC = { type: "GL Account", value: "500050", desc: "Office Supplies" };

    function ecRoot() {
        return q("[data-cmp-expcat]");
    }

    function ecCloseDialog() {
        var root = ecRoot();
        var modal = root ? q("[data-cmp-expcat-modal]", root) : null;
        if (modal && !modal.hidden) {
            var cancel = q("[data-cmp-expcat-cancel]", modal) || q("[data-cmp-expcat-close]", modal);
            if (cancel) {
                cancel.click();
            }
        }
    }

    function ecHasRow() {
        var root = ecRoot();
        return !!root && !!q('[data-cmp-expcat-row][data-value="' + EC.value + '"]', root);
    }

    function ecEnsureDialog() {
        var root = ecRoot();
        if (!root || ecHasRow()) {
            return;
        }
        var modal = q("[data-cmp-expcat-modal]", root);
        if (modal && modal.hidden) {
            var create = q("[data-cmp-expcat-create]", root);
            if (create) {
                create.click();
            }
        }
        selectByText(q("#ecf-type", root), EC.type);
        setValue(q("#ecf-value", root), EC.value);
        setValue(q("#ecf-desc", root), EC.desc);
    }

    function ecSave() {
        var root = ecRoot();
        if (!root) {
            return;
        }
        if (ecHasRow()) {
            ecCloseDialog();
            return;
        }
        ecEnsureDialog();
        var save = q("[data-cmp-expcat-save]", root);
        if (save) {
            save.click();
        }
    }

    /* ---------- actions on the existing Code Expenses component ---------- */
    var CX = { id: "e01", gl: "500050", library: "IMG002.jpg" };

    function cxRoot() {
        return q("[data-cmp-codeexp]");
    }

    function cxModal() {
        var root = cxRoot();
        return root ? q("[data-cmp-codeexp-modal]", root) : null;
    }

    function cxCloseDialog() {
        var m = cxModal();
        if (m && !m.hidden) {
            q("[data-cmp-codeexp-dclose]", m).click();
        }
    }

    function cxCloseManage() {
        var root = cxRoot();
        var pop = root ? q("#cx-manage", root) : null;
        if (pop && !pop.hidden) {
            q("[data-cmp-codeexp-manage]", root).click();
        }
    }

    function cxEnsurePanel() {
        var root = cxRoot();
        if (!root) {
            return;
        }
        var row = q('[data-cmp-codeexp-item][data-id="' + CX.id + '"]', root);
        var panel = q("[data-cmp-codeexp-panel]", root);
        if (row && !row.hidden && panel && (panel.hidden || !row.classList.contains("is-current"))) {
            q("[data-cmp-codeexp-open]", row).click();
        }
    }

    function cxClosePanel() {
        cxCloseDialog();
        var root = cxRoot();
        var panel = root ? q("[data-cmp-codeexp-panel]", root) : null;
        if (panel && !panel.hidden) {
            q("[data-cmp-codeexp-close]", root).click();
        }
    }

    function cxPickGl(keepOpen) {
        var root = cxRoot();
        var cell = root ? q('[data-cmp-codeexp-split="1"] [data-dim="gl"]', root) : null;
        if (!cell || cell.querySelector("[data-clear]")) {
            return;
        }
        var pick = q("[data-pick]", cell);
        if (pick) {
            pick.click();
        }
        if (!keepOpen) {
            var opt = q('[data-cmp-codeexp-options] [data-code="' + CX.gl + '"]', root);
            if (opt) {
                opt.click();
            }
        }
    }

    function cxEnsureDialog(tab) {
        var root = cxRoot();
        var m = cxModal();
        if (!root || !m) {
            return;
        }
        cxCloseManage();
        if (m.hidden) {
            q("[data-cmp-codeexp-thumb]", root).click();
        }
        var t = q(tab === "library" ? "#cx-itab-library" : "#cx-itab-linked", root);
        if (t && t.getAttribute("aria-selected") !== "true") {
            t.click();
        }
    }

    function cxLibraryImage() {
        var root = cxRoot();
        var btns = root ? root.querySelectorAll("[data-cmp-codeexp-library-list] [data-img]") : [];
        return Array.prototype.filter.call(btns, function (b) {
            return (b.getAttribute("aria-label") || "").indexOf(CX.library) === 0;
        })[0] || btns[0] || null;
    }

    function cxEnsureImageActions() {
        cxEnsurePanel();
        cxEnsureDialog("library");
        var root = cxRoot();
        var pop = root ? q("[data-cmp-codeexp-imgpop]", root) : null;
        var img = cxLibraryImage();
        if (pop && pop.hidden && img) {
            img.click();
        }
    }

    function cxLinkAndReturn() {
        cxEnsurePanel();
        var root = cxRoot();
        var m = cxModal();
        if (!root) {
            return;
        }
        var pop = q("[data-cmp-codeexp-imgpop]", root);
        if (m && !m.hidden && pop && !pop.hidden) {
            var link = q('[data-cmp-codeexp-img="link"]', root);
            if (link && link.textContent.trim() === "Link") {
                link.click();
            }
        }
        cxCloseDialog();
        var coding = q("#cx-tab-coding", root);
        if (coding && coding.getAttribute("aria-selected") !== "true") {
            coding.click();
        }
        cxPickGl(false);
    }

    function cxComplete() {
        var root = cxRoot();
        var btn = root ? q("[data-cmp-codeexp-complete]", root) : null;
        if (btn && visible(btn) && !btn.disabled) {
            btn.click();
        }
    }

    /* Popovers for steps inside a drawer sit outside it (left of the panel), as in the Figma. */
    var DRAWER = ".cmp-drawer:not([hidden]) .cmp-drawer__panel";

    /* ---------- journey definition ---------- */
    var STEPS = [
        { id: "welcome", chapter: "start", page: "home", center: true, title: "Spend Clarity for Enterprise",
            subtitle: "Take Control of Company Spend",
            text: ["Transform how your business manages spend with a platform that brings visibility and " +
                "control together, so you can manage cards, transactions, and expenses with confidence."],
            next: "Start Demo", back: false },
        { id: "hotspots", chapter: "start", page: "home", target: "nav:Cards",
            place: "bottom", ring: true,
            text: ["Click on hotspots or the ", { b: "Next" }, " button to proceed through the demo"],
            back: false, hint: "Use the chapters menu to quickly navigate through the features in this demo",
            hotspotNext: true },
        { id: "cards-intro", chapter: "cards", page: "cards", center: true, title: "Create and Manage Commercial Cards",
            text: ["Administrators can create and manage commercial card programs, assign cards to employees, and " +
                "apply spend controls such as transaction limits and merchant restrictions, helping maintain " +
                "control over company spend."], back: false,
            prepare: function () { setCreateMenu(false); closeCardUi(); } },
        { id: "create-card", chapter: "cards", page: "cards", target: "[data-cmp-create-trigger]", place: "left",
            ring: true,
            text: ["Clicking ", { b: "Create card" }, " opens the new card setup flow"],
            prepare: function () { closeCardUi(); setCreateMenu(false); } },
        { id: "existing", chapter: "cards", page: "cards", target: '[data-cmp-create-option="existing"]', place: "left",
            ring: true,
            text: ["Select ", { b: "Create card for existing employee" }, " to create a card for an employee"],
            prepare: function () { closeCardUi(); setCreateMenu(true); } },
        { id: "search", chapter: "cards", page: "cards", outside: DRAWER, target: "[data-cmp-empsearch-results] button",
            place: "left", ring: true,
            text: ["User can search by name or ID and selects an employee to assign the card"],
            prepare: ensureEmployeeSearch },
        { id: "controls", chapter: "cards", page: "cards", outside: DRAWER, target: "#cf-authstrat",
            place: "left", ring: true,
            scroll: "#cf-creditlimit",
            text: ["Configure card controls including spending limits and merchant category restrictions based " +
                "on company policies"],
            prepare: function () { ensureCardForm(false); } },
        { id: "submit", chapter: "cards", page: "cards", outside: DRAWER,
            target: '[data-cmp-createcard-form] button[type="submit"]',
            place: "left", ring: true,
            text: ["With the cardholder selected and account limits configured, the user clicks ", { b: "Submit" },
                " to issue the card"],
            prepare: function () { ensureCardForm(true); } },
        { id: "created", chapter: "cards", page: "cards", target: "row", place: "bottom",
            text: ["The card is successfully created and is added to the cardholders list"],
            next: "\u2192 Issue Virtual Cards", prepare: submitCard },
        { id: "virtual-intro", chapter: "virtual", page: "virtual", center: true, title: "Issue Virtual Cards",
            text: ["When a purchase is needed, a virtual card can be quickly issued with controls such as spend " +
                "limits, usage types including single-use or multi-use, and merchant restrictions, enabling " +
                "faster, more secure payments."], back: "flow",
            prepare: vcCloseDrawer },
        { id: "add-virtual", chapter: "virtual", page: "virtual", target: "[data-cmp-vclist-add-trigger]",
            place: "top", ring: true,
            text: ["Clicking ", { b: "Add virtual cards" }, " initiates the setup for a new virtual card"],
            prepare: vcCloseDrawer },
        { id: "vc-details", chapter: "virtual", page: "virtual", outside: DRAWER, target: "[data-cmp-vcwiz-next]",
            place: "left", ring: true, anchorY: "#vcf-desc",
            text: ["First, the user enters the virtual card details"],
            prepare: function () {
                vcCloseDrawer();
                vcEnsureDetails();
            } },
        { id: "vc-employees", chapter: "virtual", page: "virtual", outside: DRAWER, target: "[data-cmp-vcwiz-next]",
            place: "left", ring: true, anchorY: "[data-cmp-vcemp-add]",
            text: ["User then selects which employees will receive the virtual card"],
            prepare: function () {
                if (vcStep() === 3) {
                    q("[data-cmp-vcwiz-back]").click();
                }
                vcEnsureEmployees();
            } },
        { id: "vc-review", chapter: "virtual", page: "virtual", outside: DRAWER, target: "[data-cmp-vcwiz-create]",
            place: "left", ring: true,
            extra: { target: ".cmp-vcwiz__section--mcc", outside: DRAWER, place: "left",
                text: "Administrators can set virtual card policies to block specific merchant category groups" },
            text: ["With recipients selected, the user reviews the card details and creates the card"],
            prepare: vcEnsureReview },
        { id: "vc-creating", chapter: "virtual", page: "virtual", target: '[data-cmp-toast="vclist"]',
            place: "left", text: ["Virtual card creation is not instant and is dependent on issuers"],
            prepare: vcCreate },
        { id: "vc-added", chapter: "virtual", page: "virtual", target: "vcrow", place: "bottom", wait: 2500,
            text: ["After the card has been created it is added to the list of virtual cards"],
            next: "\u2192 Manage Expense Categories", prepare: vcCreate },

        { id: "categories-intro", chapter: "categories", page: "categories", center: true,
            title: "Manage Expense Categories",
            text: ["Expense categories are defined and managed to ensure consistent coding, enabling accurate " +
                "reporting and seamless integration with downstream systems."], back: "flow",
            prepare: ecCloseDialog },
        { id: "create-code", chapter: "categories", page: "categories", target: "[data-cmp-expcat-create]",
            place: "bottom", ring: true, text: ["Click ", { b: "Create" }, " to quickly add a new expense code"],
            prepare: ecCloseDialog },
        { id: "ec-form", chapter: "categories", page: "categories", outside: ".cmp-expcat__dialog",
            target: "[data-cmp-expcat-save]", place: "left", ring: true, anchorY: "#ecf-adv",
            text: ["Administrators can create new charge codes, either manually or by uploading a spreadsheet " +
                "to batch create multiple codes"],
            prepare: ecEnsureDialog },
        { id: "ec-created", chapter: "categories", page: "categories", target: '[data-cmp-toast="expcat"]',
            place: "left", wait: 1500,
            text: ["Once created, the charge codes becomes active and is immediately available for expense coding"],
            next: "\u2192 Code Expenses & Attach Receipts", prepare: ecSave },

        { id: "coding-intro", chapter: "coding", page: "coding", center: true, title: "Code Expenses & Attach Receipts",
            text: ["Transactions can be quickly coded to company-defined categories and receipts attached directly " +
                "from mobile or desktop, helping ensure accurate reconciliation, audit readiness, and streamlined " +
                "financial reporting."], back: "flow",
            prepare: cxClosePanel },
        { id: "pick-expense", chapter: "coding", page: "coding", target: '[data-id="e01"] [data-cmp-codeexp-open]',
            place: "bottom", ring: true,
            text: ["User selects an expense from the list to begin the coding and receipt flow"],
            prepare: cxClosePanel },
        { id: "cx-details", chapter: "coding", page: "coding", outside: ".cmp-codeexp__panel",
            target: '[data-cmp-codeexp-split="1"] [data-dim="gl"] [data-cmp-codeexp-cell]', place: "left",
            ring: true, text: ["The user reviews the transaction details and enters expense details."],
            prepare: function () {
                cxCloseDialog();
                cxEnsurePanel();
                cxPickGl(true);
            } },
        { id: "cx-manage", chapter: "coding", page: "coding", target: "[data-cmp-codeexp-manage]", place: "left",
            ring: true, anchorY: "#cx-manage",
            extra: { target: "[data-cmp-codeexp-thumb]", place: "left",
                text: "Spend Clarity can automatically link receipts to the appropriate expense" },
            text: ["Users can also manually upload and manage additional receipts if needed"],
            prepare: function () {
                cxCloseDialog();
                cxEnsurePanel();
                cxPickGl(false);
                var root = cxRoot();
                var pop = root ? q("#cx-manage", root) : null;
                if (pop && pop.hidden) {
                    q("[data-cmp-codeexp-manage]", root).click();
                }
            } },
        { id: "cx-upload", chapter: "coding", page: "coding", target: "[data-cmp-codeexp-upload]", place: "bottom",
            ring: true, text: ["Additional receipts can be uploaded to the image library via mobile, local drive, " +
                "or email"],
            prepare: function () {
                cxEnsurePanel();
                cxEnsureDialog("linked");
            } },
        { id: "cx-mobile", chapter: "coding", page: "coding", stage: "phone", target: ".cmp-vtour__shutter",
            outside: ".cmp-vtour__phone",
            place: "right", ring: true,
            text: ["Users can upload receipts conveniently from their phone using the Spend Clarity mobile app"],
            prepare: function () {
                cxEnsurePanel();
                cxEnsureDialog("linked");
            } },
        { id: "cx-library", chapter: "coding", page: "coding", target: '[data-cmp-codeexp-img="link"]',
            place: "bottom", ring: true,
            extra: { target: "#cx-itab-library", place: "bottom",
                text: "Uploaded images that haven\u2019t been linked yet are held in the Image Library" },
            text: ["The uploaded receipt photo can then be linked to expense details"],
            prepare: cxEnsureImageActions },
        { id: "cx-complete", chapter: "coding", page: "coding", outside: ".cmp-codeexp__panel",
            target: "[data-cmp-codeexp-complete]", place: "left", ring: true,
            text: ["With the receipt linked, the user reviews all charge codes and clicks ", { b: "Complete" },
                " to submit for approval"],
            next: "Continue", onNext: cxComplete, prepare: cxLinkAndReturn }
    ];

    function indexOf(id) {
        for (var i = 0; i < STEPS.length; i++) {
            if (STEPS[i].id === id) {
                return i;
            }
        }
        return -1;
    }

    function firstOfChapter(chapter) {
        for (var i = 0; i < STEPS.length; i++) {
            if (STEPS[i].chapter === chapter) {
                return i;
            }
        }
        return 0;
    }

    function chapterSteps(chapter) {
        return STEPS.filter(function (s) { return s.chapter === chapter; });
    }

    function readState() {
        try {
            return JSON.parse(window.sessionStorage.getItem(KEY) || "null");
        } catch (err) {
            return null;
        }
    }

    function writeState(state) {
        try {
            if (state) {
                window.sessionStorage.setItem(KEY, JSON.stringify(state));
            } else {
                window.sessionStorage.removeItem(KEY);
            }
        } catch (err) {
            /* Storage unavailable: the journey still works within the page. */
        }
    }

    function currentPage() {
        if (q("[data-cmp-cardlist]")) {
            return "cards";
        }
        if (q("[data-cmp-vclist]")) {
            return "virtual";
        }
        if (q("[data-cmp-expcat]")) {
            return "categories";
        }
        if (q("[data-cmp-codeexp]")) {
            return "coding";
        }
        return "home";
    }

    /* ---------- component ---------- */
    function init(root) {
        if (!root || root.__vtourInit) {
            return;
        }
        root.__vtourInit = true;

        var status = q("[data-cmp-vtour-status]", root);
        var chapters = Array.prototype.slice.call(root.querySelectorAll("[data-cmp-vtour-chapter]"));
        var page = currentPage();
        var urlKey = { home: "home", cards: "cards", virtual: "virtual", categories: "categories", coding: "coding" };
        var layer = document.createElement("div");
        layer.className = "cmp-vtour__layer";
        document.body.appendChild(layer);
        var pop = null;
        var hint = null;
        var extra = null;
        var ring = null;
        var stepIndex = -1;
        var targetEl = null;
        var hotspotHandler = null;
        var arrivedByFlow = false;

        function urlFor(p) {
            var k = urlKey[p];
            return root.getAttribute("data-url-" + k) || root.getAttribute("data-default-" + k);
        }

        var PAGE_CHAPTER = { home: "start", cards: "cards", virtual: "virtual", categories: "categories",
            coding: "coding" };

        function markChapter(chapter) {
            chapter = chapter || PAGE_CHAPTER[page];
            chapters.forEach(function (b) {
                var on = b.getAttribute("data-cmp-vtour-chapter") === chapter;
                b.classList.toggle("is-current", on);
                if (on) {
                    b.setAttribute("aria-current", "step");
                } else {
                    b.removeAttribute("aria-current");
                }
            });
        }

        function clearUi() {
            layer.textContent = "";
            pop = null;
            hint = null;
            extra = null;
            ring = null;
            if (targetEl && hotspotHandler) {
                targetEl.removeEventListener("click", hotspotHandler, true);
            }
            targetEl = null;
            hotspotHandler = null;
        }

        function end(announce) {
            clearUi();
            stepIndex = -1;
            writeState(null);
            markChapter(null);
            updateFrames();
            if (announce) {
                status.textContent = "Guided journey closed.";
            }
        }

        function resolveTarget(step) {
            if (!step.target) {
                return null;
            }
            if (step.target === "vcrow") {
                return vcRow();
            }
            if (step.target === "row") {
                return demoRow() || q("[data-cmp-toast]:not([hidden])");
            }
            if (step.target.indexOf("nav:") === 0) {
                var label = step.target.slice(4);
                var tabs = document.querySelectorAll(".cmp-header__nav-link, .cmp-vscheader__nav-link");
                return Array.prototype.slice.call(tabs).filter(function (n) {
                    return visible(n) && n.textContent.trim() === label;
                })[0] || null;
            }
            var all = Array.prototype.slice.call(document.querySelectorAll(step.target));
            return all.filter(visible)[0] || null;
        }

        function find(sel) {
            if (!sel) {
                return null;
            }
            return Array.prototype.slice.call(document.querySelectorAll(sel)).filter(visible)[0] || null;
        }

        function build(step, i) {
            var steps = chapterSteps(step.chapter);
            var pos = steps.indexOf(step);
            var el = document.createElement("section");
            el.className = "cmp-vtour__pop" + (step.center ? " cmp-vtour__pop--center" : "") +
                (step.id === "welcome" ? " cmp-vtour__pop--welcome" : "");
            el.setAttribute("role", "dialog");
            el.setAttribute("aria-labelledby", "cmp-vtour-heading");
            el.setAttribute("aria-describedby", "cmp-vtour-text");
            el.tabIndex = -1;


            var h = document.createElement("h2");
            h.id = "cmp-vtour-heading";
            h.className = step.title ? "cmp-vtour__title" : "cmp-visually-hidden";
            h.textContent = step.title || ("Guided journey, step " + (pos + 1) + " of " + steps.length);
            el.appendChild(h);
            if (step.subtitle) {
                var sub = document.createElement("p");
                sub.className = "cmp-vtour__sub";
                sub.textContent = step.subtitle;
                el.appendChild(sub);
            }
            var p = document.createElement("p");
            p.id = "cmp-vtour-text";
            p.className = "cmp-vtour__text";
            step.text.forEach(function (part) {
                if (typeof part === "string") {
                    p.appendChild(document.createTextNode(part));
                } else {
                    var b = document.createElement("strong");
                    b.textContent = part.b;
                    p.appendChild(b);
                }
            });
            el.appendChild(p);
            var tip = document.createElement("p");
            tip.className = "cmp-visually-hidden";
            tip.id = "cmp-vtour-tip";
            tip.textContent = "Press Escape to exit the guided journey.";
            el.appendChild(tip);
            el.setAttribute("aria-describedby", "cmp-vtour-text cmp-vtour-tip");

            if (!(step.center && step.id === "welcome")) {
                var prog = document.createElement("div");
                prog.className = "cmp-vtour__progress";
                prog.setAttribute("aria-hidden", "true");
                steps.forEach(function (s, k) {
                    var seg = document.createElement("span");
                    seg.className = "cmp-vtour__seg" + (k <= pos ? " is-done" : "");
                    prog.appendChild(seg);
                });
                el.appendChild(prog);
            }

            var actions = document.createElement("div");
            actions.className = "cmp-vtour__actions" + (step.back === false ? " cmp-vtour__actions--single" : "");
            var showBack = step.back === "flow" ? arrivedByFlow && i > 0 : step.back !== false;
            actions.className = "cmp-vtour__actions" + (showBack ? "" : " cmp-vtour__actions--single");
            if (showBack) {
                var back = document.createElement("button");
                back.type = "button";
                back.className = "cmp-vtour__btn";
                back.textContent = "Back";
                back.addEventListener("click", function () { go(i - 1, true); });
                actions.appendChild(back);
            }
            var next = document.createElement("button");
            next.type = "button";
            next.className = "cmp-vtour__btn cmp-vtour__btn--primary";
            next.textContent = step.next || "Next";
            next.setAttribute("data-cmp-vtour-next", "");
            next.addEventListener("click", function () {
                if (step.onNext) {
                    step.onNext();
                }
                go(i + 1, true);
            });
            actions.appendChild(next);
            el.appendChild(actions);
            return el;
        }

        function place(el, target, where, outside, anchorY) {
            el.style.top = "";
            el.style.left = "";
            if (!target) {
                el.classList.add("cmp-vtour__pop--center");
                return;
            }
            var r = target.getBoundingClientRect();
            var box = outside ? q(outside) : null;
            if (box && visible(box) && (where === "left" || where === "right")) {
                var b = box.getBoundingClientRect();
                var edge = where === "left" ? b.left : b.right;
                r = { left: edge, right: edge, width: 0, top: r.top, bottom: r.bottom, height: r.height };
            }
            var ay = anchorY ? find(anchorY) : null;
            if (ay && (where === "left" || where === "right")) {
                var a = ay.getBoundingClientRect();
                r = { left: r.left, right: r.right, width: r.width, top: a.top, bottom: a.bottom, height: a.height };
            }
            var w = el.offsetWidth;
            var hgt = el.offsetHeight;
            var gap = 14;
            var vw = document.documentElement.clientWidth;
            var vh = window.innerHeight;
            var top;
            var left;
            if (where === "left") {
                left = r.left - w - gap;
                top = r.top + r.height / 2 - hgt / 2;
                if (left < 8) {
                    where = "bottom";
                }
            }
            if (where === "right") {
                left = r.right + gap;
                top = r.top + r.height / 2 - hgt / 2;
                if (left + w > vw - 8) {
                    where = "bottom";
                }
            }
            if (where === "top") {
                left = r.left + r.width / 2 - w / 2;
                top = r.top - hgt - gap;
                if (top < 8) {
                    where = "bottom";
                }
            }
            if (where === "bottom") {
                left = r.left + r.width / 2 - w / 2;
                top = r.bottom + gap;
            }
            left = Math.max(8, Math.min(left, vw - w - 8));
            /* Keep clear of the previous / next arrows at the bottom centre. */
            top = Math.max(8, Math.min(top, vh - hgt - 56));
            el.setAttribute("data-place", where);
            el.style.left = Math.round(left) + "px";
            el.style.top = Math.round(top) + "px";
        }

        function placeRing(target) {
            if (!ring || !target) {
                return;
            }
            var r = target.getBoundingClientRect();
            var size = 64;
            ring.style.left = Math.round(r.left + r.width / 2 - size / 2) + "px";
            ring.style.top = Math.round(r.top + r.height / 2 - size / 2) + "px";
        }

        function placeHint() {
            if (!hint) {
                return;
            }
            var menu = q(".cmp-vtour__chapters", root).getBoundingClientRect();
            hint.style.left = Math.round(menu.right + 12) + "px";
            hint.style.top = Math.max(8, Math.round(menu.top + menu.height / 2 - hint.offsetHeight / 2)) + "px";
        }

        function layout() {
            if (stepIndex < 0 || !pop) {
                return;
            }
            var step = STEPS[stepIndex];
            if (step.center) {
                return;
            }
            var t = resolveTarget(step);
            place(pop, t, step.place || "bottom", step.outside, step.anchorY);
            placeRing(t);
            placeHint();
            if (extra && step.extra) {
                place(extra, find(step.extra.target), step.extra.place || "left", step.extra.outside);
            }
        }

        /* Decorative phone mock-up for the mobile upload step (Figma: camera screen). */
        function buildPhone() {
            var stage = document.createElement("div");
            stage.className = "cmp-vtour__stage";
            stage.setAttribute("aria-hidden", "true");
            var phone = document.createElement("div");
            phone.className = "cmp-vtour__phone";
            var screen = document.createElement("div");
            screen.className = "cmp-vtour__phone-screen";
            var receipt = document.createElement("div");
            receipt.className = "cmp-vtour__receipt";
            ["HOUSEWARES STORE", "123 Market Street", "Chicago, IL 60601", "", "Mixing Bowl Set      9.99",
                "Measuring Cups       6.49", "Kitchen Towel Set    7.99", "Silicone Spatula     3.49",
                "Storage Containers  12.99", "", "Subtotal            44.94", "Sales Tax 8.50%      3.82",
                "TOTAL               45.99"].forEach(function (line, k) {
                var row = document.createElement("span");
                row.className = k === 0 ? "cmp-vtour__receipt-title" : "";
                row.textContent = line || "\u00a0";
                receipt.appendChild(row);
            });
            screen.appendChild(receipt);
            phone.appendChild(screen);
            var label = document.createElement("span");
            label.className = "cmp-vtour__photo";
            label.textContent = "PHOTO";
            phone.appendChild(label);
            var bar = document.createElement("div");
            bar.className = "cmp-vtour__phone-bar";
            var cancel = document.createElement("span");
            cancel.textContent = "Cancel";
            var shutter = document.createElement("span");
            shutter.className = "cmp-vtour__shutter";
            bar.appendChild(cancel);
            bar.appendChild(shutter);
            bar.appendChild(document.createElement("span"));
            phone.appendChild(bar);
            stage.appendChild(phone);
            return stage;
        }

        function draw(step, i) {
            var target = resolveTarget(step);
            var scrollTo = step.scroll ? q(step.scroll) : target;
            if (scrollTo && scrollTo.scrollIntoView && !step.stage) {
                scrollTo.scrollIntoView({ block: "center", inline: "nearest" });
            }
            var dim = document.createElement("div");
            dim.className = "cmp-vtour__dim";
            dim.setAttribute("aria-hidden", "true");
            layer.insertBefore(dim, layer.firstChild);
            pop = build(step, i);
            layer.appendChild(pop);
            if (step.ring && target) {
                ring = document.createElement("div");
                ring.className = "cmp-vtour__ring";
                ring.setAttribute("aria-hidden", "true");
                layer.appendChild(ring);
            }
            if (step.hint) {
                hint = document.createElement("p");
                hint.className = "cmp-vtour__hint";
                hint.textContent = step.hint;
                layer.appendChild(hint);
            }
            if (step.extra) {
                extra = document.createElement("p");
                extra.className = "cmp-vtour__hint cmp-vtour__hint--extra";
                extra.textContent = step.extra.text;
                layer.appendChild(extra);
            }
            if (step.hotspotNext && target) {
                targetEl = target;
                hotspotHandler = makeHotspot(i);
                target.addEventListener("click", hotspotHandler, true);
            }
            layout();
            var focusEl = pop.querySelector("[data-cmp-vtour-next]");
            if (focusEl) {
                focusEl.focus({ preventScroll: true });
            }
            var steps = chapterSteps(step.chapter);
            status.textContent = (step.title ? step.title + ". " : "") + "Step " + (steps.indexOf(step) + 1) +
                " of " + steps.length + "." + (step.extra ? " " + step.extra.text + "." : "");
        }

        function render(i) {
            clearUi();
            var step = STEPS[i];
            stepIndex = i;
            markChapter(step.chapter);
            updateFrames();
            /* Run after the current click has finished bubbling (components close their menus on
               outside clicks), then let them update the DOM before measuring. */
            window.setTimeout(function () {
                if (stepIndex !== i) {
                    return;
                }
                if (step.prepare) {
                    step.prepare();
                }
                if (step.stage === "phone") {
                    layer.insertBefore(buildPhone(), layer.firstChild);
                }
            }, 0);
            /* Wait for the target (some appear after a delay, e.g. new rows), then draw. */
            var waited = 0;
            var limit = step.wait || 1200;
            function attempt() {
                if (stepIndex !== i) {
                    return;
                }
                if (step.target && !step.center && !resolveTarget(step) && waited < limit) {
                    waited += 100;
                    window.setTimeout(attempt, 100);
                    return;
                }
                draw(step, i);
            }
            window.setTimeout(attempt, 120);
        }

        function makeHotspot(i) {
            return function (e) {
                e.preventDefault();
                go(i + 1, true);
            };
        }

        /* =====================================================
           End of the journey: full-screen "Restart Demo" screen (Figma)
           ===================================================== */
        var finishEl = null;
        var finishReturn = null;

        function mockDashboard() {
            var shot = document.createElement("div");
            shot.className = "cmp-vtour__shot";
            var bar = document.createElement("div");
            bar.className = "cmp-vtour__shot-bar";
            var brand = document.createElement("span");
            brand.className = "cmp-vtour__shot-brand";
            brand.textContent = "VISA";
            var name = document.createElement("span");
            name.textContent = "Spend Clarity | Enterprise";
            bar.appendChild(brand);
            bar.appendChild(name);
            shot.appendChild(bar);
            var nav = document.createElement("div");
            nav.className = "cmp-vtour__shot-nav";
            ["Home", "My Spend", "Approvals", "Cards", "Virtual Cards", "Search", "Reports", "Administration"]
                .forEach(function (t) {
                    var item = document.createElement("span");
                    item.textContent = t;
                    nav.appendChild(item);
                });
            shot.appendChild(nav);
            var grid = document.createElement("div");
            grid.className = "cmp-vtour__shot-grid";
            [["My Actions", 5], ["Transactions", 9], ["Announcements", 3]].forEach(function (col) {
                var c = document.createElement("div");
                c.className = "cmp-vtour__shot-col";
                var head = document.createElement("span");
                head.className = "cmp-vtour__shot-head";
                head.textContent = col[0];
                c.appendChild(head);
                for (var k = 0; k < col[1]; k++) {
                    var line = document.createElement("span");
                    line.className = "cmp-vtour__shot-line" + (k === 0 && col[0] === "My Actions" ?
                        " cmp-vtour__shot-line--cta" : "");
                    c.appendChild(line);
                }
                grid.appendChild(c);
            });
            shot.appendChild(grid);
            return shot;
        }

        function closeFinish(restoreFocus) {
            if (!finishEl) {
                return;
            }
            finishEl.parentNode.removeChild(finishEl);
            finishEl = null;
            updateFrames();
            document.documentElement.classList.remove("cmp-vtour-locked");
            if (restoreFocus && finishReturn && document.documentElement.contains(finishReturn)) {
                finishReturn.focus();
            }
        }

        function showFinish() {
            end(false);
            closeFinish(false);
            finishReturn = document.activeElement;
            var screen = document.createElement("section");
            screen.className = "cmp-vtour__finish";
            screen.setAttribute("role", "dialog");
            screen.setAttribute("aria-modal", "true");
            screen.setAttribute("aria-labelledby", "cmp-vtour-finish-title");
            screen.setAttribute("aria-describedby", "cmp-vtour-finish-text");
            var copy = document.createElement("div");
            copy.className = "cmp-vtour__finish-copy";
            var h = document.createElement("h2");
            h.id = "cmp-vtour-finish-title";
            h.className = "cmp-vtour__finish-title";
            h.appendChild(document.createTextNode("The Future of Spend Management Starts with "));
            var strong = document.createElement("strong");
            strong.textContent = "Spend Clarity for Enterprise";
            h.appendChild(strong);
            copy.appendChild(h);
            var p = document.createElement("p");
            p.id = "cmp-vtour-finish-text";
            p.className = "cmp-vtour__finish-text";
            p.textContent = "The capabilities you\u2019ve just seen come together to create a seamless, end-to-end " +
                "view of spend. With greater visibility and control, businesses can move forward with clarity " +
                "and confidence. Connect with your banking representative to learn how Spend Clarity for " +
                "Enterprise can support your organization.";
            copy.appendChild(p);
            var restart = document.createElement("button");
            restart.type = "button";
            restart.className = "cmp-vtour__finish-btn";
            restart.textContent = "Restart Demo";
            restart.addEventListener("click", function () {
                closeFinish(false);
                go(0, false);
            });
            copy.appendChild(restart);
            screen.appendChild(copy);
            var laptop = document.createElement("div");
            laptop.className = "cmp-vtour__laptop";
            laptop.setAttribute("aria-hidden", "true");
            var lid = document.createElement("div");
            lid.className = "cmp-vtour__laptop-lid";
            lid.appendChild(mockDashboard());
            laptop.appendChild(lid);
            var base = document.createElement("div");
            base.className = "cmp-vtour__laptop-base";
            laptop.appendChild(base);
            screen.appendChild(laptop);
            screen.addEventListener("keydown", function (e) {
                if (e.key === "Tab") {
                    e.preventDefault();
                    restart.focus();
                } else if (e.key === "Escape" || e.key === "Esc") {
                    e.preventDefault();
                    closeFinish(true);
                    status.textContent = "Guided journey finished.";
                }
            });
            document.body.appendChild(screen);
            finishEl = screen;
            updateFrames();
            document.documentElement.classList.add("cmp-vtour-locked");
            restart.focus();
            status.textContent = "Guided journey finished. Restart Demo to start again.";
        }

        function go(i, flow) {
            if (i < 0) {
                return;
            }
            if (i >= STEPS.length) {
                /* Let the last action (Complete) update the list, then show the end screen. */
                end(false);
                window.setTimeout(showFinish, 400);
                return;
            }
            var step = STEPS[i];
            arrivedByFlow = !!flow;
            writeState({ step: step.id, flow: arrivedByFlow });
            if (step.page !== page) {
                clearUi();
                window.location.assign(urlFor(step.page));
                return;
            }
            render(i);
        }

        /* Previous / next frame arrows (bottom centre). */
        var prevBtn = q("[data-cmp-vtour-prev]", root);
        var nextBtn = q("[data-cmp-vtour-nextframe]", root);

        function updateFrames() {
            if (!prevBtn || !nextBtn) {
                return;
            }
            var finished = !!finishEl;
            prevBtn.disabled = finished || stepIndex <= 0;
            nextBtn.disabled = finished;
        }

        if (prevBtn && nextBtn) {
            prevBtn.addEventListener("click", function () {
                if (stepIndex > 0) {
                    go(stepIndex - 1, true);
                }
            });
            nextBtn.addEventListener("click", function () {
                if (finishEl) {
                    return;
                }
                if (stepIndex < 0) {
                    go(firstOfChapter(PAGE_CHAPTER[page]), false);
                    return;
                }
                var step = STEPS[stepIndex];
                if (step.onNext) {
                    step.onNext();
                }
                go(stepIndex + 1, true);
            });
        }

        chapters.forEach(function (b) {
            b.addEventListener("click", function () {
                go(firstOfChapter(b.getAttribute("data-cmp-vtour-chapter")), false);
            });
        });

        document.addEventListener("keydown", function (e) {
            if ((e.key === "Escape" || e.key === "Esc") && stepIndex >= 0 && pop &&
                (pop.contains(document.activeElement) || document.activeElement === document.body)) {
                end(true);
            }
        });
        window.addEventListener("resize", layout);
        window.addEventListener("scroll", layout, true);

        markChapter(null);
        updateFrames();

        /* Resume on page load, or show the welcome on the home page once per tab. */
        var state = readState();
        var resume = state && indexOf(state.step);
        if (state && resume >= 0 && STEPS[resume].page === page) {
            arrivedByFlow = !!state.flow;
            render(resume);
        } else if (!state && page === "home" && root.getAttribute("data-welcome") !== "false") {
            var seen = false;
            try {
                seen = window.sessionStorage.getItem(KEY + "-welcomed") === "1";
                window.sessionStorage.setItem(KEY + "-welcomed", "1");
            } catch (err) {
                seen = false;
            }
            if (!seen) {
                go(0, false);
            }
        } else if (state) {
            writeState(null);
        }
    }

    function boot() {
        Array.prototype.forEach.call(document.querySelectorAll("[data-cmp-vtour]"), function (root) {
            try {
                init(root);
            } catch (err) {
                window.console.warn("VSC Guided Journey could not start", err);
            }
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        boot();
    }
}());
